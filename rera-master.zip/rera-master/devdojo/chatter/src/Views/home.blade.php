@extends(Config::get('chatter.master_file_extend'))
@section(Config::get('chatter.yields.head'))
    <style>
        a .chatter-box {
            width: 10px;
            height: 10px;
            border-radius: 2px;
            float: left;
            position: relative;
            top: 50%;
            margin-top: 5px;
            left: 0;
            margin-right: 10px;
        }
        span.chatter_avatar_circle {
            width: 23px;
            height: 23px;
            line-height: 23px;
            text-align: center;
            background: #263238;
            display: inline-block;
            border-radius: 30px;
            color: #fff;
            font-size: 15px;
        }
        .chatter_cat {
            background: #ccc;
            border-radius: 30px ;
            font-weight: bold ;
            font-size: 10px ;
            padding: 3px 7px ;
            display: inline;
            color: #fff;
            position: relative;
            top: -2px;
        }
    </style>
        <link href="{{ url('/vendor/devdojo/chatter/assets/vendor/spectrum/spectrum.css') }}" rel="stylesheet">
    <link href="{{ url('/vendor/devdojo/chatter/assets/css/chatter.css') }}" rel="stylesheet">
    @if($chatter_editor == 'simplemde')
        <link href="{{ url('/vendor/devdojo/chatter/assets/css/simplemde.min.css') }}" rel="stylesheet">
    @elseif($chatter_editor == 'trumbowyg')
        <link href="{{ url('/vendor/devdojo/chatter/assets/vendor/trumbowyg/ui/trumbowyg.css') }}" rel="stylesheet">
        <style>
            .trumbowyg-box, .trumbowyg-editor {
                margin: 0px auto;
            }
        </style>
    @endif
@stop
@section('content')

    <main id="chatter" class="chatter_home">
    @if(session('verified'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
     Your email was successfully verified!!
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    @endif

        <section class="message--section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 mx-auto">
                        <?php $headline_logo = Config::get('chatter.headline_logo'); ?>
                        <div class="text-center">
                            @if( isset( $headline_logo ) && !empty( $headline_logo ) )
                                <img src="{{ Config::get('chatter.headline_logo') }}">
                            @else
                                <h6 class="text-primary mb-3">@lang('chatter::intro.headline')</h6>
                                <!-- <p>@lang('chatter::intro.description')</p> -->
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section>
            @if(config('chatter.errors'))
                <div class="row">
                    <div class="col-md-12">
                        @if(Session::has('chatter_alert'))
                            <div class="chatter-alert alert alert-{{ Session::get('chatter_alert_type') }}">
                                <div class="container">
                                    <strong><i class="chatter-alert-{{ Session::get('chatter_alert_type') }}"></i> {{ Config::get('chatter.alert_messages.' . Session::get('chatter_alert_type')) }}</strong>
                                    {{ Session::get('chatter_alert') }}
                                    <i class="chatter-close"></i>
                                </div>
                            </div>
                            <div class="chatter-alert-spacer"></div>
                        @endif

                        @if (count($errors) > 0)
                            <div class="chatter-alert alert alert-danger">
                                <div class="container">
                                    <p><strong><i class="chatter-alert-danger"></i> @lang('chatter::alert.danger.title')</strong> @lang('chatter::alert.danger.reason.errors')</p>
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            @endif
        </section>
        <section class="presentation--section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <button id="new_discussion_btn" class="btn btn-orange btn-block mb-5">@{{ $t('new_discussion') }}</button>

                        <ul class="list discussionList mb-4">
                            <li>
                                <a href="/{{ Config::get('chatter.routes.home') }}" class="{{request()->input('me')!=true?'active':''}}"> <i class="ic-chat"></i> @{{ $t('all_discussion') }} </a>
                           </li>
                            <li>
                                <a href="/{{ Config::get('chatter.routes.home') }}?me=true" class="{{request()->input('me')==true?'active':''}}"> <i class="ic-chat"></i> @{{ $t('my_discussion') }} </a>
                            </li>
                           <!--  <li>
                                <a href=""> <i class="ic-chat"></i> @{{ $t('solved_discussion') }} </a>
                            </li> -->
                        </ul>
                        <h6 class="text-muted"> @{{ $t('Categories') }} </h6>
                        {!! $categoriesMenu !!}
                        <br>
                        <div class="contact d-none d-lg-block">
                            <h6 class="text-primary mb-3">AEPC @{{ $t('Contact') }}</h6>
                            <p>@{{ $t('contacts_details') }}</p>
                            <p>@{{ $t('Website') }}: <a href="info@aepc.gov.np" target="_blank">info@aepc.gov.np</a></p>
                            <p>Tel: <a href="tel:+9771-4498013">+9771-4498013</a>,<a href="tel:4498014">4498014</a> </p>
                           <!--  <p>Fax: <a href="tel:+9771-5542397">+9771-5542397</a>, <a href="tel:5539392">5539392</a> </p> -->
                            <p>Post Box : 14364</p>
                        </div>
                    </div>

                    <div class="col-lg-9">

{{--                        <div class="dropdown mb-4">--}}
{{--                            <a class="btn btn-light text-primary dropdown-toggle" href="#" role="button" id="dropdownMenuLink"--}}
{{--                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">--}}
{{--                                Latest--}}
{{--                            </a>--}}

{{--                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">--}}
{{--                                <a class="dropdown-item" href="#">Action</a>--}}
{{--                                <a class="dropdown-item" href="#">Another action</a>--}}
{{--                                <a class="dropdown-item" href="#">Something else here</a>--}}
{{--                            </div>--}}
{{--                        </div>--}}

                        @foreach($discussions as $discussion)
                            <a href="/{{ Config::get('chatter.routes.home') }}/{{ Config::get('chatter.routes.discussion') }}/{{ $discussion->category->slug }}/{{ $discussion->slug }}">
                            <div class="card card__bordered mb-3 ">
                                <div class="d-flex align-items-center mb-2">
                                    <div class="avatar-sm mr-2">
                                        @if(Config::get('chatter.user.avatar_image_database_field'))
                                            <?php $db_field = Config::get('chatter.user.avatar_image_database_field'); ?>
                                            @if( (substr($discussion->user->{$db_field}, 0, 7) == 'http://') || (substr($discussion->user->{$db_field}, 0, 8) == 'https://') )
                                                <img src="{{ $discussion->user->{$db_field}  }}" alt="">
                                            @else
                                                <img src="{{ Config::get('chatter.user.relative_url_to_image_assets') . $discussion->user->{$db_field}  }}" alt="">
                                            @endif
                                        @else
                                            <span class="chatter_avatar_circle" style="background-color:#<?= \DevDojo\Chatter\Helpers\ChatterHelper::stringToColorCode($discussion->user->{Config::get('chatter.user.database_field_with_user_name')}) ?>">
					        					{{ strtoupper(substr($discussion->user->{Config::get('chatter.user.database_field_with_user_name')}, 0, 1)) }}
					        				</span>
                                        @endif
                                    </div>
                                    <h6 class="text-dark">
                                        {{ ucfirst($discussion->user->{Config::get('chatter.user.database_field_with_user_name')}) }}
                                        <small class="text-left">Posted {{ \Carbon\Carbon::createFromTimeStamp(strtotime($discussion->created_at))->diffForHumans() }}</small>
                                    </h6>
                                </div>
                                <h5>
                                    {{ $discussion->title }}
                                    <span class="chatter_cat" style="background-color:{{ $discussion->category->color }}">{{ $discussion->category->name }}</span>
                                </h5>
                                <p>
                                    @if($discussion->post[0]->markdown)
                                        <?php $discussion_body = GrahamCampbell\Markdown\Facades\Markdown::convertToHtml( $discussion->post[0]->body ); ?>
                                    @else
                                        <?php $discussion_body = $discussion->post[0]->body; ?>
                                    @endif
                                    {{ substr(strip_tags($discussion_body), 0, 200) }}@if(strlen(strip_tags($discussion_body)) > 200){{ '...' }}@endif
                                </p>

                                <div class="text-right">
                                    <button class="btn btn-custom btn-sm" data-toggle="collapse" href="/{{ Config::get('chatter.routes.home') }}/{{ Config::get('chatter.routes.discussion') }}/{{ $discussion->category->slug }}/{{ $discussion->slug }}" role="button" aria-expanded="false" aria-controls="collapsable">
                                        <i class="ic-chat"></i>
                                        Comments ({{ $discussion->postsCount[0]->total }})
                                    </button>
                                </div>

                            </div>
                            </a>
                        @endforeach
                        <div id="pagination">
                            {{ $discussions->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <div id="new_discussion">
            <div class="chatter_loader dark" id="new_discussion_loader">
                <div></div>
            </div>
            <form id="chatter_form_editor" action="/{{ Config::get('chatter.routes.home') }}/{{ Config::get('chatter.routes.discussion') }}" method="POST">
                <div class="row">
                    <div class="col-md-7">
                        <!-- TITLE -->
                        <input type="text" class="form-control" id="title" name="title" placeholder="@lang('chatter::messages.editor.title')" value="{{ old('title') }}" >
                    </div>

                    <div class="col-md-4">
                        <!-- CATEGORY -->
                        <select id="chatter_category_id" class="form-control" name="chatter_category_id">
                            <option value="">@lang('chatter::messages.editor.select')</option>
                            @foreach($categories as $category)
                                @if(old('chatter_category_id') == $category->id)
                                    <option value="{{ $category->id }}" selected>{{ $category->name }}</option>
                                @elseif(!empty($current_category_id) && $current_category_id == $category->id)
                                    <option value="{{ $category->id }}" selected>{{ $category->name }}</option>
                                @else
                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @endif
                            @endforeach
                        </select>
                    </div>

                    <div class="col-md-1">
                        <i class="chatter-close"></i>
                    </div>
                </div><!-- .row -->

                <!-- BODY -->
                <div id="editor">
                    @if( $chatter_editor == 'tinymce' || empty($chatter_editor) )
                        <label id="tinymce_placeholder">@lang('chatter::messages.editor.tinymce_placeholder')</label>
                        <textarea id="body" class="richText" name="body" placeholder="">{{ old('body') }}</textarea>
                    @elseif($chatter_editor == 'simplemde')
                        <textarea id="simplemde" name="body" placeholder="">{{ old('body') }}</textarea>
                    @elseif($chatter_editor == 'trumbowyg')
                        <textarea class="trumbowyg" name="body" placeholder="@lang('chatter::messages.editor.tinymce_placeholder')">{{ old('body') }}</textarea>
                    @endif
                </div>

                <input type="hidden" name="_token" id="csrf_token_field" value="{{ csrf_token() }}">

                <div id="new_discussion_footer">
                    <input type='text' id="color" name="color" /><span class="select_color_text">@lang('chatter::messages.editor.select_color_text')</span>
                    <button id="submit_discussion" class="btn btn-success pull-right"><i class="chatter-new"></i> @lang('chatter::messages.discussion.create')</button>
                    <a href="/{{ Config::get('chatter.routes.home') }}" class="btn btn-default pull-right" id="cancel_discussion">@lang('chatter::messages.words.cancel')</a>
                    <div style="clear:both"></div>
                </div>
            </form>

        </div><!-- #new_discussion -->

        <section>
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="contact d-block d-lg-none mb-3 mb-lg-0">
                            <h6 class="text-primary mb-3">AEPC Contact</h6>
                            <p>Madhya Baneshwor, Kathmandu, Nepal</p>
                            <p>Website: <a href="info@aepc.gov.np" target="_blank">info@aepc.gov.np</a></p>
                            <p>Tel: <a href="tel:+9771-4498013">+9771-4498013</a>,<a href="tel:4498014">4498014</a> </p>
                            <p>Fax: <a href="tel:+9771-5542397">+9771-5542397</a>, <a href="tel:5539392">5539392</a> </p>
                            <p>Post Box :14364</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

@endsection

@section(Config::get('chatter.yields.footer'))


    @if( $chatter_editor == 'tinymce' || empty($chatter_editor) )
        <script src="{{ url('/vendor/devdojo/chatter/assets/vendor/tinymce/tinymce.min.js') }}"></script>
        <script src="{{ url('/vendor/devdojo/chatter/assets/js/tinymce.js') }}"></script>
        <script>
            var my_tinymce = tinyMCE;
            $('document').ready(function(){
                $('#tinymce_placeholder').click(function(){
                    my_tinymce.activeEditor.focus();
                });
            });
        </script>
    @elseif($chatter_editor == 'simplemde')
        <script src="{{ url('/vendor/devdojo/chatter/assets/js/simplemde.min.js') }}"></script>
        <script src="{{ url('/vendor/devdojo/chatter/assets/js/chatter_simplemde.js') }}"></script>
    @elseif($chatter_editor == 'trumbowyg')
        <script src="{{ url('/vendor/devdojo/chatter/assets/vendor/trumbowyg/trumbowyg.min.js') }}"></script>
        <script src="{{ url('/vendor/devdojo/chatter/assets/vendor/trumbowyg/plugins/preformatted/trumbowyg.preformatted.min.js') }}"></script>
        <script src="{{ url('/vendor/devdojo/chatter/assets/js/trumbowyg.js') }}"></script>
    @endif

    <script src="{{ url('/vendor/devdojo/chatter/assets/vendor/spectrum/spectrum.js') }}"></script>
    <script src="{{ url('/vendor/devdojo/chatter/assets/js/chatter.js') }}"></script>
    <script>
        $('document').ready(function(){

            $('.chatter-close, #cancel_discussion').click(function(){
                $('#new_discussion').slideUp();
            });
            $('#new_discussion_btn').click(function(){
                @if(Auth::guest())
                    window.location.href = "{{ route('login') }}";
                @else
                $('#new_discussion').slideDown();
                $('#title').focus();
                @endif
            });

            $("#color").spectrum({
                color: "#333639",
                preferredFormat: "hex",
                containerClassName: 'chatter-color-picker',
                cancelText: '',
                chooseText: 'close',
                move: function(color) {
                    $("#color").val(color.toHexString());
                }
            });

            @if (count($errors) > 0)
            $('#new_discussion').slideDown();
            $('#title').focus();
            @endif


        });
    </script>
@stop
