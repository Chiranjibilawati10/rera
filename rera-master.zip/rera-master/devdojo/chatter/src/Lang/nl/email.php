<?php

return [
    'preheader'       => 'We laten je even weten dat iemand gereageerd heeft op een forum discussie.',
    'greeting'        => 'Hallo,',
    'body'            => 'We laten je even weten dat iemand gereageerd heeft op een forum discussie op',
    'view_discussion' => 'Bekijk de discussie',
    'farewell'        => 'Nog een fijne dag gewenst!',
    'unsuscribe'      => [
        'message' => 'Als je geen notificaties meer wilt ontvangen voor deze discussie, wijzig dan je aanmelding onderaan deze pagina :)',
        'action'  => 'Genoeg van deze e-mails?',
        'link'    => 'Afmelden voor deze discussie',
    ],
];
