<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = new \App\User();
        $user->name = "Demo User";
        $user->email = "demo@infodevelopers.com.np";
        $user->password = \Illuminate\Support\Facades\Hash::make("password");
        $user->is_super = 1;
        $user->user_type=1;
        $user->save();
    }
}
