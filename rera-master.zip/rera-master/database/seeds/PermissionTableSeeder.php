<?php

use Illuminate\Database\Seeder;

class PermissionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $permissions = [
            ['DISPLAY_NAME' => 'Can list user', 'CODE' => 'user-list', 'MENU_CODE' => 'user'],
            ['DISPLAY_NAME' => 'Can register user', 'CODE' => 'user-add', 'MENU_CODE' => 'user'],
            ['DISPLAY_NAME' => 'Can edit user', 'CODE' => 'user-edit', 'MENU_CODE' => 'user'],
            ['DISPLAY_NAME' => 'Can delete user', 'CODE' => 'user-delete', 'MENU_CODE' => 'user'],
            ['DISPLAY_NAME' => 'Can Assign permission to user', 'CODE' => 'user-permission', 'MENU_CODE' => 'user'],

            ['DISPLAY_NAME' => 'Can list permissions', 'CODE' => 'permission-list', 'MENU_CODE' => 'permission'],
            ['DISPLAY_NAME' => 'Can create permissions group', 'CODE' => 'permission-add', 'MENU_CODE' => 'permission'],
//            ['DISPLAY_NAME' => 'Can edit permissions', 'CODE' => 'permission-update', 'MENU_CODE' => 'permission'],
            ['DISPLAY_NAME' => 'Can delete permissions group', 'CODE' => 'permission-delete', 'MENU_CODE' => 'permission'],

            ['DISPLAY_NAME' => 'Can list FAQ', 'CODE' => 'faq-list', 'MENU_CODE' => 'FAQ'],
            ['DISPLAY_NAME' => 'Can create FAQ', 'CODE' => 'faq-add', 'MENU_CODE' => 'FAQ'],
            ['DISPLAY_NAME' => 'Can update FAQ', 'CODE' => 'faq-update', 'MENU_CODE' => 'FAQ'],
            ['DISPLAY_NAME' => 'Can delete FAQ', 'CODE' => 'faq-delete', 'MENU_CODE' => 'FAQ'],

            ['DISPLAY_NAME' => 'Can list consultant pool', 'CODE' => 'consultant-list', 'MENU_CODE' => 'Consultant Pool'],
            ['DISPLAY_NAME' => 'Can create consultant pool', 'CODE' => 'consultant-add', 'MENU_CODE' => 'Consultant Pool'],
            ['DISPLAY_NAME' => 'Can update consultant pool', 'CODE' => 'consultant-update', 'MENU_CODE' => 'Consultant Pool'],
            ['DISPLAY_NAME' => 'Can delete consultant pool', 'CODE' => 'consultant-delete', 'MENU_CODE' => 'Consultant Pool'],

            ['DISPLAY_NAME' => 'Can list success story', 'CODE' => 'success-story-list', 'MENU_CODE' => 'Success Story'],
            ['DISPLAY_NAME' => 'Can create success story', 'CODE' => 'success-story-add', 'MENU_CODE' => 'Success Story'],
            ['DISPLAY_NAME' => 'Can update success story', 'CODE' => 'success-story-update', 'MENU_CODE' => 'Success Story'],
            ['DISPLAY_NAME' => 'Can delete success story', 'CODE' => 'success-story-delete', 'MENU_CODE' => 'Success Story'],

            ['DISPLAY_NAME' => 'Can list complain feedback', 'CODE' => 'complain-feedback-list', 'MENU_CODE' => 'Complain Feedback'],
            // ['DISPLAY_NAME' => 'Can create complain feedback', 'CODE' => 'complain-feedback-add', 'MENU_CODE' => 'Complain Feedback'],
            ['DISPLAY_NAME' => 'Can Reply complain feedback', 'CODE' => 'complain-feedback-update', 'MENU_CODE' => 'Complain Feedback'],
            ['DISPLAY_NAME' => 'Can delete complain feedback', 'CODE' => 'complain-feedback-delete', 'MENU_CODE' => 'Complain Feedback'],

            ['DISPLAY_NAME' => 'Can list re-technologies', 'CODE' => 're-technologies-list', 'MENU_CODE' => 'RE Technologies'],
            ['DISPLAY_NAME' => 'Can create re-technologies', 'CODE' => 're-technologies-add', 'MENU_CODE' => 'RE Technologies'],
            ['DISPLAY_NAME' => 'Can update re-technologies', 'CODE' => 're-technologies-update', 'MENU_CODE' => 'RE Technologies'],
            ['DISPLAY_NAME' => 'Can delete re-technologies', 'CODE' => 're-technologies-delete', 'MENU_CODE' => 'RE Technologies'],

            ['DISPLAY_NAME' => 'Can list re-subcategories', 'CODE' => 're-subcategories-list', 'MENU_CODE' => 'RE Sub Category'],
            ['DISPLAY_NAME' => 'Can create re-subcategories', 'CODE' => 're-subcategories-add', 'MENU_CODE' => 'RE Sub Category'],
            ['DISPLAY_NAME' => 'Can update re-subcategories', 'CODE' => 're-subcategories-update', 'MENU_CODE' => 'RE Sub Category'],
            ['DISPLAY_NAME' => 'Can delete re-subcategories', 'CODE' => 're-subcategories-delete', 'MENU_CODE' => 'RE Sub Category'],

            ['DISPLAY_NAME' => 'Can list re-categories', 'CODE' => 're-categories-list', 'MENU_CODE' => 'RE Category'],
            ['DISPLAY_NAME' => 'Can create re-categories', 'CODE' => 're-categories-add', 'MENU_CODE' => 'RE Category'],
            ['DISPLAY_NAME' => 'Can update re-categories', 'CODE' => 're-categories-update', 'MENU_CODE' => 'RE Category'],
            ['DISPLAY_NAME' => 'Can delete re-categories', 'CODE' => 're-categories-delete', 'MENU_CODE' => 'RE Category'],

            ['DISPLAY_NAME' => 'Can list chapter', 'CODE' => 'chapter-list', 'MENU_CODE' => 'Chapter'],
            ['DISPLAY_NAME' => 'Can create chapter', 'CODE' => 'chapter-add', 'MENU_CODE' => 'Chapter'],
            ['DISPLAY_NAME' => 'Can update chapter', 'CODE' => 'chapter-update', 'MENU_CODE' => 'Chapter'],
            ['DISPLAY_NAME' => 'Can delete chapter', 'CODE' => 'chapter-delete', 'MENU_CODE' => 'Chapter'],

            ['DISPLAY_NAME' => 'Can list Notice category', 'CODE' => 'newscategory-list', 'MENU_CODE' => 'Notice Category'],
            ['DISPLAY_NAME' => 'Can create  Notice category', 'CODE' => 'newscategory-add', 'MENU_CODE' => ' Notice Category'],
            ['DISPLAY_NAME' => 'Can update  Notice category', 'CODE' => 'newscategory-update', 'MENU_CODE' => ' Notice Category'],
            ['DISPLAY_NAME' => 'Can delete  Notice category', 'CODE' => 'newscategory-delete', 'MENU_CODE' => ' Notice Category'],

            ['DISPLAY_NAME' => 'Can list Notice', 'CODE' => 'newsevents-list', 'MENU_CODE' => 'Notice'],
            ['DISPLAY_NAME' => 'Can create Notice', 'CODE' => 'newsevents-add', 'MENU_CODE' => 'Notices'],
            ['DISPLAY_NAME' => 'Can update Notice', 'CODE' => 'newsevents-update', 'MENU_CODE' => 'Notices'],
            ['DISPLAY_NAME' => 'Can delete Notice', 'CODE' => 'newsevents-delete', 'MENU_CODE' => 'Notices'],
            ['DISPLAY_NAME' => 'Can list forum', 'CODE' => 'forum-list', 'MENU_CODE' => 'Forum'],
            ['DISPLAY_NAME' => 'Can list Content', 'CODE' => 'topic-list', 'MENU_CODE' => 'Content'],
            ['DISPLAY_NAME' => 'Can create Content', 'CODE' => 'topic-add', 'MENU_CODE' => 'Content'],
            ['DISPLAY_NAME' => 'Can update Content', 'CODE' => 'topic-update', 'MENU_CODE' => 'Content'],
            ['DISPLAY_NAME' => 'Can delete Content', 'CODE' => 'topic-delete', 'MENU_CODE' => 'Content'],

            ['DISPLAY_NAME' => 'Can list  Occupation', 'CODE' => 'occupation-list', 'MENU_CODE' => 'Occupation'],
            ['DISPLAY_NAME' => 'Can create  Occupation', 'CODE' => 'occupation-add', 'MENU_CODE' => 'Occupation'],
            ['DISPLAY_NAME' => 'Can update  Occupation', 'CODE' => 'occupation-update', 'MENU_CODE' => 'Occupation'],
            ['DISPLAY_NAME' => 'Can delete  Occupation', 'CODE' => 'occupation-delete', 'MENU_CODE' => 'Occupation'],

            ['DISPLAY_NAME' => 'Can list  Slider', 'CODE' => 'slider-list', 'MENU_CODE' => 'Slider'],
            ['DISPLAY_NAME' => 'Can create  Slider', 'CODE' => ' slider-add', 'MENU_CODE' => 'Slider'],
            ['DISPLAY_NAME' => 'Can update  Slider', 'CODE' => ' slider-update', 'MENU_CODE' => 'Slider'],
            ['DISPLAY_NAME' => 'Can delete  Slider', 'CODE' => '  slider-delete', 'MENU_CODE' => 'Slider'],

            ['DISPLAY_NAME' => 'Can list  Gallary', 'CODE' => 'gallary-list', 'MENU_CODE' => 'Gallary'],
            ['DISPLAY_NAME' => 'Can create  Gallary', 'CODE' => ' gallary-add', 'MENU_CODE' => 'Gallary'],
            ['DISPLAY_NAME' => 'Can update  Gallary', 'CODE' => ' gallary-update', 'MENU_CODE' => 'Gallary'],
            ['DISPLAY_NAME' => 'Can delete  Gallary', 'CODE' => '  gallary-delete', 'MENU_CODE' => 'Gallary'],

            ['DISPLAY_NAME' => 'Can list  Album', 'CODE' => 'album-list', 'MENU_CODE' => 'Album'],
            ['DISPLAY_NAME' => 'Can create  Album', 'CODE' => ' album-add', 'MENU_CODE' => 'Album'],
            ['DISPLAY_NAME' => 'Can update  Album', 'CODE' => ' album-update', 'MENU_CODE' => 'Album'],
            ['DISPLAY_NAME' => 'Can delete  Album', 'CODE' => '  album-delete', 'MENU_CODE' => 'Album'],

            ['DISPLAY_NAME' => 'Can list  SliderInfo', 'CODE' => 'sliderinfo-list', 'MENU_CODE' => 'SliderInfo'],
            ['DISPLAY_NAME' => 'Can create  SliderInfo', 'CODE' => ' sliderinfo-add', 'MENU_CODE' => 'SliderInfo'],
            ['DISPLAY_NAME' => 'Can update  SliderInfo', 'CODE' => ' sliderinfo-update', 'MENU_CODE' => 'SliderInfo'],
            ['DISPLAY_NAME' => 'Can delete  SliderInfo', 'CODE' => '  sliderinfo-delete', 'MENU_CODE' => 'SliderInfo'],


            
        
            ['DISPLAY_NAME' => 'Can View Dashboard', 'CODE' => 'dashboard', 'MENU_CODE' => 'Dashboard'],

        ];

        foreach ($permissions as $value){
            \App\Model\Auth\AuthPermission::create($value);
        }
    }
}
