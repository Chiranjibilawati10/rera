<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateChatterPostTable extends Migration
{
    public function up()
    {
        Schema::create('chatter_post', function (Blueprint $table) {
            $table->increments('id');
            $table->bigInteger('chatter_discussion_id')->unsigned();
            $table->bigInteger('user_id')->unsigned();
            $table->text('body');
            $table->boolean('markdown')->default(0);
            $table->boolean('locked')->default(0);
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('chatter_discussion_id')->references('id')->on('chatter_discussion')
                ->onDelete('cascade')
                ->onUpdate('cascade');
            $table->foreign('user_id')->references('id')->on('users')
                ->onDelete('cascade')
                ->onUpdate('cascade');
        });
    }

    public function down()
    {
        Schema::table('chatter_post', function (Blueprint $table) {
            $table->dropForeign('chatter_post_chatter_discussion_id_foreign');
            $table->dropForeign('chatter_post_user_id_foreign');
        });
        Schema::drop('chatter_post');
    }
}
