<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateComplainFeedbackTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('complain_feedback', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->enum('type', ['complain', 'feedback']);
            $table->string('subject');
            $table->text('message');
            $table->text('reply_message');
            $table->string('send_from_email');
            $table->string('reply_by_email');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('complain_feedback');
    }
}
