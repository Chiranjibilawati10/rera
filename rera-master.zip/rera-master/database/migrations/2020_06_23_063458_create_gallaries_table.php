<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGallariesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('albums', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name')->nullable();
            $table->string('name_ne')->nullable();
            $table->bigInteger('order')->default(0);
            $table->boolean('status')->default(1);
            $table->string('slug')->nullable();
            $table->unsignedBigInteger('created_id')->nullable();
            $table->unsignedBigInteger('updated_id')->nullable();
            $table->timestamps();
        });
        Schema::create('gallaries', function (Blueprint $table) {
           $table->bigIncrements('id');
           $table->string('name')->nullable();
           $table->string('name_ne')->nullable();
           $table->bigInteger('order')->default(0);
           $table->boolean('status')->default(1);
           $table->unsignedBigInteger('album_id');
           $table->foreign('album_id')->references('id')->on('albums')->onDelete('cascade');
           $table->unsignedBigInteger('created_id')->nullable();
           $table->unsignedBigInteger('updated_id')->nullable();
           $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('gallaries');
    }
}
