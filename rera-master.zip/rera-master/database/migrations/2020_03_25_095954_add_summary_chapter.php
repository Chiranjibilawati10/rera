<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddSummaryChapter extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('chapters', function (Blueprint $table) {
            $table->text('summary')->nullable();
            $table->text('summary_ne')->nullable();
            $table->string('slug')->nullable();
            $table->integer('order')->default(0);
            \DB::statement('ALTER TABLE `chapters` MODIFY `chapter_name_ne` VARCHAR(100) NULL;');  
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('chapters', function (Blueprint $table) {
            $table->dropColumn('summary');
            $table->dropColumn('summary_ne');
            $table->dropColumn('order');
            $table->dropColumn('slug');
            \DB::statement('ALTER TABLE `chapters` MODIFY `chapter_name_ne` VARCHAR(100) NOT NULL;'); 
        });
    }
}
