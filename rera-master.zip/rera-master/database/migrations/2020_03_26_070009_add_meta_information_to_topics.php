<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddMetaInformationToTopics extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('topics', function (Blueprint $table) {
            $table->integer('order')->default(0);
            $table->string('target_group')->nullable();
            $table->string('technical_level')->nullable();
            $table->string('source')->nullable();
            $table->string('weblink')->nullable();
            $table->string('language')->nullable();
            $table->string('draft_review')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('topics', function (Blueprint $table) {
            $table->dropColumn('order');
            $table->dropColumn('target_group');
            $table->dropColumn('technical_level');
            $table->dropColumn('source');
            $table->dropColumn('weblink');
            $table->dropColumn('language');
            $table->dropColumn('draft_review');

        });
    }
}
