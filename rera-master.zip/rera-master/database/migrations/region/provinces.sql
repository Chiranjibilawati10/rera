-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2020 at 05:59 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rera`
--

-- --------------------------------------------------------

--
-- Table structure for table `provinces`
--

CREATE TABLE `provinces` (
  `ID` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `name_ne` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `CODE` varchar(10) DEFAULT NULL,
  `STATUS` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provinces`
--

INSERT INTO `provinces` (`ID`, `name`, `name_ne`, `CODE`, `STATUS`) VALUES
(1, 'Province No. 1', 'प्रदेश नं० १', 'PR1', 1),
(2, 'Province No. 2', 'प्रदेश नं० २', 'PR2', 1),
(3, 'Bagmati Province', 'वाग्मती प्रदेश', 'PR3', 1),
(4, 'Gandaki Province', 'गण्डकी प्रदेश', 'PR4', 1),
(5, 'Province No. 5', ' प्रदेश नं० ५', 'PR5', 1),
(6, 'Karnali Province', 'कर्णाली प्रदेश', 'PR6', 1),
(7, 'Sudurpashchim Province', 'सुदूरपश्चिम प्रदेश', 'PR7', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `provinces`
--
ALTER TABLE `provinces`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `provinces`
--
ALTER TABLE `provinces`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
