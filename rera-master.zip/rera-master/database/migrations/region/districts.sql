-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2020 at 05:59 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rera`
--

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `ID` int(11) NOT NULL,
  `PROVIENCE_REGION_ID` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `name_ne` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `CODE` varchar(10) DEFAULT NULL,
  `STATUS` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`ID`, `PROVIENCE_REGION_ID`, `name`, `name_ne`, `CODE`, `STATUS`) VALUES
(1, 7, 'ACHHAM', 'अछाम', 'ACH', 1),
(2, 5, 'ARGHAKHANCHI', ' अर्घाखाँची', 'ARK', 1),
(3, 4, 'BAGLUNG', 'बाग्लुङ', 'BAG', 1),
(4, 7, 'BAITADI', ' बैतडी', 'BTD', 1),
(5, 7, 'BAJHANG', ' बझाङ', 'BHG', 1),
(6, 7, 'BAJURA', 'बाजुरा', 'BJU', 1),
(7, 5, 'BANKE', 'बाँके', 'BKE', 1),
(8, 2, 'BARA', 'बारा', 'BAR', 1),
(9, 5, 'BARDIYA', 'बर्दिया', 'BDY', 1),
(10, 3, 'BHAKTAPUR', 'भक्तपुर', 'BAK', 1),
(11, 1, 'BHOJPUR', ' भोजपुर', 'BOJ', 1),
(12, 3, 'CHITWAN', 'चितवन', 'CTW', 1),
(13, 7, 'DADELDHURA', ' डडेलधुरा', 'DDD', 1),
(14, 6, 'DAILEKH', 'दैलेख', 'DAI', 1),
(15, 5, 'DANG', 'दाङ', 'DNG', 1),
(16, 7, 'DARCHULA', 'दार्चुला', 'DCL', 1),
(17, 3, 'DHADING', ' धादिङ', 'DAD', 1),
(18, 1, 'DHANKUTA', 'धनकुटा', 'DAK', 1),
(19, 2, 'DHANUSHA', 'धनुषा', 'DAN', 1),
(20, 3, 'DOLKHA', ' दोलखा', 'DKA', 1),
(21, 6, 'DOLPA', 'डोल्पा', 'DPA', 1),
(22, 7, 'DOTI', ' डोटी', 'DOT', 1),
(23, 4, 'GORKHA', ' गोरखा', 'GOR', 1),
(24, 5, 'GULMI', ' गुल्मी', 'GUL', 1),
(25, 6, 'HUMLA', 'हुम्ला', 'HLA', 1),
(26, 1, 'ILAM', ' इलाम', 'ILM', 1),
(27, 6, 'JAJARKOT', 'जाजरकोट', 'JJK', 1),
(28, 1, 'JHAPA', 'झापा', 'JAP', 1),
(29, 6, 'JUMLA', 'जुम्ला', 'JLA', 1),
(30, 7, 'KAILALI', 'कैलाली', 'KAI', 1),
(31, 6, 'KALIKOT', 'कालीकोट', 'KLK', 1),
(32, 7, 'KANCHANPUR', 'कञ्चनपुर', 'KCP', 1),
(33, 5, 'KAPILVASTU', 'कपिलवस्तु', 'KAP', 1),
(34, 4, 'KASKI', 'कास्की', 'KAS', 1),
(35, 3, 'KATHMANDU', 'काठमाडौं', 'KTM', 1),
(36, 3, 'KAVRE', 'काभ्रेपलाञ्चोक', 'KAV', 1),
(37, 1, 'KHOTANG', ' खोटाङ', 'KHO', 1),
(38, 3, 'LALITPUR', 'ललितपुर', 'LAL', 1),
(39, 4, 'LAMJUNG', ' लमजुङ', 'LAM', 1),
(40, 2, 'MAHOTTARI', ' महोत्तरी', 'MAH', 1),
(41, 3, 'MAKWANPUR', 'मकवानपुर', 'MKW', 1),
(42, 4, 'MANANG', 'मनाङ', 'MAN', 1),
(43, 1, 'MORANG', 'मोरङ', 'MOR', 1),
(44, 6, 'MUGU', 'मुगु', 'MUG', 1),
(45, 4, 'MUSTANG', ' मुस्ताङ', 'MUS', 1),
(46, 4, 'MYAGDI', ' म्याग्दी', 'MYA', 1),
(47, 4, 'NAWALPARASI_E', 'नवलपरासी पूर्व', 'NEW\r\n', 1),
(48, 5, 'NAWALPARASI_W', 'नवलपरासी पश्चिम', 'NWL\r\n', 1),
(49, 3, 'NUWAKOT', 'नुवाकोट', 'NUW', 1),
(50, 1, 'OKHALDHUNGA', 'ओखलढुङ्गा', 'OKA', 1),
(51, 5, 'PALPA', 'पाल्पा', 'PAL', 1),
(52, 1, 'PANCHTHAR', ' पाँचथर', 'PCH', 1),
(53, 4, 'PARBAT', ' पर्वत', 'PBT', 1),
(54, 2, 'PARSA', ' पर्सा', 'PAR', 1),
(55, 5, 'PYUTHAN', 'प्युठान', 'PYU', 1),
(56, 3, 'RAMECHHAP', ' रामेछाप', 'RAM', 1),
(57, 3, 'RASUWA', ' रसुवा', 'RAS', 1),
(58, 2, 'RAUTAHAT', 'रौतहट', 'RAU', 1),
(59, 5, 'ROLPA', ' रोल्पा', 'RPA', 1),
(60, 6, 'RUKUM_E', 'पूर्वी रुकुम', 'RUE\r\n', 1),
(61, 5, 'RUKUM_W', 'पश्चिमी रुकुम', 'RUW\r\n', 1),
(62, 5, 'RUPANDEHI', 'रुपन्देही', 'RUP', 1),
(63, 6, 'SALYAN', 'सल्यान', 'SAL', 1),
(64, 1, 'SANKHUWASABHA', 'सङ्खुवासभा', 'SKU', 1),
(65, 2, 'SAPTARI', 'सप्तरी', 'SAP', 1),
(66, 2, 'SARLAHI', ' सर्लाही', 'SAR', 1),
(67, 3, 'SINDHULI', ' सिन्धुली', 'SIN', 1),
(68, 3, 'SINDHUPALCHOWK', 'सिन्धुपाल्चोक', 'SDP', 1),
(69, 2, 'SIRAHA', 'सिराहा', 'SIR', 1),
(70, 1, 'SOLUKHUMBU', 'सोलुखुम्बु', 'SOL', 1),
(71, 1, 'SUNSARI', 'सुनसरी', 'SUN', 1),
(72, 6, 'SURKHET', 'सुर्खेत', 'SUR', 1),
(73, 4, 'SYANGJA', 'स्याङ्जा', 'SYG', 1),
(74, 4, 'TANAHU', ' तनहुँ ', 'TAN', 1),
(75, 1, 'TAPLEJUNG', 'ताप्लेजुङ', 'TAP', 1),
(76, 1, 'TERHATHUM', 'तेह्रथुम', 'TER', 1),
(77, 1, 'UDAYAPUR', 'उदयपुर', 'UDA', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `PROVIENCE_REGION_ID` (`PROVIENCE_REGION_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `districts`
--
ALTER TABLE `districts`
  ADD CONSTRAINT `districts_ibfk_1` FOREIGN KEY (`PROVIENCE_REGION_ID`) REFERENCES `provinces` (`ID`) ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
