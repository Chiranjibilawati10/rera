<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddChatterFieldsToCategoreis extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('categories', function (Blueprint $table) {
            $table->integer('order')->default(1);
            $table->string('color')->nullable();
            $table->string('slug')->nullable();
            \DB::statement('ALTER TABLE `categories` MODIFY `name` VARCHAR(100) NULL;');
            \DB::statement('ALTER TABLE `categories` MODIFY `name_ne` VARCHAR(100) NULL;');
            \DB::statement('ALTER TABLE `categories` MODIFY `description_ne` TEXT NULL;');
            \DB::statement('ALTER TABLE `categories` MODIFY `description` TEXT NULL;');  
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('categories', function (Blueprint $table) {
            $table->dropColumn('order');
            $table->dropColumn('slug');
            $table->dropColumn('color');
            \DB::statement('ALTER TABLE `categories` MODIFY `name_ne` VARCHAR(100) NOT NULL;');
            \DB::statement('ALTER TABLE `categories` MODIFY `description_ne` TEXT NOT NULL;');
            \DB::statement('ALTER TABLE `categories` MODIFY `description` TEXT NOT NULL;');
            \DB::statement('ALTER TABLE `categories` MODIFY `name` VARCHAR(100) NOT NULL;');
        });
    }
}
