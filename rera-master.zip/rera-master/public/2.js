(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[2],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _assets_loader_gif__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../assets/loader.gif */ "./resources/js/frontend/assets/loader.gif");
/* harmony import */ var _assets_loader_gif__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_assets_loader_gif__WEBPACK_IMPORTED_MODULE_0__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  props: ['topic'],
  data: function data() {
    return {
      src: false,
      // document_format:['docx', 'docm', 'dotm', 'dotx','xlsx', 'xlsb', 'xls', 'xlsm','pptx','ppsx','ppt','pps', 'pptm','potm','ppam','potx','ppsm','pdf'],
      document_format: ['pptx', 'ppt', 'pdf'],
      audio_format: ['mp3', 'MP3'],
      video_format: ['mp4', 'MP4'],
      image_format: ['png', 'jpg', 'jpeg', 'gif', 'PNG', 'JPG', 'JPEG', 'GIF'],
      audio: false,
      video: false,
      error: false,
      image: false,
      download: false,
      disableClick: false
    };
  },
  methods: {
    showMessage: function showMessage() {
      if (!parseInt(localStorage.getItem("loggedIn"))) {
        if (this.download == '#') {
          this.$notify({
            title: '',
            text: 'Only registered user can download the content',
            type: 'error'
          });
          event.preventDefault();
        } else {
          event.preventDefault();
          window.location.reload();
        }
      } else {
        if (this.download == '#') {
          event.preventDefault();
          window.location.reload();
        }
      }
    },
    getVideo: function getVideo() {
      this.video = this.topic.files[0].location;
    },
    getAudio: function getAudio() {
      // if(parseInt(localStorage.getItem("loggedIn"))){
      this.audio = this.topic.files[0].location; // }
    },
    getDocument: function getDocument() {
      var size = this.topic.files[0].size;

      if (Number(size) > Number(10485760)) {
        return this.getDownload();
      } //this.src=this.topic.files[0].document;


      if (this.topic.files[0].extension === 'pdf') {
        // this.src="http://dristaging.ml/storage/documents/OudQlBBU7bAkIvRFRDBMAxfih2DTy2rJ1KSDkZXf.pdf#toolbar=0";
        if (parseInt(localStorage.getItem("loggedIn"))) {
          this.src = this.topic.files[0].location;
        } else {
          this.src = this.topic.files[0].location + '#toolbar=0';
          this.disableClick = true;
        }
      } else {
        return this.getDownload();
      }
    },
    getImage: function getImage() {
      // if(parseInt(localStorage.getItem("loggedIn"))){
      this.image = this.topic.files[0].location; // }
    },
    getDownload: function getDownload() {
      this.download = this.topic.files[0].document;
    },
    renderFile: function renderFile() {
      if (this.topic.files.length) {
        if (this.document_format.includes(this.topic.files[0].extension)) {
          return this.getDocument();
        }

        if (this.audio_format.includes(this.topic.files[0].extension)) {
          return this.getAudio();
        }

        if (this.video_format.includes(this.topic.files[0].extension)) {
          return this.getVideo();
        }

        if (this.image_format.includes(this.topic.files[0].extension)) {
          return this.getImage();
        }

        if (!(this.audio || this.video || this.src || this.image)) {
          return this.getDownload();
        }
      } else {
        return this.getDownload();
      }
    },
    disableRightClick: function disableRightClick() {
      if (!parseInt(localStorage.getItem("loggedIn"))) {
        window.addEventListener('contextmenu', function (e) {
          // do something here... 
          e.preventDefault();
        }, false);
      }
    }
  },
  mounted: function mounted() {
    this.renderFile();
    this.disableRightClick();
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Loading.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/components/Chapter/Loading.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_lazy_youtube_video_dist_style_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-lazy-youtube-video/dist/style.css */ "./node_modules/vue-lazy-youtube-video/dist/style.css");
/* harmony import */ var vue_lazy_youtube_video_dist_style_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vue_lazy_youtube_video_dist_style_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_lazy_youtube_video__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-lazy-youtube-video */ "./node_modules/vue-lazy-youtube-video/dist/vue-lazy-youtube-video.esm.js");
/* harmony import */ var _AyncIframe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./AyncIframe */ "./resources/js/frontend/components/Chapter/AyncIframe.vue");
/* harmony import */ var _Loading__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Loading */ "./resources/js/frontend/components/Chapter/Loading.vue");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  name: "Topic",
  components: {
    LazyYoutubeVideo: vue_lazy_youtube_video__WEBPACK_IMPORTED_MODULE_1__["default"],
    Loading: _Loading__WEBPACK_IMPORTED_MODULE_3__["default"],
    'AyncIframe': function AyncIframe() {
      return {
        component: Promise.resolve(/*! import() */).then(__webpack_require__.bind(null, /*! ./AyncIframe */ "./resources/js/frontend/components/Chapter/AyncIframe.vue")),
        loading: _Loading__WEBPACK_IMPORTED_MODULE_3__["default"],
        error: _Loading__WEBPACK_IMPORTED_MODULE_3__["default"],
        delay: 200,
        timeout: 3000
      };
    }
  },
  data: function data() {
    return {
      chapter: {},
      topics: {},
      count: 2,
      busy: false
    };
  },
  methods: {
    getChapterTopics: function getChapterTopics() {
      var _this = this;

      this.$Progress.start();
      window.axios.get("/chapter/topic?id=" + this.$route.params.chapterId + "&&chapter_slug=" + this.$route.params.chapter_slug).then(function (response) {
        if (response.data.error === false) {
          _this.chapter = response.data.data.chapter;
          _this.topics = response.data.data.topics.data;

          _this.$Progress.finish();
        } else {
          _this.$Progress.fail();
        }
      })["catch"](function (error) {
        return console.log(error);
      });
    },
    scroll: function scroll(data) {
      var _this2 = this;

      window.onscroll = function () {
        var bottomOfWindow = document.documentElement.scrollTop + window.innerHeight === document.documentElement.offsetHeight;

        if (bottomOfWindow) {
          _this2.busy = true;
          window.axios.get("/chapter/topic?id=" + _this2.$route.params.chapterId + "&&chapter_slug=" + _this2.$route.params.chapter_slug + "&&page=" + _this2.count).then(function (response) {
            if (response.data.error === false) {
              var _this2$topics;

              _this2.count = _this2.count + 1;

              (_this2$topics = _this2.topics).push.apply(_this2$topics, _toConsumableArray(response.data.data.topics.data)); //this.notices=response.data.data.notices;


              _this2.$Progress.finish();
            } else {
              _this2.$Progress.fail();
            }
          })["catch"](function (error) {
            return console.log(error);
          });
          _this2.busy = false;
        }
      };
    }
  },
  mounted: function mounted() {
    this.getChapterTopics();
    this.scroll(this.topics);
  },
  watch: {
    '$route': function $route() {
      this.getChapterTopics();
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=style&index=0&id=1e0175e6&scoped=true&lang=css&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--5-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--5-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=style&index=0&id=1e0175e6&scoped=true&lang=css& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n.about[data-v-1e0175e6]{\n\tdisplay: none !important;\n}\naudio[data-v-1e0175e6],video[data-v-1e0175e6],iframe[data-v-1e0175e6],img[data-v-1e0175e6]{\n\toutline: none !important;\n}\n.img-wrapper[data-v-1e0175e6]{\n\tposition: relative;\n\toverflow: hidden;\n}\n.embed-cover[data-v-1e0175e6] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  bottom: 0;\n  right: 0;\n  width: 711px;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=style&index=0&id=04b41fc3&scoped=true&lang=css&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--5-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--5-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=style&index=0&id=04b41fc3&scoped=true&lang=css& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n/* #file_box{\n  border-style:solid !important;\n }*/\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=style&index=0&id=1e0175e6&scoped=true&lang=css&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??ref--5-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--5-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=style&index=0&id=1e0175e6&scoped=true&lang=css& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js??ref--5-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--5-2!../../../../../node_modules/vue-loader/lib??vue-loader-options!./AyncIframe.vue?vue&type=style&index=0&id=1e0175e6&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=style&index=0&id=1e0175e6&scoped=true&lang=css&");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=style&index=0&id=04b41fc3&scoped=true&lang=css&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??ref--5-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--5-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=style&index=0&id=04b41fc3&scoped=true&lang=css& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js??ref--5-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--5-2!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Topic.vue?vue&type=style&index=0&id=04b41fc3&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=style&index=0&id=04b41fc3&scoped=true&lang=css&");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=template&id=1e0175e6&scoped=true&":
/*!******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=template&id=1e0175e6&scoped=true& ***!
  \******************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      directives: [
        {
          name: "lazy-container",
          rawName: "v-lazy-container",
          value: { selector: "img" },
          expression: "{ selector: 'img' }"
        }
      ],
      staticClass: "img-wrapper"
    },
    [
      _vm.src
        ? _c("div", { staticClass: "holds-the-iframe" }, [
            _c("iframe", {
              ref: "customIframe",
              staticClass: "presentation--img",
              attrs: {
                src: _vm.src,
                width: "100%",
                height: "418px",
                frameborder: "0"
              }
            })
          ])
        : _vm.audio
        ? _c(
            "audio",
            { attrs: { controls: "", width: "100%", height: "418px" } },
            [
              _c("source", {
                ref: "audio",
                attrs: { src: _vm.audio, type: "audio/mpeg" }
              }),
              _vm._v(
                "\n\t\t   Your browser does not support the audio element.\n\t\t"
              )
            ]
          )
        : _vm.video
        ? _c(
            "video",
            {
              attrs: {
                width: "100%",
                height: "418",
                controls: "",
                preload: "none"
              }
            },
            [
              _c("source", {
                ref: "video",
                attrs: { height: "50%", src: _vm.video, type: "video/mp4" }
              }),
              _vm._v(
                "\n\t\t   Your browser does not support the video tag.\n\t\t"
              )
            ]
          )
        : _vm.image
        ? _c("img", {
            staticClass: "img-fluid",
            attrs: { "data-src": _vm.image, width: "100%", height: "418px" }
          })
        : _vm._e(),
      _vm._v(" "),
      _vm.download
        ? _c("div", { staticStyle: { "margin-bottom": "30px" } }, [
            _c(
              "a",
              {
                staticClass: "btn btn-secondary btn-sm mr-2",
                attrs: { href: _vm.download, download: "" },
                on: {
                  click: function($event) {
                    return _vm.showMessage()
                  }
                }
              },
              [
                _vm._v("\n\t             Download File \n\t            "),
                _c("i", { staticClass: "ic-download" })
              ]
            )
          ])
        : _vm._e(),
      _vm._v(" "),
      _vm.disableClick ? _c("div", { staticClass: "embed-cover" }) : _vm._e()
    ]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Loading.vue?vue&type=template&id=19751360&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/components/Chapter/Loading.vue?vue&type=template&id=19751360& ***!
  \***************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("img", { attrs: { src: __webpack_require__(/*! ../../assets/loader.gif */ "./resources/js/frontend/assets/loader.gif") } })
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=template&id=04b41fc3&scoped=true&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=template&id=04b41fc3&scoped=true& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.chapter
    ? _c(
        "div",
        [
          _c(
            "div",
            {
              staticClass:
                "d-flex align-items-center justify-content-between mb-4"
            },
            [
              _c("h5", { staticClass: "text-primary" }, [
                _vm._v(_vm._s(_vm.chapter.chapter_name))
              ]),
              _vm._v(" "),
              _vm._m(0)
            ]
          ),
          _vm._v(" "),
          _c("p", {
            staticStyle: {
              "margin-bottom": "8px",
              "word-wrap": "break-word",
              "text-align": "justify"
            },
            domProps: { innerHTML: _vm._s(_vm.chapter.summary) }
          }),
          _vm._v(" "),
          _vm._l(_vm.topics, function(topic) {
            return _vm.topics.length
              ? _c(
                  "div",
                  { key: topic.id, staticClass: "presentation" },
                  [
                    _c("h6", { staticClass: "presentation--title" }, [
                      _vm._v(_vm._s(topic.title))
                    ]),
                    _vm._v(" "),
                    topic.files.length
                      ? _c("aync-iframe", {
                          ref: topic.id,
                          refInFor: true,
                          attrs: { topic: topic }
                        })
                      : _vm._e(),
                    _vm._v(" "),
                    topic.video
                      ? _c(
                          "div",
                          [
                            _c("LazyYoutubeVideo", {
                              attrs: {
                                src:
                                  "https://www.youtube.com/embed/" +
                                  topic.video +
                                  "?autoplay=0"
                              }
                            })
                          ],
                          1
                        )
                      : _vm._e(),
                    _vm._v(" "),
                    _c("p", {
                      staticStyle: { "margin-top": "18px" },
                      domProps: { innerHTML: _vm._s(topic.summary) }
                    }),
                    _vm._v(" "),
                    _vm.busy ? _c("div", [_c("loading")], 1) : _vm._e()
                  ],
                  1
                )
              : _vm._e()
          })
        ],
        2
      )
    : _vm._e()
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "d-block d-lg-none mb-3 mb-lg-0" }, [
      _c(
        "button",
        {
          staticClass: "btn btn-orange btn-sm text-dark",
          attrs: { id: "toggleChapter" }
        },
        [
          _vm._v("Chapter List "),
          _c("i", { staticClass: "ic-triangle-down ic-1x" })
        ]
      )
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/frontend/assets/loader.gif":
/*!*************************************************!*\
  !*** ./resources/js/frontend/assets/loader.gif ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/loader.gif?0c9c6ad8731aa0714a387382117bdb64";

/***/ }),

/***/ "./resources/js/frontend/components/Chapter/AyncIframe.vue":
/*!*****************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/AyncIframe.vue ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _AyncIframe_vue_vue_type_template_id_1e0175e6_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AyncIframe.vue?vue&type=template&id=1e0175e6&scoped=true& */ "./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=template&id=1e0175e6&scoped=true&");
/* harmony import */ var _AyncIframe_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AyncIframe.vue?vue&type=script&lang=js& */ "./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _AyncIframe_vue_vue_type_style_index_0_id_1e0175e6_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./AyncIframe.vue?vue&type=style&index=0&id=1e0175e6&scoped=true&lang=css& */ "./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=style&index=0&id=1e0175e6&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _AyncIframe_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _AyncIframe_vue_vue_type_template_id_1e0175e6_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _AyncIframe_vue_vue_type_template_id_1e0175e6_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "1e0175e6",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/frontend/components/Chapter/AyncIframe.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=script&lang=js&":
/*!******************************************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AyncIframe_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./AyncIframe.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AyncIframe_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=style&index=0&id=1e0175e6&scoped=true&lang=css&":
/*!**************************************************************************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=style&index=0&id=1e0175e6&scoped=true&lang=css& ***!
  \**************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AyncIframe_vue_vue_type_style_index_0_id_1e0175e6_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader/dist/cjs.js!../../../../../node_modules/css-loader/dist/cjs.js??ref--5-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--5-2!../../../../../node_modules/vue-loader/lib??vue-loader-options!./AyncIframe.vue?vue&type=style&index=0&id=1e0175e6&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=style&index=0&id=1e0175e6&scoped=true&lang=css&");
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AyncIframe_vue_vue_type_style_index_0_id_1e0175e6_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AyncIframe_vue_vue_type_style_index_0_id_1e0175e6_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AyncIframe_vue_vue_type_style_index_0_id_1e0175e6_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AyncIframe_vue_vue_type_style_index_0_id_1e0175e6_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AyncIframe_vue_vue_type_style_index_0_id_1e0175e6_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=template&id=1e0175e6&scoped=true&":
/*!************************************************************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=template&id=1e0175e6&scoped=true& ***!
  \************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AyncIframe_vue_vue_type_template_id_1e0175e6_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./AyncIframe.vue?vue&type=template&id=1e0175e6&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/AyncIframe.vue?vue&type=template&id=1e0175e6&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AyncIframe_vue_vue_type_template_id_1e0175e6_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AyncIframe_vue_vue_type_template_id_1e0175e6_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/frontend/components/Chapter/Loading.vue":
/*!**************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/Loading.vue ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Loading_vue_vue_type_template_id_19751360___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Loading.vue?vue&type=template&id=19751360& */ "./resources/js/frontend/components/Chapter/Loading.vue?vue&type=template&id=19751360&");
/* harmony import */ var _Loading_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Loading.vue?vue&type=script&lang=js& */ "./resources/js/frontend/components/Chapter/Loading.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Loading_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Loading_vue_vue_type_template_id_19751360___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Loading_vue_vue_type_template_id_19751360___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/frontend/components/Chapter/Loading.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/frontend/components/Chapter/Loading.vue?vue&type=script&lang=js&":
/*!***************************************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/Loading.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Loading_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Loading.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Loading.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Loading_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/frontend/components/Chapter/Loading.vue?vue&type=template&id=19751360&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/Loading.vue?vue&type=template&id=19751360& ***!
  \*********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Loading_vue_vue_type_template_id_19751360___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Loading.vue?vue&type=template&id=19751360& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Loading.vue?vue&type=template&id=19751360&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Loading_vue_vue_type_template_id_19751360___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Loading_vue_vue_type_template_id_19751360___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/frontend/components/Chapter/Topic.vue":
/*!************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/Topic.vue ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Topic_vue_vue_type_template_id_04b41fc3_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Topic.vue?vue&type=template&id=04b41fc3&scoped=true& */ "./resources/js/frontend/components/Chapter/Topic.vue?vue&type=template&id=04b41fc3&scoped=true&");
/* harmony import */ var _Topic_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Topic.vue?vue&type=script&lang=js& */ "./resources/js/frontend/components/Chapter/Topic.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Topic_vue_vue_type_style_index_0_id_04b41fc3_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Topic.vue?vue&type=style&index=0&id=04b41fc3&scoped=true&lang=css& */ "./resources/js/frontend/components/Chapter/Topic.vue?vue&type=style&index=0&id=04b41fc3&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Topic_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Topic_vue_vue_type_template_id_04b41fc3_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Topic_vue_vue_type_template_id_04b41fc3_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "04b41fc3",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/frontend/components/Chapter/Topic.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/frontend/components/Chapter/Topic.vue?vue&type=script&lang=js&":
/*!*************************************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/Topic.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Topic_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Topic.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Topic_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/frontend/components/Chapter/Topic.vue?vue&type=style&index=0&id=04b41fc3&scoped=true&lang=css&":
/*!*********************************************************************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/Topic.vue?vue&type=style&index=0&id=04b41fc3&scoped=true&lang=css& ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Topic_vue_vue_type_style_index_0_id_04b41fc3_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader/dist/cjs.js!../../../../../node_modules/css-loader/dist/cjs.js??ref--5-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--5-2!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Topic.vue?vue&type=style&index=0&id=04b41fc3&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=style&index=0&id=04b41fc3&scoped=true&lang=css&");
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Topic_vue_vue_type_style_index_0_id_04b41fc3_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Topic_vue_vue_type_style_index_0_id_04b41fc3_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Topic_vue_vue_type_style_index_0_id_04b41fc3_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Topic_vue_vue_type_style_index_0_id_04b41fc3_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Topic_vue_vue_type_style_index_0_id_04b41fc3_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/frontend/components/Chapter/Topic.vue?vue&type=template&id=04b41fc3&scoped=true&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/Topic.vue?vue&type=template&id=04b41fc3&scoped=true& ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Topic_vue_vue_type_template_id_04b41fc3_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Topic.vue?vue&type=template&id=04b41fc3&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=template&id=04b41fc3&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Topic_vue_vue_type_template_id_04b41fc3_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Topic_vue_vue_type_template_id_04b41fc3_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);