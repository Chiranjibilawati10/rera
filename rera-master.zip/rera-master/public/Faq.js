(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[5],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Faq/Faq.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/components/Faq/Faq.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_lazy_youtube_video_dist_style_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-lazy-youtube-video/dist/style.css */ "./node_modules/vue-lazy-youtube-video/dist/style.css");
/* harmony import */ var vue_lazy_youtube_video_dist_style_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vue_lazy_youtube_video_dist_style_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_lazy_youtube_video__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-lazy-youtube-video */ "./node_modules/vue-lazy-youtube-video/dist/vue-lazy-youtube-video.esm.js");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  name: "Faq",
  components: {
    LazyYoutubeVideo: vue_lazy_youtube_video__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    return {
      category: {},
      faqs: {},
      count: 2,
      busy: false
    };
  },
  methods: {
    getFaqs: function getFaqs() {
      var _this = this;

      this.$Progress.start();
      window.axios.get("faqs?id=" + this.$route.params.categoryId).then(function (response) {
        if (response.data.error === false) {
          _this.category = response.data.data.category;
          _this.faqs = response.data.data.faqs.data;

          _this.$Progress.finish();
        } else {
          _this.$Progress.fail();
        }
      })["catch"](function (error) {
        return console.log(error);
      });
    },
    scroll: function scroll(data) {
      var _this2 = this;

      window.onscroll = function () {
        var bottomOfWindow = document.documentElement.scrollTop + window.innerHeight === document.documentElement.offsetHeight;

        if (bottomOfWindow) {
          _this2.busy = true;
          window.axios.get("faqs?id=" + _this2.$route.params.categoryId + "&&page=" + _this2.count).then(function (response) {
            if (response.data.error === false) {
              var _this2$faqs;

              _this2.count = _this2.count + 1;

              (_this2$faqs = _this2.faqs).push.apply(_this2$faqs, _toConsumableArray(response.data.data.faqs.data)); //this.notices=response.data.data.notices;


              _this2.$Progress.finish();
            } else {
              _this2.$Progress.fail();
            }
          })["catch"](function (error) {
            return console.log(error);
          });
          _this2.busy = false;
        }
      };
    }
  },
  mounted: function mounted() {
    this.getFaqs();
    this.scroll(this.faqs);
  },
  watch: {
    '$route': function $route() {
      this.getFaqs();
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Faq/Faq.vue?vue&type=template&id=6f6755f3&":
/*!*******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/components/Faq/Faq.vue?vue&type=template&id=6f6755f3& ***!
  \*******************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.category
    ? _c(
        "div",
        [
          _vm._l(_vm.faqs, function(faq) {
            return _c("div", { key: faq.id, staticClass: "card" }, [
              _c(
                "div",
                {
                  staticClass: "card-header",
                  attrs: { id: "heading" + faq.id }
                },
                [
                  _c("h2", { staticClass: "mb-0" }, [
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-link collapsed",
                        attrs: {
                          type: "button",
                          "data-toggle": "collapse",
                          "data-target": "#collapse" + faq.id,
                          "aria-expanded": "false",
                          "aria-controls": "collapse" + faq.id
                        }
                      },
                      [
                        _c("span", { staticClass: "ic-question" }),
                        _vm._v(" "),
                        _c("span", { staticClass: "title" }, [
                          _vm._v(
                            "\r\n              " +
                              _vm._s(faq.question) +
                              "\r\n            "
                          )
                        ])
                      ]
                    )
                  ])
                ]
              ),
              _vm._v(" "),
              _c(
                "div",
                {
                  staticClass: "collapse",
                  attrs: {
                    id: "collapse" + faq.id,
                    "aria-labelledby": "heading" + faq.id,
                    "data-parent": "#accordionExample"
                  }
                },
                [
                  _c("div", { staticClass: "card-body" }, [
                    _vm._v("\r\n        " + _vm._s(faq.answer) + "\r\n      ")
                  ])
                ]
              )
            ])
          }),
          _vm._v(" "),
          _vm.busy
            ? _c("div", [_vm._v("\r\n        Loading...\r\n    ")])
            : _vm._e()
        ],
        2
      )
    : _vm._e()
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/frontend/components/Faq/Faq.vue":
/*!******************************************************!*\
  !*** ./resources/js/frontend/components/Faq/Faq.vue ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Faq_vue_vue_type_template_id_6f6755f3___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Faq.vue?vue&type=template&id=6f6755f3& */ "./resources/js/frontend/components/Faq/Faq.vue?vue&type=template&id=6f6755f3&");
/* harmony import */ var _Faq_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Faq.vue?vue&type=script&lang=js& */ "./resources/js/frontend/components/Faq/Faq.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Faq_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Faq_vue_vue_type_template_id_6f6755f3___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Faq_vue_vue_type_template_id_6f6755f3___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/frontend/components/Faq/Faq.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/frontend/components/Faq/Faq.vue?vue&type=script&lang=js&":
/*!*******************************************************************************!*\
  !*** ./resources/js/frontend/components/Faq/Faq.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Faq_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Faq.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Faq/Faq.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Faq_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/frontend/components/Faq/Faq.vue?vue&type=template&id=6f6755f3&":
/*!*************************************************************************************!*\
  !*** ./resources/js/frontend/components/Faq/Faq.vue?vue&type=template&id=6f6755f3& ***!
  \*************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Faq_vue_vue_type_template_id_6f6755f3___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Faq.vue?vue&type=template&id=6f6755f3& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Faq/Faq.vue?vue&type=template&id=6f6755f3&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Faq_vue_vue_type_template_id_6f6755f3___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Faq_vue_vue_type_template_id_6f6755f3___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);