(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[2],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Chapters.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/components/Chapter/Chapters.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  name: "Chapters",
  data: function data() {
    return {
      chapters: {}
    };
  },
  methods: {
    getChapters: function getChapters() {
      var _this = this;

      this.$Progress.start();
      window.axios.get("/chapters").then(function (response) {
        if (response.data.error === false) {
          _this.chapters = response.data.data.chapters; //this.notices=response.data.data.notices;

          _this.$Progress.finish();
        } else {
          _this.$Progress.fail();
        }
      })["catch"](function (error) {
        return console.log(error);
      });
    }
  },
  mounted: function mounted() {
    this.getChapters();
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Chapters.vue?vue&type=template&id=7bb6c73c&":
/*!****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/components/Chapter/Chapters.vue?vue&type=template&id=7bb6c73c& ***!
  \****************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("section", { staticClass: "presentation--section" }, [
      _c("div", { staticClass: "container" }, [
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col-lg-4" }, [
            _c("aside", { staticClass: "aside--menu " }, [
              _vm._m(0),
              _vm._v(" "),
              _c(
                "ul",
                { staticClass: "aside__navigation" },
                _vm._l(_vm.chapters, function(chapter, index) {
                  return _c(
                    "li",
                    { key: chapter.id },
                    [
                      _c(
                        "router-link",
                        {
                          attrs: {
                            to: {
                              name: "chapter.topic",
                              params: { chapterId: chapter.id }
                            },
                            role: "button",
                            "aria-expanded": "false"
                          }
                        },
                        [
                          _vm._v(
                            "Ch " +
                              _vm._s(++index) +
                              " - " +
                              _vm._s(chapter.chapter_name)
                          )
                        ]
                      )
                    ],
                    1
                  )
                }),
                0
              )
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-lg-8" }, [_c("router-view")], 1)
        ])
      ])
    ])
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      { staticClass: "d-flex justify-content-between align-items-center mb-4" },
      [
        _c("h6", { staticClass: "aside--title" }, [
          _vm._v("RE Knowledge Platform")
        ]),
        _vm._v(" "),
        _c("i", { staticClass: "ic-close aside--close" })
      ]
    )
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/frontend/components/Chapter/Chapters.vue":
/*!***************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/Chapters.vue ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Chapters_vue_vue_type_template_id_7bb6c73c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Chapters.vue?vue&type=template&id=7bb6c73c& */ "./resources/js/frontend/components/Chapter/Chapters.vue?vue&type=template&id=7bb6c73c&");
/* harmony import */ var _Chapters_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Chapters.vue?vue&type=script&lang=js& */ "./resources/js/frontend/components/Chapter/Chapters.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Chapters_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Chapters_vue_vue_type_template_id_7bb6c73c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Chapters_vue_vue_type_template_id_7bb6c73c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/frontend/components/Chapter/Chapters.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/frontend/components/Chapter/Chapters.vue?vue&type=script&lang=js&":
/*!****************************************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/Chapters.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Chapters_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Chapters.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Chapters.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Chapters_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/frontend/components/Chapter/Chapters.vue?vue&type=template&id=7bb6c73c&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/Chapters.vue?vue&type=template&id=7bb6c73c& ***!
  \**********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Chapters_vue_vue_type_template_id_7bb6c73c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Chapters.vue?vue&type=template&id=7bb6c73c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Chapters.vue?vue&type=template&id=7bb6c73c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Chapters_vue_vue_type_template_id_7bb6c73c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Chapters_vue_vue_type_template_id_7bb6c73c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);