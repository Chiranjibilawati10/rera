(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[0],{

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-lazy-youtube-video/dist/style.css":
/*!********************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--5-1!./node_modules/postcss-loader/src??ref--5-2!./node_modules/vue-lazy-youtube-video/dist/style.css ***!
  \********************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ":root {\r\n  --y-video-background-color: #000;\r\n  --y-video-button-width: 68px;\r\n  --y-video-button-height: 48px;\r\n  --y-video-button-padding: 0;\r\n  --y-video-button-border-width: 0;\r\n  --y-video-button-background-color: transparent;\r\n  --y-video-button-fill: #212121;\r\n  --y-video-button-fill-opacity: 0.8;\r\n  --y-video-button-active-fill: red;\r\n  --y-video-button-active-fill-opacity: 1;\r\n  --y-video-button-icon-fill: #fff;\r\n}\r\n\r\n.y-video {\r\n  background-color: var(--y-video-background-color, #000);\r\n  cursor: pointer;\r\n}\r\n\r\n.y-video__inner {\r\n  position: relative;\r\n}\r\n\r\n.y-video__embed,\r\n.y-video__media {\r\n  position: absolute;\r\n  top: 0;\r\n  left: 0;\r\n  width: 100%;\r\n  height: 100%;\r\n  border-width: 0;\r\n}\r\n\r\n.y-video__media--type--img {\r\n  object-fit: cover;\r\n}\r\n\r\n.y-video__button {\r\n  position: absolute;\r\n  top: 50%;\r\n  left: 50%;\r\n  transform: translate(-50%, -50%);\r\n  padding: var(--y-video-button-padding, 0);\r\n  border-width: var(--y-video-button-border-width, 0);\r\n  background-color: var(--y-video-button-background-color, transparent);\r\n  width: var(--y-video-button-width, 68px);\r\n  height: var(--y-video-button-height, 48px);\r\n  cursor: pointer;\r\n}\r\n\r\n.y-video__button-shape {\r\n  fill: var(--y-video-button-fill, #212121);\r\n  fill-opacity: var(--y-video-button-fill-opacity, 0.8);\r\n}\r\n\r\n.y-video__button-icon {\r\n  fill: var(--y-video-button-icon-fill, #fff);\r\n}\r\n\r\n.y-video__button:focus {\r\n  outline: 0;\r\n}\r\n\r\n.y-video__button:focus .y-video__button-shape {\r\n  fill: var(--y-video-button-active-fill, red);\r\n  fill-opacity: var(--y-video-button-active-fill-opacity, 1);\r\n}\r\n\r\n.y-video:hover .y-video__button-shape {\r\n  fill: var(--y-video-button-active-fill, red);\r\n  fill-opacity: var(--y-video-button-active-fill-opacity, 1);\r\n}\r\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-lazy-youtube-video/dist/style.css":
/*!************************************************************!*\
  !*** ./node_modules/vue-lazy-youtube-video/dist/style.css ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../css-loader/dist/cjs.js??ref--5-1!../../postcss-loader/src??ref--5-2!./style.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-lazy-youtube-video/dist/style.css");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./node_modules/vue-lazy-youtube-video/dist/vue-lazy-youtube-video.esm.js":
/*!********************************************************************************!*\
  !*** ./node_modules/vue-lazy-youtube-video/dist/vue-lazy-youtube-video.esm.js ***!
  \********************************************************************************/
/*! exports provided: default, Plugin */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Plugin", function() { return Plugin; });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.common.js");
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vue__WEBPACK_IMPORTED_MODULE_0__);


/**
 * @see https://stackoverflow.com/a/30867255/11761617
 */
function startsWith(string, value, position = 0) {
    return string.indexOf(value, position) === position;
}

const component = vue__WEBPACK_IMPORTED_MODULE_0___default.a.extend({
    name: 'VueLazyYoutubeVideo',
    props: {
        src: {
            type: String,
            required: true,
            validator: value => startsWith(value, 'https://www.youtube.com/embed/') ||
                startsWith(value, 'https://www.youtube-nocookie.com/embed/'),
        },
        alt: {
            type: String,
            default: 'Video thumbnail',
        },
        buttonLabel: {
            type: String,
            default: 'Play video',
        },
        aspectRatio: {
            type: String,
            default: '16:9',
            validator: value => {
                const pattern = /^\d+:\d+$/;
                return pattern.test(value);
            },
        },
        previewImageSize: {
            type: String,
            default: 'maxresdefault',
            validator: value => [
                'default',
                'mqdefault',
                'sddefault',
                'hqdefault',
                'maxresdefault',
            ].indexOf(value) !== -1,
        },
        thumbnail: {
            type: Object,
            validator: val => 'jpg' in val && 'webp' in val,
        },
        iframeAttributes: {
            type: Object,
            default: () => ({
                allowfullscreen: true,
                frameborder: 0,
                allow: 'accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture',
            }),
        },
        webp: {
            type: Boolean,
            default: true,
        },
        autoplay: {
            type: Boolean,
            default: false,
        },
        thumbnailListeners: {
            type: Object,
        },
    },
    data() {
        const self = this;
        return {
            activated: self.autoplay,
        };
    },
    computed: {
        id() {
            const regExp = /^https:\/\/www\.youtube(?:-nocookie)?\.com\/embed\/(.+?)(?:\?.*)?$/;
            const executionResult = regExp.exec(this.src);
            if (executionResult !== null) {
                return executionResult[1];
            }
            else {
                this.warn(`Failed to extract video id from ${this.src}`);
                return '';
            }
        },
        srcAttribute() {
            const hasQuestionMark = typeof this.src === 'string' && this.src.indexOf('?') !== -1;
            return `${this.src}${hasQuestionMark ? '&' : '?'}autoplay=1`;
        },
        styleObj() {
            return {
                paddingBottom: this.getPaddingBottom(),
            };
        },
    },
    methods: {
        clickHandler() {
            this.activated = true;
        },
        getPaddingBottom() {
            let { aspectRatio } = this;
            // Vue does not provide correct typescript support
            // @ts-ignore
            const defaultAspectRatio = this.$options.props.aspectRatio.default;
            const warningMessage = `Invalid value ${aspectRatio} supplied to \`aspectRatio\` property, instead fallback value ${defaultAspectRatio} is used `;
            if (typeof aspectRatio === 'string') {
                const [a, b] = aspectRatio.split(':').map(Number);
                if (isFinite(a) === true && isFinite(b) === true) ;
                else {
                    aspectRatio = defaultAspectRatio;
                    this.warn(warningMessage);
                }
            }
            else {
                aspectRatio = defaultAspectRatio;
                this.warn(warningMessage);
            }
            const [a, b] = aspectRatio.split(':').map(Number);
            return this.getPaddingBottomValue(a, b);
        },
        getPaddingBottomValue(a, b) {
            return `${(b / a) * 100}%`;
        },
        warn(message) {
            console.warn(`[vue-lazy-youtube-video]: ${message}`);
        },
    },
    render(h) {
        const { alt, buttonLabel, previewImageSize, thumbnail, iframeAttributes, webp, activated, id, srcAttribute, styleObj, } = this;
        return h('div', {
            staticClass: 'y-video',
            on: { click: () => this.clickHandler() },
        }, [
            h('div', { staticClass: 'y-video__inner', style: styleObj }, [
                activated
                    ? h('iframe', {
                        staticClass: 'y-video__media',
                        attrs: { ...iframeAttributes, src: srcAttribute },
                    })
                    : [
                        h('picture', {}, [
                            webp
                                ? h('source', {
                                    attrs: {
                                        srcset: (thumbnail && thumbnail.webp) ||
                                            `https://i.ytimg.com/vi_webp/${id}/${previewImageSize}.webp`,
                                        type: 'image/webp',
                                    },
                                })
                                : null,
                            h('img', {
                                staticClass: 'y-video__media y-video__media--type--img',
                                attrs: {
                                    src: (thumbnail && thumbnail.jpg) ||
                                        `https://i.ytimg.com/vi/${id}/${previewImageSize}.jpg`,
                                    alt,
                                },
                                on: this.thumbnailListeners,
                            }),
                        ]),
                        this.$slots.button ||
                            h('button', {
                                staticClass: 'y-video__button',
                                attrs: { type: 'button', 'aria-label': buttonLabel },
                            }, [
                                this.$slots.icon ||
                                    h('svg', {
                                        attrs: {
                                            viewBox: '0 0 68 48',
                                            width: '100%',
                                            height: '100%',
                                        },
                                    }, [
                                        h('path', {
                                            staticClass: 'y-video__button-shape',
                                            attrs: {
                                                d: 'M66.5 7.7c-.8-2.9-2.5-5.4-5.4-6.2C55.8.1 34 0 34 0S12.2.1 6.9 1.6c-3 .7-4.6 3.2-5.4 6.1a89.6 89.6 0 0 0 0 32.5c.8 3 2.5 5.5 5.4 6.3C12.2 47.9 34 48 34 48s21.8-.1 27.1-1.6c3-.7 4.6-3.2 5.4-6.1C68 35 68 24 68 24s0-11-1.5-16.3z',
                                            },
                                        }),
                                        h('path', {
                                            staticClass: 'y-video__button-icon',
                                            attrs: { d: 'M45 24L27 14v20' },
                                        }),
                                    ]),
                            ]),
                    ],
            ]),
        ]);
    },
});

const Plugin = {
    install(Vue) {
        Vue.component('LazyYoutubeVideo', component);
    },
};

/* harmony default export */ __webpack_exports__["default"] = (component);



/***/ })

}]);