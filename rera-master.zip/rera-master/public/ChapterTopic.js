(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[3],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_lazy_youtube_video_dist_style_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-lazy-youtube-video/dist/style.css */ "./node_modules/vue-lazy-youtube-video/dist/style.css");
/* harmony import */ var vue_lazy_youtube_video_dist_style_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vue_lazy_youtube_video_dist_style_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_lazy_youtube_video__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-lazy-youtube-video */ "./node_modules/vue-lazy-youtube-video/dist/vue-lazy-youtube-video.esm.js");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  name: "Topic",
  components: {
    LazyYoutubeVideo: vue_lazy_youtube_video__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    return {
      chapter: {},
      topics: {},
      count: 2,
      busy: false
    };
  },
  methods: {
    getChapterTopics: function getChapterTopics() {
      var _this = this;

      this.$Progress.start();
      window.axios.get("/chapter/topic?id=" + this.$route.params.chapterId).then(function (response) {
        if (response.data.error === false) {
          _this.chapter = response.data.data.chapter;
          _this.topics = response.data.data.topics.data;

          _this.$Progress.finish();
        } else {
          _this.$Progress.fail();
        }
      })["catch"](function (error) {
        return console.log(error);
      });
    },
    scroll: function scroll(data) {
      var _this2 = this;

      window.onscroll = function () {
        var bottomOfWindow = document.documentElement.scrollTop + window.innerHeight === document.documentElement.offsetHeight;

        if (bottomOfWindow) {
          _this2.busy = true;
          window.axios.get("/chapter/topic?id=" + _this2.$route.params.chapterId + "&&page=" + _this2.count).then(function (response) {
            if (response.data.error === false) {
              var _this2$topics;

              _this2.count = _this2.count + 1;

              (_this2$topics = _this2.topics).push.apply(_this2$topics, _toConsumableArray(response.data.data.topics.data)); //this.notices=response.data.data.notices;


              _this2.$Progress.finish();
            } else {
              _this2.$Progress.fail();
            }
          })["catch"](function (error) {
            return console.log(error);
          });
          _this2.busy = false;
        }
      };
    }
  },
  mounted: function mounted() {
    this.getChapterTopics();
    this.scroll(this.topics);
  },
  watch: {
    '$route': function $route() {
      this.getChapterTopics();
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=template&id=04b41fc3&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=template&id=04b41fc3& ***!
  \*************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.chapter
    ? _c(
        "div",
        [
          _c(
            "div",
            {
              staticClass:
                "d-flex align-items-center justify-content-between mb-4"
            },
            [
              _c("h5", { staticClass: "text-primary" }, [
                _vm._v(_vm._s(_vm.chapter.chapter_name))
              ]),
              _vm._v(" "),
              _vm._m(0)
            ]
          ),
          _vm._v(" "),
          _vm._l(_vm.topics, function(topic) {
            return _c(
              "div",
              { key: topic.id, staticClass: "presentation" },
              [
                _c(
                  "router-link",
                  {
                    attrs: { to: { name: "topic", params: { id: topic.id } } }
                  },
                  [
                    _c("h6", { staticClass: "presentation--title" }, [
                      _vm._v(_vm._s(topic.title))
                    ])
                  ]
                ),
                _vm._v(" "),
                _c("LazyYoutubeVideo", {
                  attrs: {
                    src:
                      "https://www.youtube.com/embed/" +
                      topic.video +
                      "?autoplay=0"
                  }
                }),
                _vm._v(" "),
                _vm.busy
                  ? _c("div", [_vm._v("\n            Loading...\n        ")])
                  : _vm._e()
              ],
              1
            )
          })
        ],
        2
      )
    : _vm._e()
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "d-block d-lg-none mb-3 mb-lg-0" }, [
      _c(
        "button",
        {
          staticClass: "btn btn-orange btn-sm text-dark",
          attrs: { id: "toggleChapter" }
        },
        [
          _vm._v("Chapter List "),
          _c("i", { staticClass: "ic-triangle-down ic-1x" })
        ]
      )
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/frontend/components/Chapter/Topic.vue":
/*!************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/Topic.vue ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Topic_vue_vue_type_template_id_04b41fc3___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Topic.vue?vue&type=template&id=04b41fc3& */ "./resources/js/frontend/components/Chapter/Topic.vue?vue&type=template&id=04b41fc3&");
/* harmony import */ var _Topic_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Topic.vue?vue&type=script&lang=js& */ "./resources/js/frontend/components/Chapter/Topic.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Topic_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Topic_vue_vue_type_template_id_04b41fc3___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Topic_vue_vue_type_template_id_04b41fc3___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/frontend/components/Chapter/Topic.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/frontend/components/Chapter/Topic.vue?vue&type=script&lang=js&":
/*!*************************************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/Topic.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Topic_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Topic.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Topic_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/frontend/components/Chapter/Topic.vue?vue&type=template&id=04b41fc3&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/frontend/components/Chapter/Topic.vue?vue&type=template&id=04b41fc3& ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Topic_vue_vue_type_template_id_04b41fc3___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Topic.vue?vue&type=template&id=04b41fc3& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/components/Chapter/Topic.vue?vue&type=template&id=04b41fc3&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Topic_vue_vue_type_template_id_04b41fc3___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Topic_vue_vue_type_template_id_04b41fc3___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);