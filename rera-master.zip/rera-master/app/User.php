<?php

namespace App;

use App\Model\Auth\AuthGroup;
use App\Model\Auth\AuthPermissionGroup;
use App\Model\Auth\AuthUserPermissionGroup;
use Laravel\Passport\HasApiTokens;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Model\Region\Municipality;
use App\Model\Occupation\OccupationProfession;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Tools\FileTrait;


class User extends Authenticatable implements MustVerifyEmail
{
    use HasApiTokens, Notifiable,softDeletes,FileTrait;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password','username','phone','profession_id','municipality_id','is_super','country','address',
        'user_type'
    ];

    protected $appends = array('gravatar');

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function authGroup()
    {
        return $this->hasMany(AuthUserPermissionGroup::class, 'USER_ID');
    }

    public function isSuperUser()
    {
        if ($this->is_super == 1){
            return true;
        }
    }

    public function hasAccess($permissions)
    {
        $userPermissions = $this->getUserPermission();
        if (in_array($permissions,$userPermissions)){
            return true;
        }
        return false;
    }

    public function getUserPermission()
    {
        $perm = array();
        $assignedGroup = AuthUserPermissionGroup::where('USER_ID', $this->id)->get();
        foreach($assignedGroup as $value){
            $permission = AuthPermissionGroup::where('GROUP_ID',$value->GROUP_ID)->with('permission')->get();
            foreach ($permission as $val){
                $perm[] = $val->permission->CODE;
            }
        }
        return $perm;
    }

    public function profession()
    {
       return $this->belongsTo(OccupationProfession::class,'profession_id');
    }

    public function municipality()
    {
        return $this->belongsTo(Municipality::class,'municipality_id');
       
    }

    /**
     * Get gravatar url.
     *
     * @param int    $size
     * @param string $default
     * @param string $rating
     *
     * @return string
     */
    public function getGravatarAttribute($size = 60, $default = 'mm', $rating = 'g')
    {
        $email = $this->email;

        return 'http://www.gravatar.com/avatar/'.md5(strtolower(trim($email)))."?s={$size}&d={$default}&r={$rating}";
    }


}
