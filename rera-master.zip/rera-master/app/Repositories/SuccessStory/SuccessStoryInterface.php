<?php


namespace App\Repositories\SuccessStory;


use App\Repositories\BaseRepositoryInterface;

interface SuccessStoryInterface extends BaseRepositoryInterface
{

}
