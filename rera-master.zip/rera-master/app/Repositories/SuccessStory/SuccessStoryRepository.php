<?php


namespace App\Repositories\SuccessStory;

use App\Repositories\BaseRepository;
use App\Model\SuccessStory\SuccessStory;
use App\Tools\Response;
use App\Tools\ImageUploader;
use Symfony\Component\Process\Exception\ProcessFailedException;
use Symfony\Component\Process\Process;


class SuccessStoryRepository extends BaseRepository implements SuccessStoryInterface
{
    use ImageUploader;
    /**
     * CompanyRepository constructor.
     *
     * @param Company $company
     */
    public function __construct(SuccessStory $model)
    {
        parent::__construct($model);
    }

    public function getData()
    {
        try {
            $data['records'] = $this->query()
                                    ->with('createdBy','updatedBy')
                                    ->get();
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function storeEntry($request)
    {
        try {
            $request['created_id']=auth()->user()->id;
            $record=$this->create($request);
            // $this->uploadSingleFile($request,$record);
            $this->uploadMultipleFile($request,$record);
            $returnData = Response::prepare(false, 'Record Created Successfully', [], []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function getEntry($id)
    {
        try {
            $data['record'] =$this->first([
                                ['id', '=', $id],
                            ])->load('files');
            $returnData = Response::prepare(false, 'edit_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function updateEntry($request, $id)
    {
        try {
            $request['updated_id']=auth()->user()->id;
            $entry=$this->update($request, $id);
        
            if ($request->file) {
                // return $this->makeSlideImage($request->file[0]);
                //$this->deleteMultipleUpload($entry);
                $this->uploadMultipleFile($request,$entry);
            }
            $returnData = Response::prepare(false, 'Record Updated Successfully', [], []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function deleteEntry($id)
    {
        try {
            $this->delete($id);
            $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    // public function makeSlideImage($file)
    // {
    //     $powerpnt = new \com('powerpoint.application') or die("Unable to instantiate Powerpoint");
    //     $presentation = $powerpnt->Presentations->Open(realpath($file), false, false, false) or die("Unable to open the slide");
    //             $i=1;

    //     foreach($presentation->Slides as $key=>$slide)
    //     {
    //         $slideName =  $key."_SS_";
    //         // $exportFolder = realpath("Your folder path");
    //         //$exportFolder = realpath("Your folder path");
    //         $exportFolder = public_path('slides');
    //         $slide->Export($exportFolder."\\"."previews/".$slideName.".jpg", "jpg");
    //         $powerpnt->Presentations[1]->Close();
    //         $powerpnt->quit();
    //     }
    // }

    public function makeSlideImage($file)
    {
        try{
            // $process = new Process(['soffice --headless --convert-to pdf 2_summary-for-constitutional-framework-2967483741586789487.docx', '/var/www/html/hamropos/storage/app/public/uploads']);
            // $directory='/var/www/html/hamropos/storage/app/public/uploads';
            // $process = new Process('cd '.$directory.' && soffice --headless --convert-to pdf 2_summary-for-constitutional-framework-2967483741586789487.docx');
            $process = new Process('soffice --headless --convert-to pdf 1.pptx', storage_path() . '/app/public/uploads/');
           
            $process->mustRun();
            if ($process->isSuccessful()) {
                $process_pdf = new Process('gs -sDEVICE=pngalpha -o slajd-%02d.png -r96 1.pdf', storage_path() . '/app/public/uploads/');
                $process_pdf->mustRun(); 
            }else{
                throw new ProcessFailedException($process);
            }
            if ($process_pdf->isSuccessful()) {
                return $process_pdf->getOutput();
            }else{
                throw new ProcessFailedException($process_pdf);
            }
            } catch (ProcessFailedException $exception) {
                return $exception->getMessage();
            }
    }
}
