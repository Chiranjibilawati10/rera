<?php


namespace App\Repositories;


use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Tools\Response;


class BaseRepository implements BaseRepositoryInterface
{

    /**
     * Model for which the repository is provided.
     */
    protected $model;

    /**
     * BaseService constructor.
     *
     * @param Model $model
     */
    public function __construct(Model $model)
    {
        $this->model = $model;
    }

    /**
     * Get the query instance for the model.
     *
     * @return mixed
     */
    public function query()
    {
        return $this->model::query();
    }

    /**
     * Fetch all the records from the database.
     *
     * @param string $order
     * @param string $orderColumn
     */
    public function all(string $order = 'desc', string $orderColumn = 'id')
    {
        return $this->model->orderBy($orderColumn, $order)->get();
    }

    /**
     * Fetch all the records from database with their related models.
     *
     * @param array $relations
     * @param string $order
     * @param string $orderColumn
     * @return mixed
     */
    public function allWithRelation(array $relations = [], string $order = 'desc', string $orderColumn = 'id')
    {
        return $this->model->with($relations)->orderBy($orderColumn, $order)->get();
    }

    /**
     * Fetch all the records from database with pagination.
     *
     * @param int $pageSize
     * @param string $order
     * @param string $orderColumn
     * @return mixed
     */
    public function allWithPagination(int $pageSize = 5, string $order = 'desc', string $orderColumn = 'id')
    {
        return $this->model->orderBy($orderColumn, $order)->paginate($pageSize);
    }

    /**
     * Fetch all the records from database with related models and pagination.
     *
     * @param array $relations
     * @param int $pageSize
     * @param string $order
     * @param string $orderColumn
     * @return mixed
     */
    public function allWithRelationAndPagination(array $relations = [], int $pageSize = 5, string $order = 'desc', string $orderColumn = 'id')
    {
        return $this->model->with($relations)->orderBy($orderColumn, $order)->paginate($pageSize);
    }

    /**
     * Fetch all the records matching the provided condition.
     *
     * @param array $conditions
     * @param string $order
     * @param string $orderColumn
     * @return mixed
     */
    public function where(array $conditions, string $order = 'desc', string $orderColumn = 'id')
    {
        return $this->model->where($conditions)->orderBy($orderColumn, $order)->get();
    }


    /**
     * Fetch all the records matching the provided condition with related models.
     *
     * @param array $conditions
     * @param array $relations
     * @param string $order
     * @param string $orderColumn
     * @return mixed
     */
    public function whereWithRelation(array $conditions, array $relations = [], string $order = 'desc', string $orderColumn = 'id')
    {
        return $this->model->where($conditions)->with($relations)->orderBy($orderColumn, $order)->get();
    }

    /**
     * Fetch all the records matching the provided condition with pagination.
     *
     * @param array $conditions
     * @param bool $pagination
     * @param int $pageSize
     * @param string $order
     * @param string $orderColumn
     * @return mixed
     */
    public function whereWithPagination(array $conditions, bool $pagination = false, int $pageSize = 5, string $order = 'desc', string $orderColumn = 'id')
    {
        return $this->model->where($conditions)->orderBy($orderColumn, $order)->paginate($pageSize);
    }

    /**
     * Fetch all the records matching the provided
     * @param array $conditions
     * @param array $relations
     * @param bool $pagination
     * @param int $pageSize
     * @param string $order
     * @param string $orderColumn
     * @return mixed
     */
    public function whereWithRelationAndPagination(array $conditions, array $relations = [], bool $pagination = false, int $pageSize = 5, string $order = 'desc', string $orderColumn = 'id')
    {
        return $this->where($conditions)->with($relations)->orderBy($orderColumn, $order)->paginate($pageSize);
    }


    /**
     * Get the first record matching the provided condition.
     *
     * @param array $conditions
     * @param array $relations
     * @return mixed
     */
    public function first(array $conditions = [], array $relations = [])
    {
        return $this->model->where($conditions)->with($relations)->first();
    }

    /**
     * Counts the number of existing records.
     *
     * @param array $conditions
     * @return mixed
     */
    public function count(array $conditions = [])
    {
        return $this->model->where($conditions)->count();
    }

    /**
     * Prepares the data for creating a new record.
     *
     * @param Request $request
     * @return mixed
     */
    public function prepareDataForCreate(Request $request)
    {
        return $request->only($this->model->getFillable());
    }

    /**
     * Prepares the data for updating an existing record.
     *
     * @param Request $request
     * @return mixed
     */
    public function prepareDataForUpdate(Request $request)
    {

        return $this->prepareDataForCreate($request);
    }

    /**
     * Creates a new entry on the database.
     *
     * @param Request $request
     * @return mixed
     */
    public function create(Request $request)
    {
        $data = $this->prepareDataForCreate($request);
        $entry = $this->model->create($data);
        return $entry;
    }

    /**
     * Updates an existing entry on the database.
     *
     * @param Request $request
     * @param $id
     * @param string $primaryKey
     * @return mixed
     */
    public function update(Request $request, $id, string $primaryKey = 'id')
    {
        try {
            $data = $this->prepareDataForUpdate($request);
            $entry =  $this->model->where($primaryKey, '=', $id)->first();
            $entry->update($data);
            return $entry;
        } catch (\Exception $e) {
            return $this->handleDatabaseException($e);
        }
    }

    /**
     * Deletes an existing entry on the database.
     *
     * @param $id
     * @param string $primaryKey
     * @return mixed
     */
    public function delete($id, string $primaryKey = 'id')
    {
        try {
            $operation = $this->model->where($primaryKey, '=', $id)->first()->delete();
            return $operation;
        } catch (\Exception $e) {
            return $this->handleDatabaseException($e);
        }
    }

    public function forcedelete($id, string $primaryKey = 'id')
    {
        try {
            $operation = $this->model
                              ->withTrashed()
                              ->where($primaryKey, '=', $id)
                              ->first()
                              ->forcedelete();
            return $operation;
        } catch (\Exception $e) {
            return $this->handleDatabaseException($e);
        }
    }

    /**
     * Returns a success redirect with success message
     *
     * @param string $operationType
     * @param string $route
     * @param bool $success
     * @param string|null $msg
     * @return mixed
     */
    public function redirectWithResponse(string $operationType, string $route, bool $success = true, string $msg = null)
    {
        $message = '';
        switch ($operationType) {
            case 'create':
                $message = $success ? __('Record created successfully') : __('Record could not be created.');
                break;
            case 'edit':
                $message = $success ?  __('Record updated successfully') : __('Record could not be updated.');
                break;
            case 'delete':
                $message = $success ? __('Record deleted successfully') : __('Record could not be deleted.');
                break;
            default:
                $message = __('Invalid operation');
        }
        return redirect($route)->with($success ? 'status' : 'error', !empty($msg) ? $msg : $message);
    }

    /**
     * Handles the exception by rolling back database transaction and logging the exception.
     *
     * @param \Exception $e
     * @return |null
     */
    protected function handleDatabaseException(\Exception $e)
    {
        \Log::info($e);
        return null;
    }
    
}
