<?php

namespace App\Repositories\ComplainFeedback;

use App\Repositories\BaseRepositoryInterface;

interface ComplainFeedbackInterface extends BaseRepositoryInterface
{

}
