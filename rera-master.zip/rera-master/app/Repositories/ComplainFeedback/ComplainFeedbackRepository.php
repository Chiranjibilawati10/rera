<?php


namespace App\Repositories\ComplainFeedback;

use App\Repositories\BaseRepository;
use App\Model\ComplainFeedback\ComplainFeedback;
use App\Tools\Response;
use Illuminate\Support\Facades\DB;
use Notification;
use App\Notifications\ComplainFeedbackReplyNotification;

class ComplainFeedbackRepository extends BaseRepository implements ComplainFeedbackInterface
{
    /**
     * ComplainFeedbackRepository constructor.
     *
     * @param ComplainFeedback $ComplainFeedback
     */
    public function __construct(ComplainFeedback $model)
    {
        parent::__construct($model);
    }

    public function getData()
    {
        try{
            $query=$this->query();
            $data['records'] = $query->latest()->get();
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function storeEntry($request)
    {
        try{
            DB::beginTransaction();
            $record=$this->create($request);
            $returnData = Response::prepare(false, 'Record Created Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function getEntry($id)
    {
        try {
            $data['record'] = $this->first([
                ['id', '=', $id],
            ]);
            $returnData = Response::prepare(false, 'Record Updated Successfully', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function updateEntry($request, $id)
    {
        try{
            DB::beginTransaction();
            $request['reply_by_email']=auth()->user()->email;
            $entry=$this->update($request,$id);
            $data['reply_message']=$request->reply_message;
            $data['subject']=$entry->subject;
            Notification::route('mail', config('mail.from.address'))
                        ->notify(new ComplainFeedbackReplyNotification($data));
            $returnData = Response::prepare(false, 'Reply Sent Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function deleteEntry($id)
    {
        try{
            DB::beginTransaction();
            $this->delete($id);
            $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }
}
