<?php


namespace App\Repositories;
use Illuminate\Http\Request;


interface BaseRepositoryInterface
{

    /**
     * Get the query instance for the model.
     *
     * @return mixed
     */
    public function query();


    /**
     * Fetch all the records from the database.
     *
     * @param string $order
     * @param string $orderColumn
     */
    public function all(string $order = 'desc', string $orderColumn = 'id');

    /**
     * Fetch all the records from database with their related models.
     *
     * @param array $relations
     * @param string $order
     * @param string $orderColumn
     * @return mixed
     */
    public function allWithRelation(array $relations = [], string $order = 'desc', string $orderColumn = 'id');

    /**
     * Fetch all the records from database with pagination.
     *
     * @param int $pageSize
     * @param string $order
     * @param string $orderColumn
     * @return mixed
     */
    public function allWithPagination(int $pageSize = 5, string $order = 'desc', string $orderColumn = 'id');

    /**
     * Fetch all the records from database with related models and pagination.
     *
     * @param array $relations
     * @param int $pageSize
     * @param string $order
     * @param string $orderColumn
     * @return mixed
     */
    public function allWithRelationAndPagination(array $relations = [], int $pageSize = 5, string $order = 'desc', string $orderColumn = 'id');


    /**
     * Fetch all the records matching the provided condition.
     *
     * @param array $conditions
     * @param string $order
     * @param string $orderColumn
     * @return mixed
     */
    public function where(array $conditions, string $order = 'desc', string $orderColumn = 'id');

    /**
     * Fetch all the records matching the provided condition with related models.
     *
     * @param array $conditions
     * @param array $relations
     * @param string $order
     * @param string $orderColumn
     * @return mixed
     */
    public function whereWithRelation(array $conditions, array $relations = [], string $order = 'desc', string $orderColumn = 'id');

    /**
     * Fetch all the records matching the provided condition with pagination.
     *
     * @param array $conditions
     * @param bool $pagination
     * @param int $pageSize
     * @param string $order
     * @param string $orderColumn
     * @return mixed
     */
    public function whereWithPagination(array $conditions, bool $pagination = false, int $pageSize = 5, string $order = 'desc', string $orderColumn = 'id');

    /**
     * Fetch all the records matching the provided
     * @param array $conditions
     * @param array $relations
     * @param bool $pagination
     * @param int $pageSize
     * @param string $order
     * @param string $orderColumn
     * @return mixed
     */
    public function whereWithRelationAndPagination(array $conditions, array $relations = [], bool $pagination = false, int $pageSize = 5, string $order = 'desc', string $orderColumn = 'id');

    /**
     * Get the first record matching the provided condition.
     *
     * @param array $conditions
     * @param array $relations
     * @return mixed
     */
    public function first(array $conditions = [], array $relations = []);

    /**
     * Counts the number of existing records.
     *
     * @param array $conditions
     * @return mixed
     */
    public function count(array $conditions = []);

    /**
     * Prepares the data for creating a new record.
     *
     * @param Request $request
     * @return mixed
     */
    public function prepareDataForCreate(Request $request);

    /**
     * Prepares the data for updating an existing record.
     *
     * @param Request $request
     * @return mixed
     */
    public function prepareDataForUpdate(Request $request);

    /**
     * Creates a new entry on the database.
     *
     * @param Request $request
     * @return mixed
     */
    public function create(Request $request);

    /**
     * Updates an existing entry on the database.
     *
     * @param Request $request
     * @param $id
     * @param string $primaryKey
     * @return mixed
     */
    public function update(Request $request, $id, string $primaryKey = 'id');

    /**
     * Deletes an existing entry on the database.
     *
     * @param $id
     * @param string $primaryKey
     * @return mixed
     */
    public function delete($id, string $primaryKey = 'id');

    /**
     * Returns a success redirect with success message
     *
     * @param string $operationType
     * @param string $route
     * @param bool $success
     * @param string $msg
     * @return mixed
     */
    public function redirectWithResponse(string $operationType, string $route, bool $success = true, string $msg = null);
  
}
