<?php


namespace App\Repositories\NewsEvents;


use App\Repositories\BaseRepositoryInterface;

interface NewsEventsInterface extends BaseRepositoryInterface
{

}
