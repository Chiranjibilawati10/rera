<?php


namespace App\Repositories\SubCategory;

use App\Repositories\Category;
use App\Repositories\BaseRepository;
use App\Model\RETechnology\SubCategory;
use App\Repositories\Category\CategoryInterface;
use App\Tools\Response;
use Illuminate\Support\Facades\DB;

class SubCategoryRepository extends BaseRepository implements SubCategoryInterface
{

    protected $category;
    /**
     * CompanyRepository constructor.
     *
     * @param Company $company
     */
    public function __construct(SubCategory $model,CategoryInterface $category)
    {
        parent::__construct($model);
        $this->category=$category;
    }

    public function getData()
    {
        try {
            $query = $this->query();
            $data['records'] = $query
                              ->with('category:name,id','createdBy','updatedBy')
                              ->whereHas('category')
                               ->get();
            $data['parent_list'] = $this->category
                                        ->query()
                                        ->where([
                                            'level'=>'category',
                                            'status'=>'1'
                                        ])
                                        ->whereHas('retechnology')
                                        ->pluck('name','id');
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function storeEntry($request)
    {
        try {
            DB::beginTransaction();
            $request['created_id']=auth()->user()->id;
           // $this->saveWithTranslationNepali(['name'=>$request->name_ne],$model);
            $category = $this->create($request);
            $returnData = Response::prepare(false, 'Record Created Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function getEntry($id)
    {
        try {
            $data['record'] = $this->first([
                ['id', '=', $id],
            ]);
            $data['parent_list'] = $this->category
                                        ->query()
                                        ->whereHas('retechnology')
                                        ->where([
                                            'level'=>'category',
                                            'status'=>'1'
                                        ])
                                        ->pluck('name','id');
            $returnData = Response::prepare(false, 'edit_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function updateEntry($request, $id)
    {
        try {
            DB::beginTransaction();
            $request['updated_id']=auth()->user()->id;
            $entry = $this->update($request, $id);
            $returnData = Response::prepare(false, 'Record Updated Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function deleteEntry($id)
    {
        try {
            DB::beginTransaction();
            $check_secure_delete_status=$this->model
                                             ->secureDelete($id,['children','topicsWithTrashed']);
            if($check_secure_delete_status){
                $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
                DB::commit();
            }else{
                $returnData = Response::prepare(true, 'Record Cannot be Deleted Child Exists', [], []);
            }
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }
}
