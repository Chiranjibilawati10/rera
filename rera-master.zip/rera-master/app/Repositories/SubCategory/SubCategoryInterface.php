<?php


namespace App\Repositories\SubCategory;


use App\Repositories\BaseRepositoryInterface;

interface SubCategoryInterface extends BaseRepositoryInterface
{
}
