<?php


namespace App\Repositories\OccupationSector;


use App\Repositories\BaseRepositoryInterface;

interface OccupationSectorInterface extends BaseRepositoryInterface
{

}
