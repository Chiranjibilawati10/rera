<?php


namespace App\Repositories\OccupationSector;


use App\Repositories\BaseRepository;
use App\Model\Occupation\OccupationSector;
use App\Tools\Response;
use Illuminate\Support\Facades\DB;


class OccupationSectorRepository extends BaseRepository implements OccupationSectorInterface
{
    /**
     * CompanyRepository constructor.
     *
     * @param Company $company
     */
    public function __construct(OccupationSector $model)
    {
        parent::__construct($model);
    }

    public function getData()
    {
        try{
            $query=$this->query();
            $data['sectors'] = $query->with('professions:name,occupation_sector_id')->get();
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }

    public function storeEntry($request)
    {
        try{
            DB::beginTransaction();
            $sector=$this->create($request);
            $sector->professions()->createMany($request->professions);
            $returnData = Response::prepare(false, 'Record Created Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function getEntry($id)
    {
        try{
            $data['sector'] = $this->first([
                                ['id','=',$id],
                            ]);
            $data['professions']=$data['sector']
                                    ->professions()
                                    ->get(['name','name_ne']);
            $returnData = Response::prepare(false, 'edit_success', $data, []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
           $returnData = Response::prepare(true, $e->getMessage(), [], []);
           return response()->json($returnData, 500);
        }
    }

    public function updateEntry($request,$id)
    {
        try{
            DB::beginTransaction();
            $entry=$this->update($request,$id);
            $entry->professions()->delete();
            $entry->professions()->createMany($request->professions);
            $returnData = Response::prepare(false, 'Record Updated Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }

    }

    public function deleteEntry($id)
    {
        try{
            DB::beginTransaction();
            $this->delete($id);
            $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }

    }


}
