<?php

namespace App\Repositories\NewsCategory;

use App\Repositories\BaseRepositoryInterface;

interface NewsCategoryInterface extends BaseRepositoryInterface
{

}
