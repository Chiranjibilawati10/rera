<?php

namespace App\Repositories\ConsultantPool;

use App\Repositories\BaseRepositoryInterface;

interface ConsultantPoolInterface extends BaseRepositoryInterface
{

}
