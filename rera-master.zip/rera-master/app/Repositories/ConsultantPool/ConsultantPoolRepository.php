<?php


namespace App\Repositories\ConsultantPool;

use App\Repositories\BaseRepository;
use App\Model\Consultant\ConsultantPool;
use App\Tools\Response;
use App\Model\Region\Province;
use Illuminate\Support\Facades\DB;

class ConsultantPoolRepository extends BaseRepository implements ConsultantPoolInterface
{
    /**
     * ComplainFeedbackRepository constructor.
     *
     * @param ComplainFeedback $ComplainFeedback
     */
    public function __construct(ConsultantPool $model)
    {
        parent::__construct($model);
    }

    public function getData()
    {
        try{
            $query=$this->query();
            $data['consultants'] = $query->with('createdBy','updatedBy','district','municipality','province')->get();
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function storeEntry($request)
    {
        try{
            DB::beginTransaction();
            $request['created_id']=auth()->user()->id;
            $topic=$this->create($request);
            $returnData = Response::prepare(false, 'Record Created Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function getEntry($id)
    {
        try {
            $data['consultant'] = $this->first([
                                    ['id', '=', $id],
                                ]);
            $returnData = Response::prepare(false, 'edit_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function updateEntry($request, $id)
    {
        try{
            DB::beginTransaction();
            $request['updated_id']=auth()->user()->id;
            $entry=$this->update($request,$id);
            $returnData = Response::prepare(false, 'Record Updated Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function deleteEntry($id)
    {
        try{
            DB::beginTransaction();
            $this->delete($id);
            $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function getDistrictList($province_id)
    {
        $district_list= District::all();

    }
   
}
