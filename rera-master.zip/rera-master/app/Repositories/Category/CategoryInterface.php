<?php


namespace App\Repositories\Category;


use App\Repositories\BaseRepositoryInterface;

interface CategoryInterface extends BaseRepositoryInterface
{
}
