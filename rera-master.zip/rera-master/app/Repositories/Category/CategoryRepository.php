s<?php


namespace App\Repositories\Category;


use App\Repositories\BaseRepository;
use App\Model\RETechnology\Category;
use App\Model\RETechnology\RETechnology;
use App\Tools\Response;
use App\Repositories\RETechnology\RETechnologyInterface;

use Illuminate\Support\Facades\DB;

class CategoryRepository extends BaseRepository implements CategoryInterface
{
    protected $re_technology;
    /**
     * CompanyRepository constructor.
     *
     * @param Company $company
     */
    public function __construct(Category $model,RETechnologyInterface $re_technology)
    {
        parent::__construct($model);
        $this->re_technology=$re_technology;
    }

    public function getData()
    {
        try {
            $query = $this->query();
            $data['records'] = $query
                                ->with('retechnology:name,id','createdBy','updatedBy')
                                ->whereHas('retechnology')
                                ->get();
            $data['parent_list'] = $this->re_technology
                                        ->query()
                                        ->where([
                                            'level'=>'energy',
                                            'status'=>'1'
                                        ])
                                        ->pluck('name','id');
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function storeEntry($request)
    {
        try {
            DB::beginTransaction();
            $request['created_id']=auth()->user()->id;
           // $this->saveWithTranslationNepali(['name'=>$request->name_ne],$model);
            $category = $this->create($request);
            $returnData = Response::prepare(false, 'Record Created', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function getEntry($id)
    {
        try {
            $data['record'] = $this->first([
                ['id', '=', $id],
            ]);
            $data['parent_list'] = $this->re_technology
                                        ->query()
                                        ->where([
                                            'level'=>'energy',
                                            'status'=>'1'
                                        ])
                                        ->pluck('name','id');
            $returnData = Response::prepare(false, 'edit_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function updateEntry($request, $id)
    {
        try {
            DB::beginTransaction();
            $request['updated_id']=auth()->user()->id;
            $entry = $this->update($request, $id);
            $returnData = Response::prepare(false, 'Record Updated Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function deleteEntry($id)
    {
        try {
            DB::beginTransaction();
            $check_secure_delete_status=$this->model
                                             ->secureDelete($id,['children','topicsWithTrashed']);
            if($check_secure_delete_status){
                $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
                DB::commit();
            }else{
                $returnData = Response::prepare(true, 'Record Cannot be Deleted Child Exists', [], []);
            }
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }
}
