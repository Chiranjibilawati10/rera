<?php


namespace App\Repositories\Slider;


use App\Repositories\BaseRepositoryInterface;

interface SliderInterface extends BaseRepositoryInterface
{

}
