<?php


namespace App\Repositories\Slider;

use App\Repositories\BaseRepository;
use App\Model\Slider\Slider;
use App\Tools\Response;
use App\Tools\ImageUploader;
//use Symfony\Component\Process\Exception\ProcessFailedException;
//use Symfony\Component\Process\Process;


class SliderRepository extends BaseRepository implements SliderInterface
{
    use ImageUploader;
    /**
     * CompanyRepository constructor.
     *
     * @param Company $company
     */
    public function __construct(Slider $model)
    {
        parent::__construct($model);
    }

    public function getData()
    {
        try {
            $data['records'] = $this->query()
                                    ->with('createdBy','updatedBy')
                                    ->get();
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function storeEntry($request)
    {
        try {
            $request['created_id']=auth()->user()->id;
            $record=$this->create($request);
            // $this->uploadSingleFile($request,$record);
            $this->uploadMultipleFile($request,$record);
            $returnData = Response::prepare(false, 'Record Created Successfully', [], []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function getEntry($id)
    {
        try {
            $data['record'] =$this->first([
                                ['id', '=', $id],
                            ])->load('files');
            if(is_null($data['record']['status'])){
                $data['record']['status']='';
            }
            $returnData = Response::prepare(false, 'edit_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function updateEntry($request, $id)
    {
        try {
            $request['updated_id']=auth()->user()->id;
            $entry=$this->update($request, $id);
        
            if ($request->file) {
                // return $this->makeSlideImage($request->file[0]);
                //$this->deleteMultipleUpload($entry);
                $this->uploadMultipleFile($request,$entry);
            }
            $returnData = Response::prepare(false, 'Record Updated Successfully', [], []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function deleteEntry($id)
    {
        try {
            $this->delete($id);
            $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function makeSlideImage($file)
    {
        try{
            $process = new Process('soffice --headless --convert-to pdf 1.ppt', storage_path() . '/app/public/uploads/');
           
            $process->mustRun();
            if ($process->isSuccessful()) {
                $process_pdf = new Process('gs -sDEVICE=pngalpha -o slajd-%02d.png -r96 1.pdf', storage_path() . '/app/public/uploads/');
                $process_pdf->mustRun(); 
            }else{
                throw new ProcessFailedException($process);
            }
            if ($process_pdf->isSuccessful()) {
                return $process_pdf->getOutput();
            }else{
                throw new ProcessFailedException($process_pdf);
            }
            } catch (ProcessFailedException $exception) {
                return $exception->getMessage();
            }
    }
}
