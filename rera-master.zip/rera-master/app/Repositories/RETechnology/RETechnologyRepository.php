<?php


namespace App\Repositories\RETechnology;


use App\Repositories\BaseRepository;
use App\Model\RETechnology\RETechnology;
use App\Tools\Response;
use Illuminate\Support\Facades\DB;

class RETechnologyRepository extends BaseRepository implements RETechnologyInterface
{
    /**
     * CompanyRepository constructor.
     *
     * @param Company $company
     */
    public function __construct(RETechnology $model)
    {
        parent::__construct($model);
    }

    public function getData()
    {
        try {
            $query = $this->query();
            $data['retechnologies'] = $query->with('createdBy','updatedBy')
                                            ->where('level','energy')
                                            ->get();
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function storeEntry($request)
    {
        try {
            DB::beginTransaction();
            $request['created_id']=auth()->user()->id;
            $retechnology = $this->create($request);
            $returnData = Response::prepare(false, 'Record Created Successfully', [], []);
            $request['slug'] = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $request['name'].'-'.$retechnology->id)));
            $retechnology->slug=$request['slug'];
            $retechnology->save();
            DB::commit();
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function getEntry($id)
    {
        try {
            $data['retechnology'] = $this->first([
                ['id', '=', $id],
            ]);
            $returnData = Response::prepare(false, 'edit_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function updateEntry($request, $id)
    {
        try {
            DB::beginTransaction();
            $request['updated_id']=auth()->user()->id;
            $request['slug'] = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $request['name'].'-'.$id)));
            $entry = $this->update($request, $id);
            $returnData = Response::prepare(false, 'Record Updated Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function deleteEntry($id)
    {
        try {
            DB::beginTransaction();
            $check_secure_delete_status=$this->model
                                             ->secureDelete($id,['children','topicsWithTrashed']);
            if($check_secure_delete_status){
                $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
                DB::commit();
            }else{
                $returnData = Response::prepare(true, 'Record Cannot be Deleted Child Exists', [], []);
            }
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }
}
