<?php


namespace App\Repositories\RETechnology;


use App\Repositories\BaseRepositoryInterface;

interface RETechnologyInterface extends BaseRepositoryInterface
{
}
