<?php


namespace App\Repositories\Topic;

use App\Repositories\BaseRepository;
use App\Model\Topic\Topic;
use App\Tools\Response;
use Illuminate\Support\Facades\DB;
use App\Repositories\RETechnology\RETechnologyInterface;
use App\Repositories\Category\CategoryInterface;
use App\Repositories\SubCategory\SubCategoryInterface;
use App\Repositories\Chapter\ChapterInterface;
use App\Tools\ImageUploader;

class TopicRepository extends BaseRepository implements TopicInterface
{
    use ImageUploader;

    protected $re_technology,$chapter;
    /**
     * TopicRepository constructor.
     *
     * @param Topic $topic
     */
    public function __construct(Topic $model, RETechnologyInterface $re_technology,ChapterInterface $chapter)
    {
        parent::__construct($model);
        $this->re_technology=$re_technology;
        $this->chapter=$chapter;
    }

    public function getData($request)
    {
        try{
            $columns = ['title', 'title_ne', 'summary', 'summary_ne', 'order'];
            $search = $request->input('search');
            $query=$this->query();
            $query->with('createdBy','updatedBy','category','chapter')->orderBy('order');
            if ($search){
               $query->where(function($query) use($columns, $search){
                   foreach($columns as $value){
                       $query->orWhere($value, 'like', '%'. $search . '%');
                   }
               })->orwhereHas('category', function ($query) use ($search){
                    $query->where('name', 'like', '%'.$search.'%');
                  })->orwhereHas('chapter', function ($query) use ($search){
                    $query->where('chapter_name', 'like', '%'.$search.'%');
                  });
            }
            $data['topics'] = $query->paginate($request->pageNumber);

            $data['renewable_parent_list'] = $this->re_technology
                                                    ->model
                                                    ->where([
                                                        'status'=>1,
                                                        'level'=>'energy'
                                                    ])->pluck('name','id');
            $data['chapter_parent_list'] = $this->chapter
                                                    ->model
                                                    ->where([
                                                        'status'=>1,
                                                        'level'=>'parent'
                                                    ])->pluck('chapter_name','id');
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function getTrashedData($request)
    {
        try{
                $columns = ['title', 'title_ne', 'summary', 'summary_ne', 'order'];
                $search = $request->input('trashedsearch');
                $query=$this->query();
                $query->onlyTrashed()->with('createdBy','updatedBy','category','chapter')->orderBy('order');
                if ($search){
                   $query->where(function($query) use($columns, $search){
                       foreach($columns as $value){
                           $query->orWhere($value, 'like', '%'. $search . '%');
                       }
                   })->orwhereHas('category', function ($query) use ($search){
                    $query->where('name', 'like', '%'.$search.'%');
                  })->orwhereHas('chapter', function ($query) use ($search){
                    $query->where('chapter_name', 'like', '%'.$search.'%');
                  });
                }
                $data['topics'] = $query->where('deleted_at','!=',null)->paginate($request->pageNumber);
                $returnData = Response::prepare(false, 'list_success', $data, []);
                return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }

    public function storeEntry($request)
    {
        try{
            DB::beginTransaction();
            if(!$request->dragged){
                $request['created_id']=auth()->user()->id;
                // unset($request['renewable_id']);
                // unset($request['re_category_id']);
                // unset($request['sub_category_id']);
                $topic=$this->create($request);
                if(!$request->order){
                    $topic->order=$topic->id;
                    $topic->save();
                }
                $this->uploadContentFiles($request,$topic);
                $returnData = Response::prepare(false, 'Record Created Successfully', [], []);
                DB::commit();
            }else{
                return $this->orderData($request);
            }
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function getEntry($id)
    {
        try {
            $data['topic'] = $this->first([
                                    ['id', '=', $id],
                                ])->load('files');
            $data['categorySetValue']=$this->getCategoryList($data['topic']);
            $data['chapterSetValue']=$this->getChapterList($data['topic']);
            $returnData = Response::prepare(false, 'edit_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function updateEntry($request, $id)
    {
        try{
            DB::beginTransaction();
            $request['updated_id']=auth()->user()->id;
            $entry=$this->update($request,$id);
            if ($request->file) {
                $this->uploadContentFiles($request,$entry);
            }
            $returnData = Response::prepare(false, 'Record Updated Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function deleteEntry($id)
    {
        try{
            DB::beginTransaction();
            $this->delete($id);
            $returnData = Response::prepare(false, 'Record Trashed Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function deleteTrashedEntry($id)
    {
        try{
            DB::beginTransaction();
            $this->forcedelete($id);
            $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }


    public function restoreTopic($id)
    {
        try{
            DB::beginTransaction();
            $this->query()
                 ->withTrashed()
                 ->find($id)
                 ->restore();
            $returnData = Response::prepare(false, 'Record Restore Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }

    }

    public function getChildren(int $category_id)
    {
        try{
            $children =  $this->re_technology
                                ->model
                                ->where([
                                    'status'=>1,
                                    'parent_id'=>$category_id
                                ])->pluck('name','id');
            if(count($children)){
                $data['children']=$children;
                $returnData = Response::prepare(false, 'list_success', $data, []);
                return response()->json($returnData, 200);
            }else{
                $data['children']=[];
                $returnData = Response::prepare(true, 'list_success', $data, []);
                return response()->json($returnData, 200);
            }
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }

    public function getCategoryList($topic)
    {
        $renewable_parent_list= $this->re_technology
                                    ->model
                                    ->where([
                                        'status'=>1,
                                        'level'=>'energy'
                                    ])->pluck('name','id');
        $category=$topic->category;
        if($category->level=='energy'){
            return [
                'renewable_id'=>$category->id,
                're_category_id'=>'',
                'sub_category_id'=>'',
                'renewable_parent_list'=>$renewable_parent_list,
                'renewable_category_parent_list'=>false,
                'renewable_sub_category_parent_list'=>false
            ];
        }
        if($category->level=='category'){
            return [
                'renewable_id'=>$category->parentCategory->id,
                're_category_id'=>$category->id,
                'sub_category_id'=>'',
                'renewable_parent_list'=>$renewable_parent_list,
                'renewable_category_parent_list'=>$category->parentCategory
                                                           ->children
                                                           ->pluck('name','id'),
                'renewable_sub_category_parent_list'=>false
            ];
        }
        if($category->level=='subcategory'){
            return [
                'renewable_id'=>$category->parentCategory->parentCategory->id,
                're_category_id'=>$category->parentCategory->id,
                'sub_category_id'=>$category->id,
                'renewable_parent_list'=>$renewable_parent_list,
                'renewable_category_parent_list'=>$category->parentCategory
                                                           ->parentCategory
                                                           ->children
                                                           ->pluck('name','id'),
                'renewable_sub_category_parent_list'=>$category->parentCategory
                                                           ->children
                                                           ->pluck('name','id')
            ];
        }
    }

    public function getChapterChildren(int $chapter_id)
    {
        try{
            $children =  $this->chapter
                                ->model
                                ->where([
                                    'status'=>1,
                                    'parent_id'=>$chapter_id
                                ])->pluck('chapter_name','id');
            if(count($children)){
                $data['chapter_children']=$children;
                $returnData = Response::prepare(false, 'list_success', $data, []);
                return response()->json($returnData, 200);
            }else{
                $data['chapter_children']=[];
                $returnData = Response::prepare(true, 'list_success', $data, []);
                return response()->json($returnData, 200);
            }
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }

    public function getChapterList($topic)
    {
        $chapter_parent_list= $this->chapter
                                    ->model
                                    ->where([
                                        'status'=>1,
                                        'level'=>'parent'
                                    ])->pluck('chapter_name','id');
        if($topic->chapter->level=='child'){
            return [
                'chapter_parent_id'=>$topic->chapter->parent->id,
                'chapter_child_id'=>$topic->chapter->id,
                'chapter_parent_list'=>$chapter_parent_list,
                'chapter_children_list'=>$topic->chapter
                                               ->parent
                                               ->children
                                               ->pluck('chapter_name','id'),
            ];
        }else{
            return [
                'chapter_parent_id'=>$topic->chapter->id,
                'chapter_child_id'=>'',
                'chapter_parent_list'=>$chapter_parent_list,
                'chapter_children_list'=>false
            ];

        }

    }

    private function orderData($request)
    {
        try {
            $dragged_data=collect($request->dragged_data);
            $order=$dragged_data->pluck('order')->toArray();
            sort($order);
            foreach ($dragged_data as $key => $value) {
                if(!is_null($value)){
                    $entry =  $this->model->where('id', '=', $value['id'])->first();
                    $entry->update(['order'=>$order[$key]]);
                } 
            }
            DB::commit();
            $returnData = Response::prepare(false, 'Record Updated Successfully',[], []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }
}
