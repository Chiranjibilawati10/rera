<?php

namespace App\Repositories\Topic;

use App\Repositories\BaseRepositoryInterface;

interface TopicInterface extends BaseRepositoryInterface
{

}
