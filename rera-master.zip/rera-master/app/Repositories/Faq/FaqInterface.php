<?php


namespace App\Repositories\Faq;


use App\Repositories\BaseRepositoryInterface;

interface FaqInterface extends BaseRepositoryInterface
{
}
