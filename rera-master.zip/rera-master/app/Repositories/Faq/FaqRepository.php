<?php


namespace App\Repositories\Faq;


use App\Repositories\BaseRepository;
use App\Model\Faq;
use App\Tools\Response;
use Illuminate\Support\Facades\DB;
use App\Model\Category;
use App\Repositories\RETechnology\RETechnologyInterface;

class FaqRepository extends BaseRepository implements FaqInterface
{
    protected $re_technology;
    /**
     * CompanyRepository constructor.
     *
     * @param Company $company
     */
    public function __construct(Faq $model,RETechnologyInterface $re_technology)
    {
        parent::__construct($model);
        $this->re_technology=$re_technology;
    }

    public function getData()
    {
        try {
            $query = $this->query();
            $data['faqs'] = $query->latest()->get();
            
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function storeEntry($request)
    {
        try {
            DB::beginTransaction();
            $faq = $this->create($request);
            $returnData = Response::prepare(false, 'Record Created Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function getEntry($id)
    {
        try {
            $data['faq'] = $this->first([
                ['id', '=', $id],
            ]);
            
            $returnData = Response::prepare(false, 'edit_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function updateEntry($request, $id)
    {
        try {
            DB::beginTransaction();
            $entry = $this->update($request, $id);
            $returnData = Response::prepare(false, 'Record Updated Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function deleteEntry($id)
    {
        try {
            DB::beginTransaction();
            $this->delete($id);
            $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }
}
