<?php


namespace App\Repositories\OccupationProfession;


use App\Repositories\BaseRepositoryInterface;

interface OccupationProfessionInterface extends BaseRepositoryInterface
{

}
