<?php


namespace App\Repositories\OccupationProfession;

use App\Repositories\BaseRepository;
use App\Model\Occupation\OccupationProfession;
use App\Tools\Response;

class OccupationProfessionRepository extends BaseRepository implements OccupationProfessionInterface
{
    /**
     * CompanyRepository constructor.
     *
     * @param Company $company
     */
    public function __construct(OccupationProfession $model)
    {
        parent::__construct($model);
    }

    public function getData()
    {
        try {
            $data['records'] = $this->all();
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function storeEntry($request)
    {
        try {
            $this->create($request);
            $returnData = Response::prepare(false, 'Record Created Successfully', [], []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function getEntry($id)
    {
        try {
            $data['record'] = $this->first([
                ['id', '=', $id],
            ]);
            $returnData = Response::prepare(false, 'edit_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function updateEntry($request, $id)
    {
        try {
            $this->update($request, $id);
            $returnData = Response::prepare(false, 'Record Updated Successfully', [], []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function deleteEntry($id)
    {
        try {
            $this->delete($id);
            $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }
}
