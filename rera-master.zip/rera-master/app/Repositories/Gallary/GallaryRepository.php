<?php


namespace App\Repositories\Gallary;


use App\Repositories\BaseRepository;
use App\Model\Gallary\Gallary;
use App\Tools\Response;
use App\Tools\ImageUploader;
use App\Model\Album\Album;

use Illuminate\Support\Facades\DB;

class GallaryRepository extends BaseRepository implements GallaryInterface
{
    use ImageUploader;
    protected $Gallary;
    /**
     * CompanyRepository constructor.
     *
     * @param Company $company
     */
    public function __construct(Gallary $model)
    {
        parent::__construct($model);
    }

    public function getData($request)
    {
        try {
            $query = $this->query();
            $data['categories']=Album::pluck('name','id');
            $data['records'] = Album::with('createdBy','updatedBy')
                                      ->paginate(10);
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function storeEntry($request)
    {
        try {
            DB::beginTransaction();
            // $request['created_id']=auth()->user()->id;
            // $Gallary = $this->create($request);
            // if ($request->file) {
            //     $this->uploadMultipleFile($request,$Gallary);
            // }
            $returnData = Response::prepare(false, 'Record Created', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function getEntry($id)
    {
        try {
            $data['record'] = Album::find($id)->load('files');
            $returnData = Response::prepare(false, 'edit_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function updateEntry($request, $id)
    {
        try {
            DB::beginTransaction();
            $request['updated_id']=auth()->user()->id;
            // $entry = $this->update($request, $id);
            // if ($request->file) {
            //     $this->uploadMultipleFile($request,$entry);
            // }
            $returnData = Response::prepare(false, 'Record Updated Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function deleteEntry($id)
    {
        try {
            DB::beginTransaction();
            $this->delete($id);
            $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function upload($request,$id)
    {
        try {
            DB::beginTransaction();
            $entry =Album::find($id);
            if ($request->file) {
                $file_name = $this->normalizeString(pathinfo($request->file->getClientOriginalName(), PATHINFO_FILENAME).'.'.$request->file->getClientOriginalExtension());
                $path=$request->file->storeAs('public/uploads',$file_name);
                $entry->files()->create([
                                    'location'=>$path,
                                    'type'=>'dropzonefile',
                                    'name'=>$file_name
                                ]);
            }
            $returnData = Response::prepare(false, 'Record Updated Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        }catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
        
    }

    public function gallaryDelete($request,$id)
    {
        try {
            DB::beginTransaction();
            $entry=\App\Model\File\File::where(['name'=> $this->normalizeString($request->file),
                                     'model_type'=>'App\Model\Album\Album',
                                     'model_id'=>$id,
                                     'type'=>'dropzonefile',
                                   ])->first();
            $entry->delete();
            $returnData = Response::prepare(false, 'Record Updated Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        }catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
        
    }
}
