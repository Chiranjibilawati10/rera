<?php


namespace App\Repositories\Gallary;


use App\Repositories\BaseRepositoryInterface;

interface GallaryInterface extends BaseRepositoryInterface
{
}
