<?php

namespace App\Repositories\Chapter;

use App\Repositories\BaseRepositoryInterface;

interface ChapterInterface extends BaseRepositoryInterface
{

}
