<?php


namespace App\Repositories\Chapter;

use App\Repositories\BaseRepository;
use App\Model\Chapter\Chapter;
use App\Tools\Response;
use Illuminate\Support\Facades\DB;

class ChapterRepository extends BaseRepository implements ChapterInterface
{
    /**
     * ChapterRepository constructor.
     *
     * @param Chapter $chapter
     */
    public function __construct(Chapter $model)
    {
        parent::__construct($model);
    }

    public function getData($request)
    {
        try{
            $query=$this->query();
            $columns = ['chapter_name','chapter_name_ne','summary', 'summary_ne'];
            $search = $request->input('search');
            if ($search){
               $query->where(function($query) use($columns, $search){
                   foreach($columns as $value){
                       $query->orWhere($value, 'like', '%'. $search . '%');
                   }
               });
            }
            if(request()->has('parent')){
                $data['chapters'] = $query->with('createdBy','updatedBy','parent')
                            ->where('level','parent')
                            ->orderBy('order')
                            ->orderBy('created_at', 'desc')
                            ->paginate($request->pageNumber);
            }else{
                if ($search){
                    $query=$query->orwhereHas('parent', function ($query) use ($search){
                                $query->where('chapter_name', 'like', '%'.$search.'%');
                            });
                }
                $data['chapters'] = $query->with('createdBy','updatedBy','parent')
                            ->where('level','child')
                            ->orderBy('order')
                            ->orderBy('created_at', 'desc')
                            ->paginate($request->pageNumber);

            }
           
            $data['parent_list'] = $this->query()
                                        ->where('level','parent')
                                        ->orderBy('order')
                                         ->orderBy('created_at', 'desc')
                                         ->get('chapter_name','id');
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function storeEntry($request)
    {
        try{
            DB::beginTransaction();
            if(!$request->dragged){
                $request['created_id']=auth()->user()->id;
                if($request->parent_id && is_numeric($request->parent_id)){
                    $request['level']='child';
                }else{
                     $request['level']='parent';
                }
                $chapters=$this->create($request);
                if(!$request->order){
                    $chapters->order= $chapters->id;
                    $chapters->save();
                }
                $request['slug'] = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $request['chapter_name'].'-'.$chapters->id)));
                $chapters->slug=$request['slug'];
                $chapters->save();
                $returnData = Response::prepare(false, 'Record Created Successfully', [], []);
                DB::commit();
            }else{
                return $this->orderData($request);
            }
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function getEntry($id)
    {
        try {
            $data['chapters'] = $this->first([
                ['id', '=', $id],
            ]);
            $data['parent_list'] =  $this->query()
                                        ->with('createdBy','updatedBy','parent')
                                        ->where('level','parent')
                                        ->get();
            $returnData = Response::prepare(false, 'Record Updated Successfully', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function updateEntry($request, $id)
    {
        try{
            DB::beginTransaction();
            $request['updated_id']=auth()->user()->id;
            if($request->parent_id && is_numeric($request->parent_id)){
                $request['level']='child';
            }else{
                 $request['level']='parent';
            }
            $request['slug'] = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $request['chapter_name'].'-'.$id)));
            $entry=$this->update($request,$id);
            $returnData = Response::prepare(false, 'Record Updated Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function deleteEntry($id)
    {
        try{
            DB::beginTransaction();
            $check_secure_delete_status=$this->model
                                             ->secureDelete($id,['topicsWithTrashed']);
            if($check_secure_delete_status){
                $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
                DB::commit();
            }else{
                $returnData = Response::prepare(true, 'Record Cannot be Deleted Child Exists', [], []);
            }
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    private function orderData($request)
    {
        try {
            $dragged_data=collect($request->dragged_data);
            $order=$dragged_data->pluck('order')->toArray();
            sort($order);
            foreach ($dragged_data as $key => $value) {
                if(!is_null($value)){
                    $entry =  $this->model->where('id', '=', $value['id'])->first();
                    $entry->update(['order'=>$order[$key]]);
                } 
            }
            DB::commit();
            $returnData = Response::prepare(false, 'Record Updated Successfully',[], []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }

}
