<?php  
namespace App\Frontend\Notice;

use App\Tools\Response;

class NoticeService{
    /**
    * @var noticeService
    */
    protected $noticeService;

    public function __construct() 
    {
      $this->noticeService=resolve('App\Repositories\NewsEvents\NewsEventsInterface');
    }

    /**
     * @return mixed
     */
    public function getNotices($request)
    {
        try {
            $data['notices'] = $this->noticeService
                                              ->query()
                                              ->translate()
                                              ->with('files')
                                              ->paginate(10);
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function getNotice($request)
    {
        try {
            $data['notice'] = $this->noticeService
                                    ->query()
                                    ->translate()
                                    ->with('files')
                                    ->where('id',$request->id)
                                    ->first();
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }
 
}
