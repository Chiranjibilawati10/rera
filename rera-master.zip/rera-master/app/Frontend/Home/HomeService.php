<?php
namespace App\Frontend\Home;

use App\Tools\Response;
use App\Model\Consultant\ConsultantPool;
use App\Model\Slider\Slider;
use App\Model\SliderInfo\SliderInfo;

class HomeService{
    /**
    * @var successStoryService
    */
    protected $successStoryService;
    /**
    * @var newsEventService
    */
    protected $newsEventService;

    public function __construct()
    {
      $this->successStoryService=resolve('App\Repositories\SuccessStory\SuccessStoryInterface');
      $this->newsEventService=resolve('App\Repositories\NewsEvents\NewsEventsInterface');
      $this->chapterService=resolve('App\Repositories\Chapter\ChapterInterface');
    }

    /**
     * @return mixed
     */
    public function getHomePage()
    {
        try {
            $data['success_stories'] = $this->successStoryService
                                              ->query()
                                              ->translate()
                                              ->with('files')
                                              ->latest()
                                              ->take(5)
                                              ->get();
            $data['notices'] = $this->newsEventService
                                    ->query()
                                    ->translate()
                                    ->with('files')
                                    ->latest()
                                    ->take(5)
                                    ->get();
            $data['sliderinfos'] = SliderInfo::query()->translate()->get();
            $data['chapters'] = $this->chapterService
                                   ->query()
                                   ->translate()
                                   ->with('topics')
                                   ->where('level','parent')
                                   // ->whereHas('children.topics')
                                   ->whereHas('children')
                                   ->with(['children' => function ($child){
                                         $child->where('status',1)
                                               ->orderBy('order')
                                               ->orderBy('created_at', 'desc')
                                               // ->whereHas('topics')
                                               ->translate();
                                    }])
                                   ->where('status',1)
                                   ->orderBy('order')
                                   ->orderBy('created_at', 'desc')
                                   ->get()->chunk(3);
            $data['sliders']=Slider::with('files')->whereHas('files')->get();
//            dd($data['chapters']);
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function getConsultantPool()
    {
      try{
          $data['consultants'] =ConsultantPool::with('district','municipality','province')->get();
          $returnData = Response::prepare(false, 'list_success', $data, []);
          return response()->json($returnData, 200);
      }catch(\Exception $e){
          $returnData = Response::prepare(true, $e->getMessage(), [], []);
          return response()->json($returnData, 500);
      }
    }

}
