<?php  
namespace App\Frontend\Story;

use App\Tools\Response;

class StoryService{
    /**
    * @var successStoryService
    */
    protected $successStoryService;

    public function __construct() 
    {
      $this->successStoryService=resolve('App\Repositories\SuccessStory\SuccessStoryInterface');
    }

    /**
     * @return mixed
     */
    public function getStories($request)
    {
        try {
            $data['success_stories'] = $this->successStoryService
                                              ->query()
                                              ->translate()
                                              ->with('files')
                                              ->paginate(10);
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function getStory($request)
    {
        try {
            $data['story'] = $this->successStoryService
                                    ->query()
                                    ->translate()
                                    ->with('files')
                                    ->where('id',$request->id)
                                    ->first();
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }
 
}
