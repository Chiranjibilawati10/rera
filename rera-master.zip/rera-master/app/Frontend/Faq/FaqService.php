<?php  
namespace App\Frontend\Faq;

use App\Tools\Response;

class FaqService{
    /**
    * @var retechnologyService
    */
    protected $retechnologyService,$faqService;

    public function __construct() 
    {
      $this->retechnologyService=resolve('App\Repositories\RETechnology\RETechnologyInterface');
      $this->faqService=resolve('App\Repositories\Faq\FaqInterface');

    }


    public function getFaqs($request)
    {
        try {
            $data['faqs']= $this->faqService
                                    ->query()
                                    ->translate()
                                    ->where('status',1)
                                    ->paginate(30);
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    
 
}
