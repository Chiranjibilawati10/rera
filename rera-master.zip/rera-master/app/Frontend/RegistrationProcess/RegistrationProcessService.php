<?php  
namespace App\Frontend\RegistrationProcess;

use App\Tools\Response;
use App\User;

class RegistrationProcessService{
    // /**
    // * @var userService
    // */
    // protected $emailService;

    public function __construct() {}
    /**
     * @return mixed
     */
    public function validateEmail($request)
    {
        $user=User::find($request->id);
        if($user){
            if(is_null($user->email_verified_at)){
                $user->email_verified_at=date('Y-m-d H:i:s');
                $user->save();
                return redirect('login')->with('emailValidationSuccess','email was successfully valdiated');
                //return view('frontend.registration.success_email_validation');
            }else{
                return redirect('login');
            }
        }
        return redirect('login');
    }
    
 
}
