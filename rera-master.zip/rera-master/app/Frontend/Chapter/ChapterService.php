<?php  
namespace App\Frontend\Chapter;

use App\Tools\Response;

class ChapterService{
    /**
    * @var chapterService
    */
    protected $chapterService,$topicService;

    public function __construct() 
    {
      $this->chapterService=resolve('App\Repositories\Chapter\ChapterInterface');
      $this->topicService=resolve('App\Repositories\Topic\TopicInterface');

    }
    /**
     * @return mixed
     */
    public function getChapters($request)
    {
        try {
            $data['chapters'] = $this->chapterService
                                      ->query()
                                      ->translate()
                                      ->where('status',1)
                                      ->with('topics')
                                      ->where('level','parent')
                                      // ->whereHas('children.topics')
                                      ->whereHas('children')
                                      ->with(['children' => function ($child){
                                            $child->where('status',1)
                                                  ->orderBy('order')
                                                  ->orderBy('created_at', 'desc')
                                                  // ->whereHas('topics')
                                                  ->translate();
                                          }])
                                      ->orderBy('order')
                                      ->orderBy('created_at', 'desc')
                                      ->get();
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function getChapterTopic($request)
    {
        try {
            if($request->id!='overview'){
              if(is_numeric($request->id)){
                  $data['chapter'] = $this->chapterService
                                          ->query()
                                          ->where('id',$request->id)
                                          ->translate()
                                          ->where('status',1)
                                          // ->whereHas('topics')
                                          ->first();
                  if($data['chapter']){
                      $this->incrementHits($data['chapter']);
                      $data['topics']= $this->topicService
                                            ->query()
                                            ->translate()
                                            ->where('chapter_id',$data['chapter']->id)
                                            ->where('status',1)
                                            ->with('files')
                                            ->orderBy('order')
                                            ->paginate(10);
                  }else{
                      $data['topics']=[];
                  }
              }else{
                  $data['chapter'] = $this->chapterService
                                          ->query()
                                          ->translate()
                                          // ->whereHas('topics')
                                          ->where('status',1)
                                          ->with('topics.files')
                                          ->orderBy('order')
                                          ->first();
                  if($data['chapter']){
                      $this->incrementHits($data['chapter']);
                      $data['topics']= $this->topicService
                                            ->query()
                                            ->translate()
                                            ->where('chapter_id',$data['chapter']->id)
                                            ->where('status',1)
                                            ->orderBy('order')
                                            ->with('files')
                                            ->paginate(10);
                  }else{
                      $data['topics']=[];
                  }
              }

            }else{
              $data['chapter'] = $this->chapterService
                                      ->query()
                                      ->where('slug',$request->chapter_slug)
                                      ->translate()
                                      ->where('status',1)
                                      ->first();
              if($data['chapter']){
                  $this->incrementHits($data['chapter']);
                  $data['topics']= $this->topicService
                                        ->query()
                                        ->translate()
                                        ->where('chapter_id',$data['chapter']->id)
                                        ->where('status',1)
                                        ->with('files')
                                        ->orderBy('order')
                                        ->paginate(10);
              }else{
                  $data['topics']=[];
              }

            }
            
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    private function incrementHits($chapter)
    {
      if($chapter->level=='child'){
        $chapter=$chapter->parent;
        $chapter->hits=$chapter->hits+1;
        $chapter->save();
      }
      return;
    }

    
 
}
