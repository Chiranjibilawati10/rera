<?php  
namespace App\Frontend\Profile;

use App\Tools\Response;
use App\User;
use Illuminate\Support\Facades\Auth;
use App\Tools\ImageUploader;

class ProfileService{
    use ImageUploader;
    /**
    * @var profileService
    */
    protected $profileService;

    public function __construct() 
    {
    }

    /**
     * @return mixed
     */
    public function getProfile($request)
    {
        try {
            $data['profile']=Auth::guard('general')->user()->load('profession','municipality');
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function updateProfile($request)
    {
        try {
            $user=Auth::guard('general')->user();
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = Hash::make($request->password);
            $user->is_super = 0;
            $user->save();
            if ($request->file) {
                $this->deleteMultipleUpload($user);
                $this->uploadMultipleFile($request,$user);
            }
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }
 
}
