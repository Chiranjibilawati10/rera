<?php
namespace App\Frontend\Complaint;

use App\Tools\Response;
use DB;
use Illuminate\Support\Facades\Notification;
//use Notification;
use App\Notifications\ComplainFeedbackNotification;

class ComplaintService{
    /**
    * @var complaintService
    */
    protected $complaintService;

    public function __construct()
    {
      $this->complaintService=resolve('App\Repositories\ComplainFeedback\ComplainFeedbackInterface');

    }
    /**
     * @return mixed
     */
    public function storeEntry($request)
    {
        try{
            \DB::beginTransaction();
            $record= $this->complaintService->create($request);
            Notification::route('mail', config('mail.from.address'))
                        ->notify(new ComplainFeedbackNotification($request->only(['subject','message'])));
            $returnData = Response::prepare(false, 'Complain Send Successfully', [], []);
            \DB::commit();
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            \DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

}
