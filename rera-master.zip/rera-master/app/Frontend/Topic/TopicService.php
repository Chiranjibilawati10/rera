<?php  
namespace App\Frontend\Topic;

use App\Tools\Response;

class TopicService{
    /**
    * @var topicService
    */
    protected $topicService;

    public function __construct() 
    {
      $this->topicService=resolve('App\Repositories\Topic\TopicInterface');
    }

    public function getTopic($request)
    {
        try {
            $data['topic'] = $this->topicService
                                    ->query()
                                    ->translate()
                                    ->with('files')
                                    ->where('id',$request->id)
                                    ->first();
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }
 
}
