<?php

namespace App\Http\Controllers;

use App\Model\ComplainFeedback\ComplainFeedback;
use App\Model\Logger\Logger;
use App\Model\Topic\Topic;
use App\Tools\Response;
use App\User;
use Carbon\Carbon;
use DevDojo\Chatter\Models\Discussion;
use Illuminate\Http\Request;
use App\Model\Chapter\Chapter;
use App\Model\Forum\ForumCategory;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }

    public function getBoardData(Request $request)
    {
        if ($request->ajax()){
            try {
                $data['user_count'] = User::count();
                $data['complaint_count'] = ComplainFeedback::count();
                $data['content_count'] = Topic::count();

                $views = Discussion::get('views');
                $data['content_views'] = $views->sum('views');

                $returnData = Response::prepare(false, '', $data, []);
                return response()->json($returnData, 200);
            } catch (\Exception $e) {
                $returnData = Response::prepare(true, $e->getMessage(), [], []);
                return response()->json($returnData, 500);
            }
        }else{
            abort(403);
        }
    }

    public function getUserActivity(Request $request)
    {
        if($request->start && $request->end){
            $from = date($request->start);
            $to = date($request->end);
            $log_general_value=Logger::whereNull('userId')->whereBetween('created_at', [$from, $to])->orderBy('created_at')->get();
            $log_general =  $log_general_value->groupBy(function($date) {
                    return Carbon::parse($date->created_at)->format('m');
                });
            $log_admin_value=Logger::whereNotNull('userId')->whereBetween('created_at', [$from, $to])->orderBy('created_at')->get();
            $log_admin = $log_admin_value->groupBy(function($date) {
                    return Carbon::parse($date->created_at)->format('m');
                });

        }else{
            $log_general_value= Logger::whereNull('userId')->whereYear('created_at', date('Y'))->orderBy('created_at')->get();
            $log_general =$log_general_value->groupBy(function($date) {
                    return Carbon::parse($date->created_at)->format('m');
                });
            $log_admin_value=Logger::whereNotNull('userId')->whereYear('created_at', date('Y'))->orderBy('created_at')->get();
            $log_admin =  $log_admin_value->groupBy(function($date) {
                    return Carbon::parse($date->created_at)->format('m');
                });
        }
        $header = ['Month', 'General User', 'Administrators'];
        $chartData= [$header];
        $chartDataAll = [];
        if(!count($log_general_value) && !count($log_admin_value)){
            return response()->json([]);
        }
        foreach ($log_general as $key=>$value){
            $dateObj   = \DateTime::createFromFormat('!m', $key);
            $monthName = $dateObj->format('F');
            array_push($chartDataAll, [$monthName, $value->count()]);
        }
        foreach ($log_admin as $key=>$value){
            $dateObj   = \DateTime::createFromFormat('!m', $key);
            $monthName = $dateObj->format('F');
            array_push($chartDataAll, [$monthName, $value->count()]);
        }

        $tmp = array();
        foreach($chartDataAll as $value) {
            $tmp[$value[0]][] = $value[1];
        }

        foreach($tmp as $key => $value) {
            $chartData[] = [
                $key,
                isset($value[0])? $value[0] : 0,
                isset($value[1]) ? $value[1] : 0
            ];
        }

        return response()->json($chartData);
    }

    public function getUserRegistration(Request $request)
    {
        if($request->start && $request->end){
            $from = date($request->start);
            $to = date($request->end);
            $users_data=User::where('user_type',0)->whereBetween('created_at', [$from, $to])->orderBy('created_at')->get();
            $users = $users_data->groupBy(function($date) {
                    return Carbon::parse($date->created_at)->format('m');
                });
        }else{
            $users_data=User::where('user_type',0)->whereYear('created_at', date('Y'))->orderBy('created_at')->get();
            $users = $users_data->groupBy(function($date) {
                    return Carbon::parse($date->created_at)->format('m');
                });

        }
        if(!count($users_data)){
            return response()->json([]);
        }
        $header = ['Month','Registered Users'];
        $chartData= [$header];
        if (!$users->isEmpty()){
            foreach ($users as $key=>$value){
                $dateObj   = \DateTime::createFromFormat('!m', $key);
                $monthName = $dateObj->format('F');
                array_push($chartData, [$monthName, $value->count()]);
            }
        }
        else{
            array_push($chartData, ['', 0]);
        }
        return response()->json($chartData);
    }

    public function getTotalChapterView(Request $request)
    {
        $chapters = Chapter::select('id','chapter_name','hits')->orderBy('hits','desc')->where('level','parent')->get();
        $total_hits=$chapters->sum('hits');
        $header = ['Chapter','Count'];
        $chartData= [$header];
        if($total_hits){
            foreach ($chapters  as $key=>$value){
                $name = $value->chapter_name;
                $count_percentage=($value->hits/$total_hits)*100;
                array_push($chartData, [$name, $count_percentage]);
            }
        }
        return response()->json($chartData);
    }

    public function getTotalForumView(Request $request)
    {
        $categories = ForumCategory::select('id','name','hits')->orderBy('hits','desc')->get();
        $total_hits=$categories->sum('hits');
        $header = ['Category','Count'];
        $chartData= [$header];
        if($total_hits){
            foreach ($categories  as $key=>$value){
                $name = $value->name;
                $count_percentage=($value->hits/$total_hits)*100;
                array_push($chartData, [$name, $count_percentage]);
            }
        }
        return response()->json($chartData);
    }
}
