<?php

namespace App\Http\Controllers\Auth;

use App\Model\Auth\AuthUserPermissionGroup;
use App\Tools\Response;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function userList()
    {
        try{
            $data['general_user'] = User::where('user_type', 0)->where('is_super','<>', 1)->orderBy('id', 'DESC')
                ->get()
            ->map(function ($q){
                return [
                    'id' => $q->id,
                    'name' => $q->name,
                    'email' => $q->email,
                    'is_super' => $q->is_super,
                    'user_type' => $q->user_type
                ];
            });

            $data['admin_user'] = User::where('user_type', 1)->where('is_super','<>', 1)->orderBy('id', 'DESC')
                ->get()
                ->map(function ($q){
                    return [
                        'id' => $q->id,
                        'name' => $q->name,
                        'email' => $q->email,
                        'is_super' => $q->is_super,
                        'user_type' => $q->user_type
                    ];
                });

            $returnData = Response::prepare(false, 'listing_success', $data, []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function me()
    {
        try{
            $data['me'] = User::whereId(Auth::user()->id)->with('authGroup.group')->first();

            $returnData = Response::prepare(false, 'listing_success', $data, []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function register(Request $request, AuthUserPermissionGroup $userPermissionGroup)
    {

        if (is_null($request->id)){
            $this->validate($request, [
                'password' => 'required|min:6|confirmed',
                'name' => 'required|string|max:255',
                'email' => 'required|email|max:255|unique:users',
                'user_type' => 'required',
            ]);
        }else{
            $this->validate($request, [
                'name' => 'required|string|max:255',
                'email' => 'required|email|max:255|unique:users,email,'.$request->id,
                'user_type' => 'required',
            ]);

        }
        try{
            if (is_null($request->id)){
                $user = new User();
            }else{
                $user = User::find($request->id);
            }
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = Hash::make($request->password);
            if($request->user_type=='2'){
                $user->is_super = 1;
                $user->user_type = 1;
            }else{
                $user->is_super = 0;
                $user->user_type = $request->user_type;
            }
            $user->save();
            if (!empty($request->groupId) AND $user AND $request->user_type!='2'){
                $userPermissionGroup->USER_ID = $user->id;
                $userPermissionGroup->GROUP_ID = $request->groupId;
                $userPermissionGroup->save();
            }
            $returnData = Response::prepare(false, 'Record Created Successfully', [], []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    /**
     * @todo remove user permission on delete
     */
    public function deleteUser(Request $request)
    {
        $this->validate($request, [
            'USER_ID' => 'required|integer'
        ]);

        try{
            $user = User::find($request->USER_ID);
            $user->delete();
            $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function getUserById($userId)
    {
        try{
            $data['user'] = User::whereId($userId)->with('authGroup.group')->first();
//            dd($data['user']);

            $returnData = Response::prepare(false, 'listing_success', $data, []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function editUser($id)
    {
        try{
            $data['record'] = User::whereId($id)->with('authGroup.group')->first();
//            dd($data['user']);
            $returnData = Response::prepare(false, 'listing_success', $data, []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }

    public function updateProfile(Request $request,$id)
    {
        
        $this->validate($request, [
            'password' => 'nullable|min:6|confirmed',
            'name' => 'required|string|max:255',
        ]);
        try{
            $user = User::find($request->id);
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = Hash::make($request->password);
            $user->save();
            $returnData = Response::prepare(false, 'Profile updated Successfully', [], []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }



    // check and remove
    public function updateUser(Request $request,$id)
    {
        try{
            $this->validateEntry($request,$id);   
            $user=User::find($id);
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = Hash::make($request->password);
            $user->is_super = 0;
            $user->save();
            if (!empty($request->groupId) AND $user){
                $userPermissionGroup->USER_ID = $user->id;
                $userPermissionGroup->GROUP_ID = $request->groupId;
                $userPermissionGroup->save();
            }
            $returnData = Response::prepare(false, 'Record Successfully Updated',[], []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }

    public function validateEntry($request,$id)
    {
        $rules = [
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:users,email,'.$id,
            'groupId' => 'required|integer',
            'password' => 'sometimes|required|min:6|confirmed',
            ];
        $customMessages = [
            'name.required' => 'name was required',
            'email.required' => 'email was required',
            'groupId.required' => 'groupId was required',
            'password.required' => 'password was required'
        ];
        $this->validate($request, $rules, $customMessages);
    }
}
