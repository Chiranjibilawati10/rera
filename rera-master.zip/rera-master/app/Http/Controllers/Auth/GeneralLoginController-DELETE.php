<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class GeneralLoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | GeneralLogin Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/forum';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest:general')->except('logout');
        //$this->middleware('guest')->except('logout');
    }

    public function index()
    {
        return view('frontend.auth.login');
    }

    protected function credentials(Request $request)
    {
        return [
            'email'    => $request->input('email'),
            'password' => $request->input('password')
            //'user_type' => 1
        ];
    }

     /**
     * Handle an authentication attempt.
     *
     * @param  \Illuminate\Http\Request $request
     *
     * @return Response
     */
    public function authenticate(Request $request)
    {
        $credentials = $request->only('email', 'password');
        if (Auth::guard('general')->attempt($credentials)) {
            // Authentication passed...
           // return redirect('/');
            return redirect()->intended('/forum');
        }
    }


    private static function isValidEmail(string $text)
    {
        return filter_var($text, FILTER_VALIDATE_EMAIL);
    }

    protected function guard()
    {
        return Auth::guard('general');
    }

    public function logout()
    {
        \Auth::guard('general')->logout();
        return redirect('/');
    }
}
