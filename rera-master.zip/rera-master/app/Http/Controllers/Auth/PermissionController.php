<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Permission\PermissionRequest;
use App\Model\Auth\AuthGroup;
use App\Model\Auth\AuthPermission;
use App\Model\Auth\AuthPermissionGroup;
use App\Model\Auth\AuthUserPermissionGroup;
use App\Tools\Response;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;

class PermissionController extends Controller
{
    public function listPermission()
    {
        try{
            $data['permission'] = AuthPermission::orderBy('ID', 'ASC')->get();
            $data['menu'] = Config::get('menu.menu');
            $returnData = Response::prepare(false, 'listing_success', $data, []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function storePermission(PermissionRequest $request, AuthPermission $permission)
    {
        try{
            $permission->DISPLAY_NAME = $request->DISPLAY_NAME;
            $permission->CODE = $request->CODE_NAME;
            $permission->MENU_CODE = $request->MENU_CODE;
            $permission->save();

            $returnData = Response::prepare(false, 'Record Created Successfully', [], []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function listAuthGroup()
    {
        try{
            $data['authGroupList'] = AuthGroup::orderBy('ID', 'ASC')->get();
            $returnData = Response::prepare(false, 'listing_success', $data, []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function storeAuthGroup(Request $request, AuthGroup $group)
    {
        $this->validate($request, [
            'NAME' => 'required|string|max:255'
        ]);

        try{
            $group->NAME = $request->NAME;
            $group->save();

            $returnData = Response::prepare(false, 'Record Created Successfully', [], []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function getGroupPermission(Request $request, AuthPermissionGroup $permissionGroup)
    {
        try{
            if ($request->GROUP_ID == null){
                $data['groupPermissions'] = [];
                $data['permissions'] = [];
                $data['permissionInGroup'] = [];
                $returnData = Response::prepare(false, 'listing_success', $data, []);
                return response()->json($returnData, 200);
            }

            $menuCode = collect(Config::get('menu.menu'));
//            dd($menuCode);
            $gpArray = [];
            $data['groupPermissions'] = $groupPermissions = $permissionGroup::where('GROUP_ID', $request->GROUP_ID)->get();

            foreach($groupPermissions as $val){
                $gpArray[] = $val->PERMISSION_ID;
            }
            $data['permissions'] = $permissions = AuthPermission::all();

            $permissionInGroupColl = new Collection();
            foreach($permissions as $key=>$value){
                if (in_array($value->ID,$gpArray)){
                    $check = true;
                }else{
                    $check = false;
                }
                $menu = $menuCode->where('code', $value->MENU_CODE)->first();

                $permissionInGroupColl->push([
                    'permissionId' => $value->ID,
                    'DISPLAY_NAME' => $value->DISPLAY_NAME,
                    'menu_code' => $value->MENU_CODE,
                    'menu_description' =>  $menu['description'] ?: 'na',
                    'check' => $check,
                ]);
            }

            $data['permissionInGroup'] = $permissionInGroupColl->groupBy('menu_code');
            $returnData = Response::prepare(false, 'listing_success', $data, []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function storeGroupPermission(Request $request)
    {
        $this->validate($request,[
            'GROUP_ID' => 'required|integer'
        ]);
        try{
            foreach ($request->PERMISSION as $value){
                foreach($value as $permission)
                if ($permission['check'] == 'true'){
                    if (!AuthPermissionGroup::where('GROUP_ID', $request->GROUP_ID)->where('PERMISSION_ID', $permission['permissionId'])->first()){
                        $groupPermission = new AuthPermissionGroup();
                        $groupPermission->GROUP_ID = $request->GROUP_ID;
                        $groupPermission->PERMISSION_ID = $permission['permissionId'];
                        $groupPermission->save();
                    }
                }else{
                    if ($deletePermission = AuthPermissionGroup::where('GROUP_ID', $request->GROUP_ID)->where('PERMISSION_ID', $permission['permissionId'])->first()){
                        $deletePermission->delete();
                    }
                }
            }
            $returnData = Response::prepare(false, 'Permission Assigned Successfully', [], []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    /**
     * @todo Remove all assigned permissions from group after delete
     */
    public function deleteAuthGroup(Request $request)
    {
        $this->validate($request,[
            'ID' =>'required|integer',
        ]);

        try{
            $authGroup = AuthGroup::find($request->ID);
            $authGroup->delete();

            $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function storeUserAuthGroup(Request $request, AuthUserPermissionGroup $userPermissionGroup)
    {
        $this->validate($request,[
            'USER_ID' =>'required|integer',
            'GROUP_ID' => 'required|integer'
        ]);
        try{
            if (!AuthUserPermissionGroup::where('USER_ID', $request->USER_ID)->where('GROUP_ID', $request->GROUP_ID)->first()){
                $userPermissionGroup->USER_ID = $request->USER_ID;
                $userPermissionGroup->GROUP_ID = $request->GROUP_ID;
                $userPermissionGroup->save();

                $returnData = Response::prepare(false, 'Permission Assigned Successfully', [], []);
                return response()->json($returnData, 200);
            }
            $returnData = Response::prepare(true, 'Permission Already Assigned', [], []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function getUserAuthGroup(Request $request)
    {
        $this->validate($request, [
            'USER_ID' => 'required|integer'
        ]);
        try{
            $groupName = [];
            $userAuthGroup = AuthUserPermissionGroup::where('USER_ID', $request->USER_ID)->with(['group','user'])->orderBy('GROUP_ID')->get();
            if ($userAuthGroup){
                foreach ($userAuthGroup as $value){
                    $groupName[] = [
                        'authUserPermissionId' => $value->ID,
                        'groupName' => $value->group->NAME,
                    ];
                }
            }
            $data['userAuthGroup'] = $groupName;
            if (!$userAuthGroup->isEmpty()) {
                $data['userName'] = $userAuthGroup[0]->user->name;
            }
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function deleteUserAuthGroup($authUserPermissionId)
    {
        try{
            $userAuthGroup = AuthUserPermissionGroup::find($authUserPermissionId);
            $userAuthGroup->delete();

            $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }
}
