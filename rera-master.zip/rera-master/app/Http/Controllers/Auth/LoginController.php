<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/admin';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    protected function credentials(Request $request)
    {
        return [
            'email'    => $request->input('email'),
            'password' => $request->input('password')
            //'user_type' => 1
        ];
    }

    protected function attemptLogin(Request $request)
    {
        //check user type
        $userType = User::where('email', $request->email)->first('user_type');
        if (isset($userType) AND $userType->user_type === 1){
            $this->redirectTo = '/admin';
            $this->guard('general')->attempt(
                $this->credentials($request), $request->filled('remember')
            );
//            return $this->guard('web')->attempt(
////                $this->credentials($request), $request->filled('remember')
////            );

            return Auth::guard()->attempt(
                $this->credentials($request), $request->filled('remember')
            );

        }else{
            $this->redirectTo = '/';
            return $this->guard('general')->attempt(
                $this->credentials($request), $request->filled('remember')
            );
        }

    }
    protected function guard($guard = '')
    {
        return Auth::guard($guard);
    }
    public function logout()
    {
        \Auth::guard('web')->logout();
        \Auth::guard('general')->logout();
        return redirect('/');
    }

}
