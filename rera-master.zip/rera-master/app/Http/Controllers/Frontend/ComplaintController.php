<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Frontend\Complaint\ComplaintService;


class ComplaintController extends Controller
{
    protected $complaintService;
    /**
     * ComplaintController constructor.
     *
     * @param ComplaintService $complaintService
     */
    public function __construct(ComplaintService $complaintService)
    {
        $this->complaintService=$complaintService;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validateEntry($request);
        return $this->complaintService
            ->storeEntry($request);
    }


    public function validateEntry($request)
    {
        $rules = [
            'subject' => 'required',
            'type' => 'required',
            'message' => 'required',
            'send_from_email' => 'required'
        ];
        $customMessages = [
            'subject.required' => 'Please, write subject of complaint',
            'type.required'=>'select complaint type',
            'message.required' => 'Please, write complaint message',
            'send_from_email.requred' => 'Please, write email address'
        ];
        $this->validate($request, $rules, $customMessages);
    }
}
