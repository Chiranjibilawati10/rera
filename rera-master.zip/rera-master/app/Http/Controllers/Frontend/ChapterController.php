<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Frontend\Chapter\ChapterService;

class ChapterController extends Controller
{
    protected $chapterService;
    /**
     * ChapterController constructor.
     *
     * @param ChapterService $ChapterService
    */
    public function __construct(ChapterService $chapterService)
    {
        $this->chapterService=$chapterService;
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function getChapters(Request $request)
    {
        return $this->chapterService
                    ->getChapters($request);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function getChapterTopic(Request $request)
    {
        return $this->chapterService
                    ->getChapterTopic($request);
    }
}
