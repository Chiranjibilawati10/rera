<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Frontend\Faq\FaqService;

class FaqController extends Controller
{
    protected $faqService;
    /**
     * FaqController constructor.
     *
     * @param FaqService $FaqService
    */
    public function __construct(FaqService $faqService)
    {
        $this->faqService=$faqService;
    }

    public function getFaqCategories(Request $request)
    {
        return  $this->faqService
                    ->getFaqCategories($request);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function getFaqs(Request $request)
    {
        return $this->faqService
                    ->getFaqs($request);
    }
}
