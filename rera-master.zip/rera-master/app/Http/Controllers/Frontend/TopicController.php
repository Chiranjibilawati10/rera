<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Frontend\Topic\TopicService;


class TopicController extends Controller
{
    protected $topicService;
    /**
     * TopicController constructor.
     *
     * @param TopicService $topicService
    */
    public function __construct(TopicService $topicService)
    {
        $this->topicService=$topicService;
        // $this->middleware('auth');
    }

    public function getTopic(Request $request)
    {
        return $this->topicService
                    ->getTopic($request);
    }
}
