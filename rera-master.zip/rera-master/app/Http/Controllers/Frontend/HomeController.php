<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Frontend\Home\HomeService;
use App\Tools\Response;


class HomeController extends Controller
{
    protected $homeService;
    /**
     * HomeController constructor.
     *
     * @param HomeService $homeService
    */
    public function __construct(HomeService $homeService)
    {
        $this->homeService=$homeService;
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return $this->homeService
                    ->getHomePage();
    }

    public function getConsultantPool()
    {
        return $this->homeService
                    ->getConsultantPool();

    }

    public function download(Request $request)
    {
        if($request->all || empty($request->chapters)){
          $chapters=[];
        }else{
          $chapters=$request->chapters;
        }
        $zip_file = 'retechnologies.zip';
        $zip = new \ZipArchive();
        $zip->open($zip_file, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);
        $path = storage_path('app/public/re_technology');
        $files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($path));
        foreach ($files as $name => $file)
        {
              // We're skipping all subfolders
            if (!$file->isDir()) {
                $filePath     = $file->getRealPath();
                  // extracting filename with substr/strlen
                $relativePath = substr($filePath, strlen($path) + 1);
                if($this->checkIfChapterExist($relativePath,$chapters)){
                  $zip->addFile($filePath, $relativePath);
                }
            }
        }
        $zip->close();
        return response()->download($zip_file);
    }

    public function setServerLocale(Request $request)
    {
      $locale=($request->locale=='ne')?'ne':'en';
      session(['ln' =>$locale]);
      $returnData = Response::prepare(false, 'success',[], []);
      return response()->json($returnData, 200);
    }

    private function checkIfChapterExist($string,$array)
    {
      if(!empty($array)){
        foreach($array as $chapter){
            if(strpos($string, $chapter) !== FALSE){
              return true;
            }
        }
        return false;

      }
      return true;
    }
}
