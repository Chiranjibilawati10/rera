<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Frontend\RegistrationProcess\RegistrationProcessService;

class RegistrationProcessController extends Controller
{
    protected $registrationProcessService;
    /**
     * EmailController constructor.
     *
     * @param registrationProcess $registrationProcessService
    */
    public function __construct(RegistrationProcessService $registrationProcessService)
    {
        //$this->middleware('auth:general');
        $this->registrationProcessService=$registrationProcessService;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function validateEmail(Request $request)
    {
        $user=\Auth::guard('general')->user();
        if($user && !$user->hasVerifiedEmail()){
            return view('auth.verify');
        }
        return redirect('/login');
    }
}
