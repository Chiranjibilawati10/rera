<?php

namespace App\Http\Controllers\Frontend\Auth;

use App\Model\Auth\AuthUserPermissionGroup;
use App\Tools\Response;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{

    public function me()
    {
        try{
            $data['me'] = User::whereId(Auth::user()->id)->with('authGroup.group')->first();

            $returnData = Response::prepare(false, 'listing_success', $data, []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

   

   
    public function getUserById($userId)
    {
        try{
            $data['user'] = User::whereId($userId)->with('authGroup.group')->first();
//            dd($data['user']);

            $returnData = Response::prepare(false, 'listing_success', $data, []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function editUser($id)
    {
        try{
            $data['record'] = User::whereId($id)->with('authGroup.group')->first();
//            dd($data['user']);
            $returnData = Response::prepare(false, 'listing_success', $data, []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }

    public function updateProfile(Request $request,$id)
    {
        $this->validate($request, [
            'password' => 'nullable|min:6|confirmed',
            'name' => 'required|string|max:255',
        ]);
        try{
            $user = User::find($request->id);
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = Hash::make($request->password);
            $user->save();
            $returnData = Response::prepare(false, 'Profile updated Successfully', [], []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }

    public function validateEntry($request,$id)
    {
        $rules = [
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:users,email,'.$id,
            'groupId' => 'required|integer',
            'password' => 'sometimes|required|min:6|confirmed',
            ];
        $customMessages = [
            'name.required' => 'name was required',
            'email.required' => 'email was required',
            'groupId.required' => 'groupId was required',
            'password.required' => 'password was required'
        ];
        $this->validate($request, $rules, $customMessages);
    }
}
