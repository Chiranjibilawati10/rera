<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Frontend\Profile\ProfileService;
use App\User;

class ProfileController extends Controller
{
    protected $profileService;
    /**
     * ProfileController constructor.
     *
     * @param ProfileService $ProfileService
    */
    public function __construct(ProfileService $profileService)
    {
        $this->profileService=$profileService;
    }

    public function getProfile(Request $request)
    {
        return  $this->profileService
                     ->getProfile($request);
    }

    public function updateProfile(Request $request)
    {
        $this->validateEntry($request); 
        return  $this->profileService
                     ->updateProfile($request);
    }

    public function validateEntry($request)
    {
        $rules = [
                'name' => 'required',
                'email' => 'required',
                'profession_id' => 'required',
                'password' => 'required|min:6|confirmed',
            ];
        $customMessages = [
            'name.required' => 'name was required',
            'email.required' => 'email was required',
            'profession_id.required'=>'profession name was required'
        ];
        $this->validate($request, $rules, $customMessages);
    }
}
