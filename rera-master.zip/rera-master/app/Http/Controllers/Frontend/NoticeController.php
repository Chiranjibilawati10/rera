<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Frontend\Notice\NoticeService;


class NoticeController extends Controller
{
    protected $noticeService;
    /**
     * NoticeController constructor.
     *
     * @param NoticeService $noticeService
    */
    public function __construct(NoticeService $noticeService)
    {
        $this->noticeService=$noticeService;
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function getNotices(Request $request)
    {
        return $this->noticeService
                    ->getNotices($request);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function getNotice(Request $request)
    {
        return $this->noticeService
                    ->getNotice($request);
    }
}
