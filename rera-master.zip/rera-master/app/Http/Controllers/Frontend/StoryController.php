<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Frontend\Story\StoryService;


class StoryController extends Controller
{
    protected $storyService;
    /**
     * storyController constructor.
     *
     * @param storyService $storyService
    */
    public function __construct(StoryService $storyService)
    {
        $this->storyService=$storyService;
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function getStories(Request $request)
    {
        return $this->storyService
                    ->getStories($request);
    }

    public function getStory(Request $request)
    {
        return $this->storyService
                    ->getStory($request);
    }
}
