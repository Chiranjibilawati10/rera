<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Tools\Response;

class OccupationController extends Controller
{
    protected $occupationService;
    /**
     * OccupationController constructor.
     *
     * @param OccupationService $occupationService
    */
    public function __construct()
    {
        $this->occupationService=resolve('App\Repositories\OccupationSector\OccupationSectorInterface');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function getOccupation()
    {
        try {
            $data['occupations'] =  $this->occupationService
                                         ->query()
                                         ->translate()
                                         ->pluck('name','id');
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function getProfession(Request $request)
    {
        try {
            $sector =  $this->occupationService
                            ->query()
                            ->translate()
                            ->where('id',$request->id)
                            ->first();
            if($sector){
                $data['profession_list']=$sector->professions()
                                                ->pluck('name','id');
            }else{
                $data['profession_list']=false;
            }
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }
}
