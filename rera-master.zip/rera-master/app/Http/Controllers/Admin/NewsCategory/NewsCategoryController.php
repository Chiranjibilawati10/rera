<?php

namespace App\Http\Controllers\Admin\NewsCategory;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\NewsCategory\NewsCategoryInterface;

class NewsCategoryController extends Controller
{
    protected $newscategoryRepository;
    /**
     * NewsCategory constructor.
     *
     * @param NewsCategoryInterface $newscategoryRepository
    */
    public function __construct(NewsCategoryInterface $newscategoryRepository)
    {
        $this->newscategoryRepository = $newscategoryRepository;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return $this->newscategoryRepository->getData();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validateEntry($request);
        return $this->newscategoryRepository
                    ->storeEntry($request);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return $this->newscategoryRepository
                    ->getEntry($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validateEntry($request);
        return $this->newscategoryRepository
                    ->updateEntry($request,$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return $this->newscategoryRepository
                    ->deleteEntry($id);
    }

    public function validateEntry($request)
    {
        $rules = [
                'news_category_name' => 'required',
                'news_category_name_ne' => 'required'
            ];
        $customMessages = [
            'news_category_name.required' => 'Category name was required',
            'news_category_name_ne.required'=>'Category name in nepali was required'
        ];
        $this->validate($request, $rules, $customMessages);
    }
}
