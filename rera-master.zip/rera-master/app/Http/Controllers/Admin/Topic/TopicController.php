<?php

namespace App\Http\Controllers\Admin\Topic;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Topic\TopicInterface;
use Illuminate\Support\Facades\Validator;

class TopicController extends Controller
{
    protected $topicRepository;
    /**
     * TopicController constructor.
     *
     * @param TopicInterface $topicRepository
    */
    public function __construct(TopicInterface $topicRepository)
    {
        $this->topicRepository = $topicRepository;

    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        return $this->topicRepository->getData($request);
    }

    public function trashedindex(Request $request)
    {
        return $this->topicRepository->getTrashedData($request);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(!$request->dragged){
            $this->validateEntry($request); 
        }
        return $this->topicRepository
                    ->storeEntry($request);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return $this->topicRepository
                    ->getEntry($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validateEntry($request);
        return $this->topicRepository
                    ->updateEntry($request,$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return $this->topicRepository
                    ->deleteEntry($id);
    }

    public function trasheddestroy($id)
    {
        return $this->topicRepository
                    ->deleteTrashedEntry($id);
    }

     public function restoreTopic($id)
     {
        return $this->topicRepository
                    ->restoreTopic($id);

     }

    public function validateEntry($request)
    {
        $rules = [
                'renewable_id' => 'required',
                're_category_id' => 'sometimes|required',
                'sub_category_id' => 'sometimes|required',
                'chapter_id' => 'required',
                'title' => 'required',
                'title_ne' => 'required',
//                'content_type' => 'required',
                // 'summary' => 'required',
                // 'summary_ne' => 'required',
            ];
        $customMessages = [
            'renewable_id.required' => 'Please, select renewable name.',
            're_category_id.required'=>'Please, select renewable category name.',
            'sub_category_id.required' => 'Please, select renewable sub category.',
            'chapter_id.required' => 'Please, select chapter.',
            'title.required' => 'Please, write title in english.',
            'title_ne.required' => 'Please, write title in nepali.',
//            'content_type.required' => 'Plese, write content type.',
            // 'summary.required' => 'Please, write summary in english.',
            // 'summary_ne.required' => 'Please, write summary in nepali.'
        ];
        $this->validate($request, $rules, $customMessages);
    }

    public function getChildren(int $category_id)
    {
        return  $this->topicRepository
                    ->getChildren($category_id);
    }

    public function getChapterChildren(int $chapter_id)
    {
        return  $this->topicRepository
                    ->getChapterChildren($chapter_id);

    }

}
