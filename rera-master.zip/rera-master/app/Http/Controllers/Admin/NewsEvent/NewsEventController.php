<?php

namespace App\Http\Controllers\Admin\NewsEvent;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\NewsEvents\NewsEventsInterface;
use App\Http\Requests\NewsEventsRequest;
use Illuminate\Support\Facades\Validator;

class NewsEventController extends Controller
{

    protected $newseventsRepository;

    public function __construct(NewsEventsInterface $newseventsRepository)
    {
        $this->newseventsRepository = $newseventsRepository;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return $this->newseventsRepository->getData();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validateEntry($request);   
        return $this->newseventsRepository
                    ->storeEntry($request);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return $this->newseventsRepository->getEntry($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validateEntry($request);
        return $this->newseventsRepository
                    ->updateEntry($request,$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return $this->newseventsRepository
                    ->deleteEntry($id);
    }

    public function validateEntry($request)
    {
        $rules = [
                'title' => 'required',
                'title_ne' => 'required',
                'content' => 'required',
                'content_ne' => 'required',
               // 'external_link' => 'required',
                'category_id'=>'required'
            ];
        $customMessages = [
            'title.required' => 'Title name was required',
            'title_ne.required'=>'Title name in nepali was required',
            'content.required' => 'The content was required.',
            'content_ne.required' => 'The content in nepali was required.',
           // 'external_link.required' => 'Please, add external link.',
            'category_id'=>'The Category was required'
        ];
        $this->validate($request, $rules, $customMessages);
    }
}
