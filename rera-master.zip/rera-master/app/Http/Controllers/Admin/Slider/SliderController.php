<?php

namespace App\Http\Controllers\Admin\Slider;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Slider\SliderInterface;

class SliderController extends Controller
{
    protected $sliderRepository;
    /**
     * SliderController constructor.
     *
     * @param SliderInterface $sliderRepository
    */
    public function __construct(SliderInterface $sliderRepository)
    {
        $this->sliderRepository = $sliderRepository;
       
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return $this->sliderRepository->getData();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validateEntry($request);
        return $this->sliderRepository
                    ->storeEntry($request);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return $this->sliderRepository
                    ->getEntry($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validateEntry($request);
        return $this->sliderRepository
                    ->updateEntry($request,$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return $this->sliderRepository
                    ->deleteEntry($id);
    }

    public function validateEntry($request)
    {
        $rules = [
                'title' => 'required',
                // 'title_ne' => 'required',
                // 'description' => 'required',
                // 'description_ne' => 'required',
                // 'status' => 'required',
                //'file'=>'required'
            ];
        $customMessages = [
            'title.required' => 'Name was required',
            // 'title_ne.required' => 'answer was required',
            // 'description.required' => 'answer was required',
            // 'description_ne.required' => 'answer was required',
            // 'status.required' => 'answer was required',
            //'file.required'=>'file was required'
        ];
        $this->validate($request, $rules, $customMessages);
    }
}
