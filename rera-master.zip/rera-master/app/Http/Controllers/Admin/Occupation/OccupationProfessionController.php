<?php

namespace App\Http\Controllers\Admin\Occupation;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\OccupationProfession\OccupationProfessionInterface;
     
class OccupationProfessionController extends Controller
{

    protected $occupationProfessionRepository;
    /**
     * OccupationSectorController constructor.
     *
     * @param OccupationSectorInterface $occupationProfessionRepository
    */
    public function __construct(OccupationProfessionInterface $occupationProfessionRepository)
    {
        $this->occupationProfessionRepository = $occupationProfessionRepository;
       
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return $this->occupationProfessionRepository->getData();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return $this->occupationProfessionRepository
                    ->storeEntry($request);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return $this->occupationProfessionRepository
                    ->getEntry($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        return $this->occupationProfessionRepository
                    ->updateEntry($request,$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return $this->occupationProfessionRepository
                    ->deleteEntry($id);
    }
}
