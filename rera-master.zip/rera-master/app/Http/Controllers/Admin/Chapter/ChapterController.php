<?php

namespace App\Http\Controllers\Admin\Chapter;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Chapter\ChapterInterface;
use Illuminate\Support\Facades\Validator;

class ChapterController extends Controller
{

    protected $chapterRepository;
    /**
     * ChapterController constructor.
     *
     * @param ChapterInterface $chapterRepository
    */
    public function __construct(ChapterInterface $chapterRepository)
    {
        $this->chapterRepository = $chapterRepository;
       
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        return $this->chapterRepository->getData($request);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(!$request->dragged){
            $this->validateEntry($request); 
        }
        return $this->chapterRepository
                    ->storeEntry($request);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return $this->chapterRepository
                    ->getEntry($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validateEntry($request);
        return $this->chapterRepository
                    ->updateEntry($request,$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return $this->chapterRepository
                    ->deleteEntry($id);
    }

    public function validateEntry($request)
    {
        $rules = [
                'chapter_name' => 'required',
               //'chapter_name_ne' => 'required'
            ];
        $customMessages = [
            'chapter_name.required' => 'Chapter name was required',
           // 'chapter_name_ne.required'=>'Chapter name in nepali was required'
        ];
        $this->validate($request, $rules, $customMessages);
    }
}
