<?php

namespace App\Http\Controllers\Admin\Activity;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Chapter\ChapterInterface;
use Illuminate\Support\Facades\Validator;
use App\Tools\Response;
use App\Model\Activity;
use DB;

class ActivityController extends Controller
{

   public function index(Request $request)
   {
       try{
            $query=Activity::query();
            $this->search($query,$request);
            $data['activities']=$query->with('user')->paginate($request->pageNumber);
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

   }

   public function destroy($id)
   {
       try{
            if($id=='all'){
                DB::table('laravel_logger_activity')->delete();
            }
            DB::table('laravel_logger_activity')->where('id',$id)->delete();
            $data=[];
            $returnData = Response::prepare(false, 'Activity deleted', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

   }

    private function search($query,$request)
    {
        $columns = ['userType','ipAddress','description'];
        $search = $request->input('search');
        if ($search){
           $query->where(function($query) use($columns, $search){
               foreach($columns as $value){
                $query->orWhere($value, 'like', '%'. $search . '%');
               }
            })->orwhereHas('user', function ($query) use ($search){
                $query->where('name', 'like', '%'.$search.'%');
            });
        }
        return $query;
    }
}
