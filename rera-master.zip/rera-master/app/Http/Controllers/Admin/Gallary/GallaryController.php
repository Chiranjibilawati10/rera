<?php

namespace App\Http\Controllers\Admin\Gallary;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Gallary\GallaryInterface;
use Illuminate\Support\Facades\Validator;

class GallaryController extends Controller
{

    protected $gallaryRepository;
    /**
     * GallaryController constructor.
     *
     * @param GallaryInterface $GallaryRepository
    */
    public function __construct(GallaryInterface $gallaryRepository)
    {
        $this->gallaryRepository = $gallaryRepository;
       
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        return $this->gallaryRepository->getData($request);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validateEntry($request);   
        return $this->gallaryRepository
                    ->storeEntry($request);
    }


    public function upload(Request $request,$id)
    {  
        return $this->gallaryRepository
                    ->upload($request,$id);
    }

    public function gallaryDelete(Request $request,$id)
    {  
        return $this->gallaryRepository
                    ->gallaryDelete($request,$id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return $this->gallaryRepository
                    ->getEntry($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validateEntry($request);
        return $this->gallaryRepository
                    ->updateEntry($request,$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return $this->gallaryRepository
                    ->deleteEntry($id);
    }

    public function validateEntry($request)
    {
        // $rules = [
        //     'album_id' => 'required',
        //        //'Gallary_name_ne' => 'required'
        //     'file'=>'required'
        //     ];
        // $customMessages = [
        //     'file.required' => 'File was required',
        //     'album_id.required' => 'Album was required',
        //    // 'Gallary_name_ne.required'=>'Gallary name in nepali was required'
        // ];
        // $this->validate($request, $rules, $customMessages);
    }
}
