<?php

namespace App\Http\Controllers\Admin\Retechnology;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\SubCategory\SubCategoryInterface;
use Illuminate\Support\Facades\Validator;


     
class SubCategoryController extends Controller
{
    protected $subcategoryRepository;
    /**
     * subcategoryController constructor.
     *
     * @param subcategoryInterface $subcategoryRepository
    */
    public function __construct(SubCategoryInterface $subcategoryRepository)
    {
        $this->subcategoryRepository = $subcategoryRepository;
       
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return $this->subcategoryRepository->getData();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validateEntry($request);   
        return $this->subcategoryRepository
                    ->storeEntry($request);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return $this->subcategoryRepository
                    ->getEntry($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validateEntry($request);
        return $this->subcategoryRepository
                    ->updateEntry($request,$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return $this->subcategoryRepository
                    ->deleteEntry($id);
    }

    public function validateEntry($request)
    {
        $rules = [
                'name' => 'required',
                'name_ne' => 'required',
                'description' => 'required',
                'description_ne' => 'required',
                'parent_id'=>'required'
            ];
        $customMessages = [
            'name.required' => ' name was required',
            'name_ne.required' => ' name was required',
            'description.required' => 'description was required',
            'description_ne.required' => 'description was required',
            'parent_id.required'=>'RE Category was required'
        ];
        $this->validate($request, $rules, $customMessages);
    }
}
