<?php

namespace App\Http\Controllers\Admin\Retechnology;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Category\CategoryInterface;
use Illuminate\Support\Facades\Validator;


     
class CategoryController extends Controller
{
    protected $categoryRepository;
    /**
     * categoryController constructor.
     *
     * @param categoryInterface $categoryRepository
    */
    public function __construct(CategoryInterface $categoryRepository)
    {
        $this->categoryRepository = $categoryRepository;
       
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return $this->categoryRepository->getData();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validateEntry($request);   
        return $this->categoryRepository
                    ->storeEntry($request);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return $this->categoryRepository
                    ->getEntry($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validateEntry($request);
        return $this->categoryRepository
                    ->updateEntry($request,$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return $this->categoryRepository
                    ->deleteEntry($id);
    }

    public function validateEntry($request)
    {
        $rules = [
                'name' => 'required',
                'name_ne' => 'required',
                'description' => 'required',
                'description_ne' => 'required',
                'parent_id'=>'required'
            ];
        $customMessages = [
            'name.required' => ' name was required',
            'name_ne.required' => ' name was required',
            'description.required' => 'description was required',
            'description_ne.required' => 'description was required',
            'parent_id.required'=>'RE energy was required'
        ];
        $this->validate($request, $rules, $customMessages);
    }
}
