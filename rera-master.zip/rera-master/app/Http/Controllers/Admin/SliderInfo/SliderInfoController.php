<?php

namespace App\Http\Controllers\Admin\SliderInfo;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Slider\SliderInterface;
use App\Model\SliderInfo\SliderInfo;
use App\Tools\Response;


class SliderInfoController extends Controller
{
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        try {
            $data['records']=SliderInfo::with('createdBy','updatedBy')->get();
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            $this->validateEntry($request);
            $request['created_id']=auth()->user()->id;
            SliderInfo::create($request->all());
            $returnData = Response::prepare(false, 'Record Created',[], []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        try {
            $data['record']=SliderInfo::find($id);
            $returnData = Response::prepare(false, 'Record Updated', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {
            $this->validateEntry($request);
            $request['updated_id']=auth()->user()->id;
            $data['record']=SliderInfo::find($id);
            $data['record']->update($request->all());
            $returnData = Response::prepare(false, 'Record Updated', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $data['record']=SliderInfo::find($id);
            $data['record']->delete();
            $returnData = Response::prepare(false, 'Record Deleted', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function validateEntry($request)
    {
        // $rules = [
        //         'title' => 'required',
        //         'title_ne'=>'required',
        //         'description'=>'required',
        //         'description_ne'=>'required'
        //         // 'title_ne' => 'required',
        //         // 'description' => 'required',
        //         // 'description_ne' => 'required',
        //         // 'status' => 'required',
        //         //'file'=>'required'
        //     ];
        // $customMessages = [
        //     'title.required' => 'Title was required',
        //     'title_ne.required'=>'Title Nepali was required',
        //     'description.required'=>'Description was required',
        //     'description_ne.required'=>'Description Nepali was required'
        //     // 'title_ne.required' => 'answer was required',
        //     // 'description.required' => 'answer was required',
        //     // 'description_ne.required' => 'answer was required',
        //     // 'status.required' => 'answer was required',
        //     //'file.required'=>'file was required'
        // ];
        // $this->validate($request, $rules, $customMessages);
        $rules = [
                'title' => 'required',
               //'chapter_name_ne' => 'required'
            ];
        $customMessages = [
            'title.required' => 'Chapter name was required',
           // 'chapter_name_ne.required'=>'Chapter name in nepali was required'
        ];
        $this->validate($request, $rules, $customMessages);
    }
}
