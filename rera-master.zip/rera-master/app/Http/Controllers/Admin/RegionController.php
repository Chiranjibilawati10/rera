<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Tools\Response;
use App\Model\Region\Province;
use App\Model\Region\District;
use App\Model\Region\Municipality;

class RegionController extends Controller
{
    protected $regionService;
    /**
     * RegionController constructor.
     *
     * @param regionService $regionService
    */
    public function __construct()
    {
        //$this->regionService=resolve('App\Repositories\RegionSector\RegionSectorInterface');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function provinces()
    {
        try {
            $data['provinces'] =Province::query()
                                             ->translate()
                                             ->pluck('name','ID');
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }
   

    public function districts(Request $request)
    {
        try {
            $data['district_list'] =District::query()
                                            ->translate()
                                            ->where('PROVIENCE_REGION_ID',$request->id)
                                             ->pluck('name','ID');
            if(!count($data['district_list'])){
                $data['district_list'] =false;
            }
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function municipalities(Request $request)
    {
        try {
            $data['municipalities'] =Municipality::query()
                                                   ->translate()
                                                   ->where('DISTRICT_ID',$request->id)
                                                   ->pluck('name','ID');
            if(!count($data['municipalities'])){
                $data['municipalities'] =false;
            }
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }
}
