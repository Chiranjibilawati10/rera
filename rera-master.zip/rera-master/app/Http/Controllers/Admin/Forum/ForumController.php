<?php

namespace App\Http\Controllers\Admin\Forum;

use App\Http\Controllers\Controller;
use App\Model\Forum\ForumCategory;
use App\Model\Forum\ForumDiscussion;
use App\Tools\Response;
use Illuminate\Http\Request;

class ForumController extends Controller
{
    public function categoryList(Request $request)
    {
        if($request->ajax()) {
            try {
                $data['categories'] = ForumCategory::orderBy('created_at', 'desc')->get();
                $returnData = Response::prepare(false, 'list_success', $data, []);
                return response()->json($returnData, 200);
            } catch (\Exception $e) {
                $returnData = Response::prepare(true, $e->getMessage(), [], []);
                return response()->json($returnData, 500);
            }
        }else{
            abort(403);
        }
    }

    public function storeCategory(Request $request)
    {
        $this->validate($request,[
            'name' => 'required|string',
            'slug' => 'required|string|unique:chatter_categories'
        ]);
        try{
            $cat = new ForumCategory();
            $cat->name = $request->name;
            $cat->name_ne = $request->name_ne;
            $cat->slug = $request->slug;
            $cat->color = $request->color;
            $cat->save();

            $returnData = Response::prepare(false, 'store_success', [], []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function getCategory($id)
    {
        try{
            $data['category'] =ForumCategory::where('id',$id)->first();
            $returnData = Response::prepare(false, 'store_success',$data, []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function updateCategory(Request $request)
    {
        $this->validate($request,[
            'name' => 'required|string',
            'slug' => 'required|string|unique:chatter_categories,slug,'.$request->id
        ]);
        try{
            $cat = ForumCategory::whereId($request->id)->first();
            $cat->name = $request->name;
            $cat->name_ne = $request->name_ne;
            $cat->slug = $request->slug;
            $cat->color = $request->color;
            $cat->save();
            $returnData = Response::prepare(false, 'Record Updated Successfully', [], []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function postList()
    {
        try{
            $data['postList'] = ForumDiscussion::orderBy('id', 'desc')
                ->with(['category', 'author'])
                ->whereNull('deleted_at')
                ->get()
                ->map(function($query){
                    return [
                        'id'=>$query->id,
                        'title' => $query->title,
                        'slug' => $query->slug,
                        'category' => $query->category->name,
                        'category_slug' => $query->category->slug,
                        'category_color' => $query->category->color,
                        'created_by' => $query->author->name,
                        'created_by_id' => $query->author->id,
                        'views' => $query->views,
                        'created_at' => $query->created_at->diffForHumans()
                    ];
                });

            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }


    public function trashedPostList()
    {
        try{
            $data['trashedPostList'] = ForumDiscussion::onlyTrashed('id', 'desc')
                ->with(['category', 'author'])
                // ->where('deleted_at', '!=', '')
                ->get()
                ->map(function($query){
                    return [
                        'id'=>$query->id,
                        'title' => $query->title,
                        'slug' => $query->slug,
                        'category' => $query->category->name,
                        'category_slug' => $query->category->slug,
                        'category_color' => $query->category->color,
                        'created_by' => $query->author->name,
                        'created_by_id' => $query->author->id,
                        'created_at' => $query->created_at->diffForHumans()
                    ];
                });
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    public function deletePost($id)
    {
        try{
            ForumDiscussion::where('id',$id)->delete();
            $returnData = Response::prepare(false, 'Record Deleted Successfully',[], []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }

    public function restoreTrashedEntry($id)
    {
        try{
            ForumDiscussion::withTrashed()
                ->where('id', $id)
                ->update(['deleted_at' => null]);
            $returnData = Response::prepare(false, 'Record Restored Successfully', [],[]);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }
    
    public function deleteTrashedEntry($id)
    {
        try{
            ForumDiscussion::where('id',$id)->forceDelete();
            $returnData = Response::prepare(false, 'Record Deleted Successfully',[], []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }


    public function deleteCategory($id)
    {
        try{
            ForumCategory::where('id',$id)->delete();
            $returnData = Response::prepare(false, 'Record Deleted Successfully',[], []);
            return response()->json($returnData, 200);
        }catch(\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }

    }
}
