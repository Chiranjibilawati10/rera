<?php

namespace App\Http\Controllers\Admin\Album;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Album\Album;
use DB;
use App\Tools\Response;


class AlbumController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        try {
            $query = Album::query();
            $data['records'] = $query
                                ->with('createdBy','updatedBy')
                                ->paginate(10);
            $returnData = Response::prepare(false, 'list_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validateEntry($request);
        try {
            DB::beginTransaction();
            $request['created_id']=auth()->user()->id;
           // $this->saveWithTranslationNepali(['name'=>$request->name_ne],$model);
            $category = Album::create($request->all());
            $returnData = Response::prepare(false, 'Record Created', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        try {
            $data['record'] = Album::find($id)->load('files');
            $returnData = Response::prepare(false, 'edit_success', $data, []);
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validateEntry($request);
        try {
            DB::beginTransaction();
            $request['updated_id']=auth()->user()->id;
            $entry = Album::where('id',$id)->update($request->only('name'));
            $returnData = Response::prepare(false, 'Record Updated Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            DB::beginTransaction();
            Album::where('id',$id)->delete();
            $returnData = Response::prepare(false, 'Record Deleted Successfully', [], []);
            DB::commit();
            return response()->json($returnData, 200);
        } catch (\Exception $e) {
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            DB::rollBack();
            return response()->json($returnData, 500);
        }
    }

    public function validateEntry($request)
    {
        $rules = [
                'name' => 'required',
                // 'title_ne' => 'required',
                // 'description' => 'required',
                // 'description_ne' => 'required',
                // 'status' => 'required',
                //'file'=>'required'
            ];
        $customMessages = [
            'name.required' => 'name was required',
            // 'title_ne.required' => 'answer was required',
            // 'description.required' => 'answer was required',
            // 'description_ne.required' => 'answer was required',
            // 'status.required' => 'answer was required',
            //'file.required'=>'file was required'
        ];
        $this->validate($request, $rules, $customMessages);
    }
}
