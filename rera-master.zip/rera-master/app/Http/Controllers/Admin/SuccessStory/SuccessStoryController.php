<?php

namespace App\Http\Controllers\Admin\SuccessStory;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\SuccessStory\SuccessStoryInterface;
     
class SuccessStoryController extends Controller
{

    protected $successStoryRepository;
    /**
     * OccupationSectorController constructor.
     *
     * @param OccupationSectorInterface $successStoryRepository
    */
    public function __construct(SuccessStoryInterface $successStoryRepository)
    {
        $this->successStoryRepository = $successStoryRepository;
       
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return $this->successStoryRepository->getData();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validateEntry($request);
        return $this->successStoryRepository
                    ->storeEntry($request);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return $this->successStoryRepository
                    ->getEntry($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validateEntry($request);
        return $this->successStoryRepository
                    ->updateEntry($request,$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return $this->successStoryRepository
                    ->deleteEntry($id);
    }

    public function validateEntry($request)
    {
        $rules = [
                'title' => 'required',
                'title_ne' => 'required',
                //'file'=>'required'
            ];
        $customMessages = [
            'title.required' => 'answer was required',
            'title_ne.required' => 'answer was required',
            //'file.required'=>'file was required'
        ];
        $this->validate($request, $rules, $customMessages);
    }
}
