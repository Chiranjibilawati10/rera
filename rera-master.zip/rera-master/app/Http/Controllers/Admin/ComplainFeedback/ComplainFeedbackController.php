<?php

namespace App\Http\Controllers\Admin\ComplainFeedback;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\ComplainFeedback\ComplainFeedbackInterface;
use Illuminate\Support\Facades\Validator;

class ComplainFeedbackController extends Controller
{

    protected $complainFeedbackRepository;
    /**
     * ComplainFeedbackController constructor.
     *
     * @param ComplainFeedbackInterface $ComplainFeedbackRepository
    */
    public function __construct(ComplainFeedbackInterface $complainFeedbackRepository)
    {
        $this->complainFeedbackRepository = $complainFeedbackRepository;
       
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return $this->complainFeedbackRepository->getData();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validateEntry($request);   
        return $this->complainFeedbackRepository
                    ->storeEntry($request);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return $this->complainFeedbackRepository
                    ->getEntry($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validateEntry($request);
        return $this->complainFeedbackRepository
                    ->updateEntry($request,$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return $this->complainFeedbackRepository
                    ->deleteEntry($id);
    }

    public function validateEntry($request)
    {
        // $rules = [
        //         'ComplainFeedback_name' => 'required',
        //         'ComplainFeedback_name_ne' => 'required'
        //     ];
        // $customMessages = [
        //     'ComplainFeedback_name.required' => 'ComplainFeedback name was required',
        //     'ComplainFeedback_name_ne.required'=>'ComplainFeedback name in nepali was required'
        // ];
        // $this->validate($request, $rules, $customMessages);
    }
}
