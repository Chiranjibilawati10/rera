<?php

namespace App\Http\Controllers\Admin\File;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\File\File as CustomFile;
use App\Tools\Response;

class FileController extends Controller
{
    public function deleteFile($id)
    {
        try{
            $file=CustomFile::find($id);
            $file->delete();
            $returnData = Response::prepare(false, 'File Deleted Successfully', [], []);
            return response()->json($returnData, 200);
        }catch (\Exception $e){
            $returnData = Response::prepare(true, $e->getMessage(), [], []);
            return response()->json($returnData, 500);
        }
    }


    public function upload(Request $request)
    {
        if($request->hasFile('upload')) {
            $originName = $request->file('upload')->getClientOriginalName();
            $fileName = pathinfo($originName, PATHINFO_FILENAME);
            $extension = $request->file('upload')->getClientOriginalExtension();
            $fileName = $fileName.'_'.time().'.'.$extension;
        
            $request->file('upload')->move(public_path('images'), $fileName);
   
            $CKEditorFuncNum = $request->input('CKEditorFuncNum');
            $url = asset('images/'.$fileName); 
            $msg = 'Image uploaded successfully'; 
            $response = "<script>window.parent.CKEDITOR.tools.callFunction($CKEditorFuncNum, '$url', '$msg')</script>";
               
            @header('Content-type: text/html; charset=utf-8'); 
            echo $response;
        }
    }
}
