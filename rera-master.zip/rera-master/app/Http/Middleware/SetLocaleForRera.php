<?php

namespace App\Http\Middleware;

use Closure;

class SetLocaleForRera
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $url = $request->url();
        if(strpos($url,'/ne')){
            \App::setlocale('ne');
        }else{
            \App::setlocale('en');
        } 
        return $next($request);
    }
}
