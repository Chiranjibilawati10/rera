<?php

namespace App\Model\Occupation;

use Illuminate\Database\Eloquent\Model;
use App\Model\Occupation\OccupationProfession;
use App\Tools\TranslationTrait;

class OccupationSector extends Model
{
   use TranslationTrait;
   protected $table = 'occupation_sectors';
   protected $primaryKey = 'id';
   protected $fillable=['name','name_ne'];
   protected $translationAttributes=['name'];

    public function professions()
    {
        return $this->hasMany(OccupationProfession::class);
    }
}
