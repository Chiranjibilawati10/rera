<?php

namespace App\Model\Occupation;

use Illuminate\Database\Eloquent\Model;
use App\Tools\TranslationTrait;

class OccupationProfession extends Model
{
    use TranslationTrait;
    protected $fillable=['name','name_ne'];
    protected $translationAttributes=['name'];
    /**
    * Get the user that owns the phone.
    */
   public function sector()
   {
       return $this->belongsTo('App\Model\OccupationSector');
   }
}
