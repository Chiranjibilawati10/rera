<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use App\Tools\UserTrait;
use App\Tools\TranslationTrait;
use Illuminate\Database\Eloquent\SoftDeletes;


class Faq extends Model
{
    use UserTrait,TranslationTrait,SoftDeletes;
    
    public $fillable = ['answer','question','answer_ne','question_ne'];

    protected $translationAttributes=['answer','question'];
}
