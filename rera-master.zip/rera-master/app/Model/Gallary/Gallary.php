<?php

namespace App\Model\Gallary;

use Illuminate\Database\Eloquent\Model;
use App\Tools\UserTrait;
use App\Tools\FileTrait;
use App\Model\Album\Album;


class Gallary extends Model
{
	use UserTrait,FileTrait;
    protected $fillable=['name','name_ne','status','category_id','description_ne','description','updated_id','created_id','album_id'];
    protected $table='gallaries';

    public function album()
    {
    	return $this->belongsTo(Album::class,'album_id');
    }
}
