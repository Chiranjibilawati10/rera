<?php

namespace App\Model\Logger;

use App\User;
use Illuminate\Database\Eloquent\Model;

class Logger extends Model
{
    protected $table = 'laravel_logger_activity';

    public function user()
    {
        $this->belongsTo(User::class, 'userId');
    }
}
