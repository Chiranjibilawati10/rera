<?php

namespace App\Model\Expert;

use Illuminate\Database\Eloquent\Model;
use App\Tools\TranslationTrait;

class Expert extends Model
{
    use TranslationTrait;
    protected $fillable=['name'];
    protected $translationAttributes=['name'];
    
    protected $table='expertises';
   
}
