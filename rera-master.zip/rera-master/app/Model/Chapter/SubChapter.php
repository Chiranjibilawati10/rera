<?php

namespace App\Model\Chapter;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Tools\UserTrait;
use App\Model\Topic\Topic;
use App\Tools\SecureDelete;
use App\Tools\TranslationTrait;

class SubChapter extends Model
{
    use UserTrait,SecureDelete,TranslationTrait;
    protected $table = 'chapters';
    protected $fillable = ['chapter_name', 'chapter_name_ne','created_id','updated_id', 'status'];
    protected $translationAttributes=['chapter_name'];

    public function topicsWithTrashed()
    {
        return $this->hasMany(Topic::class,'chapter_id')->withTrashed();
    }

    public function topics()
    {
        return $this->hasMany(Topic::class,'chapter_id');
    }

    public function topicsWithTranslation()
    {
        return $this->topics()->translate();
    }
}
