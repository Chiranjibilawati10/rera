<?php

namespace App\Model\Chapter;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Tools\UserTrait;
use App\Model\Topic\Topic;
use App\Tools\SecureDelete;
use App\Tools\TranslationTrait;



class Chapter extends Model
{
    use UserTrait,SecureDelete,TranslationTrait;
    protected $table = 'chapters';
    protected $fillable = ['chapter_name', 'chapter_name_ne','created_id','updated_id', 'status','parent_id','level','summary','summary_ne','order','slug'];
    protected $translationAttributes=['chapter_name','summary'];

    public function topicsWithTrashed()
    {
        return $this->hasMany(Topic::class,'chapter_id')->withTrashed();
    }

    public function topics()
    {
        return $this->hasMany(Topic::class,'chapter_id');
    }

    public function topicsWithTranslation()
    {
        return $this->topics()->translate();
    }

    public function parent()
    {
        return $this->belongsTo(Self::class,'parent_id');
    }

    public function children()
    {
        return $this->hasMany(Self::class,'parent_id')->where('level','child');
    }

    public function setOrderAttribute($value)
    {
        $this->attributes['order'] = is_null($value)?0:$value;
    }
}
