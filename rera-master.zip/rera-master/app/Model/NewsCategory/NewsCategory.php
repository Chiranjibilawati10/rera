<?php

namespace App\Model\NewsCategory;

use Illuminate\Database\Eloquent\Model;
use App\Tools\UserTrait;
use App\Tools\SecureDelete;
use App\Model\NewsEvents\NewsEvent;

class NewsCategory extends Model
{
    use UserTrait,SecureDelete;
    protected $table = 'news_categories';
    protected $fillable = ['news_category_name','news_category_name_ne', 'created_id', 'updated_id'];

    public function notices()
    {
        return $this->hasMany(NewsEvent::class,'category_id');
    }

    public function noticesWithTrashed()
    {
        return $this->hasMany(NewsEvent::class,'category_id')->withTrashed();
    }
}
