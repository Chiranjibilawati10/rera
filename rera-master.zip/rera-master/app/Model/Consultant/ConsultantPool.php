<?php

namespace App\Model\Consultant;

use App\Tools\UserTrait;


use Illuminate\Database\Eloquent\Model;

class ConsultantPool extends Model
{
    use UserTrait;
    
    protected $fillable = ['province_id', 'district_id','municipality_id','name','contact','email','expertise','created_id','updated_id','status'];
    protected $table = 'consultants';

    public function district()
    {
      return $this->belongsTo('App\Model\Region\District','district_id','ID');
    }

    public function municipality()
    {
      return $this->belongsTo('App\Model\Region\Municipality','municipality_id','ID');
    }

    public function province()
    {
      return $this->belongsTo('App\Model\Region\Province','province_id','ID');
    }

}
