<?php

namespace App\Model\Topic;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Tools\UserTrait;
use App\Model\RETechnology\Category;
use App\Model\Chapter\Chapter;
use App\Tools\FileTrait;
use App\Tools\TranslationTrait;

class Topic extends Model
{
	use softDeletes,UserTrait,FileTrait,TranslationTrait;
	
    protected $fillable = ['category_id','chapter_id',
                            'title','created_id','updated_id', 'status','title_ne','summary_ne','summary','content_type','video','target_group','technical_level','source','weblink','language','order','draft_review'];
	protected $translationAttributes=['title','summary'];
    protected $table = 'topics';

	public function category()
	{
	   return $this->belongsTo(Category::class,'category_id');
	}

	public function chapter()
	{
	   return $this->belongsTo(Chapter::class,'chapter_id');
	}
	
	public function getTargetGroupAttribute($value)
	{
		return ($value=='null')?'':$value;
	}

	public function getTechnicalLevelAttribute($value)
	{
		return ($value=='null')?'':$value;
	}

	public function getVideoAttribute($value)
	{
		return ($value=='null')?'':$value;
	}

	public function getSourceAttribute($value)
	{
		return ($value=='null')?'':$value;
	}

	public function getWeblinkAttribute($value)
	{
		return ($value=='null')?'':$value;
	}

	public function getLanguageAttribute($value)
	{
		return ($value=='null')?'':$value;
	}

	public function getDraftReviewAttribute($value)
	{
		return ($value=='null')?'':$value;
	}

	public function setOrderAttribute($value)
	{
	    $this->attributes['order'] = is_null($value)?0:$value;
	}

	public function getSummaryAttribute($value)
	{
		return ($value=='null' || is_null($value))?'':$value;
	}

	public function getSummaryNeAttribute($value)
	{
		return ($value=='null' || is_null($value))?'':$value;
	}

	public function getTitleNeAttribute($value)
	{
		return ($value=='null' || is_null($value))?'':$value;
	}


}
