<?php

namespace App\Model\Region;

use Illuminate\Database\Eloquent\Model;
use App\Tools\TranslationTrait;

class District extends Model
{
    use TranslationTrait;
    protected $fillable=['name'];
    protected $translationAttributes=['name'];
    
    protected $table='districts';
    /**
    * Get the user that owns the phone.
    */
   public function municipalities()
   {
       return $this->hasmany('App\Model\Region\Municipality','DISTRICT_ID');
   }
}
