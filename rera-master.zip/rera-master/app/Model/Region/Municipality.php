<?php

namespace App\Model\Region;

use Illuminate\Database\Eloquent\Model;
use App\Tools\TranslationTrait;


class Municipality extends Model
{
    use TranslationTrait;
    protected $fillable=['name'];
    
    protected $table='municipalities';
    

    protected $translationAttributes=['name'];

}
