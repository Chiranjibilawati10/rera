<?php

namespace App\Model\File;

use Illuminate\Database\Eloquent\Model;
use File as FileUploads;
use Storage;

class File extends Model
{

	protected $fillable = ['model_id','model_type','location','type','url','name','extension','size','download'];
    protected $appends=['document','file_type'];
    /**
	* Get all of the owning File models.
	*/
    public function model()
    {
        return $this->morphTo();
    }

    public function getLocationAttribute($value)
    {
        // if(auth()->check()){
            return url(Storage::url($value));
        // }else{
        //     return '#';
        // }
        
    }

    public function getFileTypeAttribute($value)
    {
        return url(Storage::url($this->attributes['location']));
    }


    public function getDocumentAttribute($value)
    {
        if(auth()->check()){
            return url(Storage::url($this->attributes['location']));
        }else{
            return '#';
        }
    }

    public static function boot()
    {
        try{
	        parent::boot();
	        static::deleting(function($file){
	            if(!FileUploads::exists(storage_path($file->location))){
                    if(!FileUploads::exists(storage_path($file->download))){
                        Storage::delete($file->download);
                    }
		           	Storage::delete($file->location);
		           	return;
	            }
	        });
	        return;
        }catch(\Exception $e){
        	return;
        }   	
    }
}
