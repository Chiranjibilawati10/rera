<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use App\Tools\UserTrait;
use App\Tools\TranslationTrait;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\User;

class Activity extends Model
{
	protected $table='laravel_logger_activity';
   
    public function user()
    {
        return $this->belongsTo(User::class,'userId');
    }

    public function getDescriptionAttribute($value)
    {
    	$value=str_replace('webApi/','',$value);
    	$value=str_replace('frontapi/','',$value);
    	$value=str_replace('en/','',$value);
    	$value=str_replace('ne/','',$value);
    	return $value;
    }


 
  
}
