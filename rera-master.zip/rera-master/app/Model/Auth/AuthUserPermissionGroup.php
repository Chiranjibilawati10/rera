<?php

namespace App\Model\Auth;

use App\User;
use Illuminate\Database\Eloquent\Model;

class AuthUserPermissionGroup extends Model
{
    protected $table = 'auth_user_permission_groups';
    protected $primaryKey = 'ID';
    public $timestamps = false;

    public function group()
    {
        return $this->belongsTo(AuthGroup::class,'GROUP_ID');
    }

    public function user()
    {
        return $this->belongsTo(User::class,'USER_ID');
    }
}
