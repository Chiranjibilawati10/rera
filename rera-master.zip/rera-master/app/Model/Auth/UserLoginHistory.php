<?php

namespace App\Model\Auth;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class UserLoginHistory extends Model
{
    protected $fillable = ['user_id','login_at','logout_at','login_ip','role','session_id'];
    protected $dates = ['login_at'];

    public function setLogOutLog()
    {
//        dd(request()->session()->getId());
//        bug: this function is not getting proper session id
        $this->where('session_id',request()->session()->getId())->update([
            'logout_at' => Carbon::now(),
        ]);

    }

    public function setLogInLog()
    {
//        dd(Auth::user());
        $this->insert(
            [
                'user_id' => Auth::guard('general')->user()->id ?: Auth::guard('web')->user()->id,
                'login_at' =>Carbon::now(),
                'login_ip'=>request()->getClientIp(),
                'guard' => Auth::user() ? 'web' : 'general',
                'session_id'=>request()->session()->getId()
            ]);
    }
}
