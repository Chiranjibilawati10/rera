<?php

namespace App\Model\Auth;

use Illuminate\Database\Eloquent\Model;

class AuthGroup extends Model
{
    protected $table = 'auth_groups';
    protected $primaryKey = 'ID';
    public $timestamps = false;
}
