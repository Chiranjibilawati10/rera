<?php

namespace App\Model\Auth;

use Illuminate\Database\Eloquent\Model;

class AuthPermissionGroup extends Model
{
    protected $table = 'auth_permission_groups';
    protected $primaryKey = 'ID';
    public $timestamps = false;

    public function permission()
    {
        return $this->belongsTo(AuthPermission::class, 'PERMISSION_ID');
    }

    public function group()
    {
        return $this->belongsTo(AuthGroup::class, 'GROUP_ID');
    }
}
