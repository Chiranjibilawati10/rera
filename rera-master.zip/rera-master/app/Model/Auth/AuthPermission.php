<?php

namespace App\Model\Auth;

use Illuminate\Database\Eloquent\Model;

class AuthPermission extends Model
{
    protected $table = 'auth_permissions';
    protected $primaryKey = 'ID';
    public $timestamps = false;

    protected $fillable = [
        'DISPLAY_NAME',
        'CODE',
        'MENU_CODE'
    ];
}
