<?php

namespace App\Model\Forum;

use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class ForumDiscussion extends Model
{
    use SoftDeletes;
    protected $table = 'chatter_discussion';
    protected $dates = ['deleted_at'];

    public function category()
    {
        return $this->belongsTo(ForumCategory::class, 'chatter_category_id');
    }
    public function author()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
