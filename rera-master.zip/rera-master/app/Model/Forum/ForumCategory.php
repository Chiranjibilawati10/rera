<?php

namespace App\Model\Forum;

use Illuminate\Database\Eloquent\Model;

class ForumCategory extends Model
{
    protected $table = 'chatter_categories';
    protected $primaryKey = 'id';
}
