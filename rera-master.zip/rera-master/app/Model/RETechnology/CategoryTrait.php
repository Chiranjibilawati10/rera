<?php
namespace App\Model\RETechnology;

use App\Model\Topic\Topic;
use App\Model\Faq;

trait  CategoryTrait{

	public function children()
	{
	    return $this->hasMany(Self::class,'parent_id');
	}

	// recursive, loads all descendants
	public function childrenRecursive()
	{
	    return $this->children()->with('childrenRecursive');
	}

	// parent
	public function parentCategory()
	{
	    return $this->belongsTo(Self::class,'parent_id');
	}

	// all ascendants
	public function parentRecursive()
	{
	    return $this->parentCategory()->with('parentRecursive');
	}

	public function topics()
	{
	    return $this->hasMany(Topic::class,'category_id');
	}

	public function faqs()
	{
		return $this->hasMany(Faq::class,'category_id');

	}

	public function topicsWithTrashed()
	{
	    return $this->hasMany(Topic::class,'category_id')->withTrashed();
	}

	public function faqsWithTrashed()
	{
	    return $this->hasMany(Faq::class,'category_id')->withTrashed();
	}


}