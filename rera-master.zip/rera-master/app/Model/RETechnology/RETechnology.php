<?php

namespace App\Model\RETechnology;

use Illuminate\Database\Eloquent\Model;
use App\Model\RETechnology\Category;
use App\Tools\UserTrait;
use App\Tools\SecureDelete;
use App\Tools\TranslationTrait;


class RETechnology extends Model
{
	use UserTrait,SecureDelete,CategoryTrait,TranslationTrait;
	
	protected $guarded = ['id'];
	protected $translationAttributes=['name','description'];
	
	protected $fillable=['name','name_ne','description','description_ne','created_id','updated_id','status','r_e_technology_id','parent_id','level','slug'];

	protected $table="categories";

	public function categories()
	{
	    return $this->hasMany(Category::class,'parent_id')
	                ->where('level','category');
	}
}