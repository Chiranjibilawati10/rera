<?php

namespace App\Model\ComplainFeedback;

use Illuminate\Database\Eloquent\Model;

class ComplainFeedback extends Model
{
    protected $fillable = ['type','subject','message','reply_message','send_from_email','reply_by_email'];
}
