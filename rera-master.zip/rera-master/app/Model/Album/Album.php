<?php

namespace App\Model\Album;

use Illuminate\Database\Eloquent\Model;
use App\Tools\UserTrait;
use App\Tools\FileTrait;


class Album extends Model
{
	use UserTrait,FileTrait;
    protected $fillable=['updated_id','created_id','type','name','name_ne','status','slug','order'];
    protected $table='albums';
}
