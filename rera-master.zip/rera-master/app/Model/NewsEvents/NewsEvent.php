<?php

namespace App\Model\NewsEvents;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Tools\UserTrait;
use App\Tools\TranslationTrait;
use App\Tools\FileTrait;
use App\Model\NewsCategory\NewsCategory;


class NewsEvent extends Model
{
    use UserTrait,TranslationTrait,FileTrait,SoftDeletes;

    protected $fillable = ['title','title_ne','content','content_ne','external_link','created_id','updated_id','category_id'];
    protected $table = 'news_event';

    protected $translationAttributes=['title','content'];

    public function category()
	{
	   return $this->belongsTo(NewsCategory::class,'category_id');
	}
}
