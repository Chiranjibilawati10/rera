<?php

namespace App\Model\Slider;

use Illuminate\Database\Eloquent\Model;
use App\Tools\FileTrait;
use App\Tools\UserTrait;
use App\Tools\TranslationTrait;
use Illuminate\Database\Eloquent\SoftDeletes;

class Slider extends Model
{
    use UserTrait,FileTrait;
    protected $table = 'sliders';
    protected $fillable = ['title','title_ne','description','description_ne','status','created_id','updated_id','deleted_at'];
}
