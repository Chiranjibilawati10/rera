<?php

namespace App\Model\SuccessStory;
use App\Tools\FileTrait;
use Illuminate\Database\Eloquent\Model;
use App\Tools\UserTrait;
use App\Tools\TranslationTrait;
use Illuminate\Database\Eloquent\SoftDeletes;


class SuccessStory extends Model
{
    use UserTrait,FileTrait,TranslationTrait,SoftDeletes;

    public $fillable = ['title','title_ne','created_id','updated_id'];
    protected $translationAttributes=['title'];
    
}
