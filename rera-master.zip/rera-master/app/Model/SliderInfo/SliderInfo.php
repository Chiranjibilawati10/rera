<?php

namespace App\Model\SliderInfo;

use Illuminate\Database\Eloquent\Model;
use App\Tools\TranslationTrait;
use App\Tools\UserTrait;


class SliderInfo extends Model
{
	use TranslationTrait,UserTrait;
    protected $fillable = ['title','title_ne','description','description_ne','status','created_id','updated_id'];
}
