<?php

namespace App\Listeners;

use App\Model\Auth\UserLoginHistory;
use Illuminate\Auth\Events\Logout;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class LogoutLogs
{
    private $UserLogoutHistory;

    public function __construct(UserLoginHistory $UserLoginHistory)
    {
        // the initialization of  private $UserLogoutHistory;

        $this->UserLogoutHistory = $UserLoginHistory;
    }


    public function handle(Logout $event)
    {
        // from model UserLoginHistory
        $this->UserLogoutHistory->setLogOutLog();
    }
}
