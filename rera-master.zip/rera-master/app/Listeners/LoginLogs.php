<?php

namespace App\Listeners;

use App\Model\Auth\UserLoginHistory;
use Illuminate\Auth\Events\Login;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class LoginLogs
{
    private $UserLoginHistory;

    public function __construct(UserLoginHistory $UserLoginHistory)
    {
        // the initialization of  private $UserLoginHistory;

        $this->UserLoginHistory = $UserLoginHistory;
    }


    public function handle(Login $event)
    {
        // from model UserLoginHistory

        $this->UserLoginHistory->setLogInLog();
    }
}
