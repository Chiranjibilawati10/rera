<?php

namespace App\Listeners;

use Illuminate\Auth\Events\Login;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Request;

class SetCookie
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  Login  $event
     * @return void
     */
    public function handle(Login $event)
    {
        Cookie::queue(cookie('_email', Auth::guard('general')->user()->email ?: Auth::guard('web')->user()->email, 45000));
        Cookie::queue(cookie('_name', Auth::guard('general')->user()->name ?: Auth::guard('web')->user()->name, 45000));
    }
}
