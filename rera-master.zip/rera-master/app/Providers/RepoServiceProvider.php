<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class RepoServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $repos = [
                   'OccupationSector',
                   'OccupationProfession',
                   'Chapter',
                   'Faq',
                   'Category',
                   'RETechnology',
                   'SubCategory',
                   'Topic',
                   'NewsCategory',
                   'NewsEvents',
                   'SuccessStory',
                   'ComplainFeedback',
                   'NewsCategory',
                   'ConsultantPool',
                   'Slider',
                   'Gallary'
               ];
        foreach ($repos as $repo) {
           $this->app->bind(
               "App\Repositories\\{$repo}\\{$repo}Interface",
               "App\Repositories\\{$repo}\\{$repo}Repository"
           );
       }
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
