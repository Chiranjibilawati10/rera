<?php

namespace App\Providers;

use App\Model\Auth\AuthPermission;
use Illuminate\Support\Facades\Schema;
use Laravel\Passport\Passport;
use Illuminate\Support\Facades\Gate;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
         'App\Model' => 'App\Policies\ModelPolicy',
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();

        $this->userAccessPolicies();

        Passport::routes();

        Passport::tokensExpireIn(now()->addDays(15));

        Passport::refreshTokensExpireIn(now()->addDays(30));

        Passport::personalAccessTokensExpireIn(now()->addMonths(6));
    }

    public function userAccessPolicies()
    {
        Gate::before(function($user) {
            return $user->isSuperUser();
        });


        if (Schema::hasTable('auth_permissions')){
            $permissions = AuthPermission::all();
            foreach ($permissions as $prem){
                $role = $prem->CODE;
                Gate::define($role, function($user) use($role){
                    return $user->hasAccess($role); // returns true or false.
                });
            }
        }
    }
}
