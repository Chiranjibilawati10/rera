<?php 
namespace App\Tools;

trait UserTrait
{
    public function createdBy()
    {
       return $this->belongsTo('App\User','created_id')->select(['name','id']);
    }

    public function updatedBy()
    {
        return $this->belongsTo('App\User','updated_id')->select(['name','id']);
    }
}