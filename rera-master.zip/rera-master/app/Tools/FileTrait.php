<?php

namespace App\Tools;

trait FileTrait
{
    public function files()
    {
        return $this->morphMany('App\Model\File\File', 'model');
    }

    public function getImage()
    {
        $file=$this->files()
                   ->where('type','image')
                   ->first();
        if($file){
            return $file->location;
        }
        return 0;
    }

    public function getFileType($type='image')
    {
        $file=$this->files()
                   ->where('type',$type)
                   ->first();
        if($file){
            return $file->location;
        }
        return 0;
    }

    public function getMultipleFileByType($type='image')
    {
        return  $this->files()
                   ->where('type',$type)
                   ->get();
    }

    public function timthumb($src=null,$w=200,$h=150)
    {
        if($src == null){
            return;
        }
        if($w==null){
            $url = '/image.php?src='.$src.'&h='.$h;
        }
        else if($h == null){
            $url = '/image.php?src='.$src.'&w='.$w;
        }
        else{
            $url = '/image.php?src='.$src.'&w='.$w.'&h='.$h;
        }
        return url($url.'&static=true');
    }

    public static function boot()
    {
        try{
            parent::boot();
	        self::deleting(function ($value) {
                if(!$value->soft_deleting){
                    foreach($value->files()->get() as $value){
                        $value->delete();
                    }
                }else{
                    if ($value->isForceDeleting()) {
                        foreach($value->files()->get() as $value){
                            $value->delete();
                        }
                    }
                }
            });
	        return;
        }catch(\Exception $e){
        	return;
        }   	
    }

    // In your model...
    public function getSoftDeletingAttribute()
    {
        // ... check if 'this' model uses the soft deletes trait
        return in_array('Illuminate\Database\Eloquent\SoftDeletes', class_uses($this)) && ! $this->forceDeleting;
    }

}
