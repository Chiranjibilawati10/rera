<?php 
namespace App\Tools;
use DB;

trait TranslationTrait
{

    public function scopeTranslate($query)
    {
        try{
            if(\App::getLocale()=='ne'){
                $query=$query->select(array_diff($this->getTableColumns(),$this->translationAttributes));
                foreach ($this->translationAttributes as $key => $attribute) 
                {
                    if(\App::getLocale()=='ne'){
                        $query->addSelect($attribute.'_ne as '.$attribute);
                    }
                }
            }
        }catch (\Exception $e) {
        }

    }

    public function getTableColumns()
    {
        return $this->getConnection()->getSchemaBuilder()->getColumnListing($this->getTable());
    }
}