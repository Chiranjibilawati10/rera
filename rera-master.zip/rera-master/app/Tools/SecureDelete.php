<?php 
namespace App\Tools;

trait SecureDelete
{
    /**
     * Delete only when there is no reference to other models.
     *
     * @param array $relations
     * @return response
     */
    public function secureDelete(int $id,Array $relations)
    {
        $hasRelation = false;
        $model=$this->find($id);
        foreach ($relations as $relation) {
            if ($model->$relation()->get()->count()) {
                $hasRelation = true;
                break;
            }
        }
        if ($hasRelation) {
            return false;
        } else {
            $model->delete();
            return true;
        }
    }

    // return $telco->secureDelete('operators', 'packages', 'topups');
}