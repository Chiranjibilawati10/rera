<?php namespace App\Tools;

use Illuminate\Support\Facades\Storage;
use File;
use App\Models\File as LaravelFile;

trait ImageUploader{

    protected $fileName;

    protected $file;

    protected $location;

    protected $uploaded_files_path=[];


    /**
     * @param $file
     * @param string $location
     * @param bool $fileName
     * @return mixed
     */
    public function performUpload($file, $location='public/uploads', $fileName=false)
    {
        if(!is_null($file)){
            $this->file=$file;
            $this->location=$location;
            $this->fileName=$fileName;
            return $this->upload();
        }
        return false;
      

    }


    /**
     * @return mixed
     */
    private function upload()
    {
        // if($this->checkFileExistance()){
	   return $this->file->storeAs(
                $this->location, $this->getFilename());
        // }
        
    }

    /**
     * @return string
     */
    private function getFilename()
    {
        if($this->file && !$this->fileName){
            $file_name = pathinfo($this->file->getClientOriginalName(), PATHINFO_FILENAME);
            $file_name=substr($file_name,0,10);
            $extension = $this->file->getClientOriginalExtension();
            // $fileName = $this->normalizeString($file_name).'-'.rand(). time(). '.' . $extension;
            $fileName = $this->normalizeString($file_name).'-'.rand(). '.' . $extension;
            return preg_replace('/\s+/', '',$fileName);
        }
        return $this->fileName;

    }

    /**
     * @return bool
     */
    private function checkFileExistance($location=0,$fileName=0)
    {
     
     //    $path = storage_path($this->location.'/'.$this->getFilename());
    	// if(File::exists($path)){
    	//     return true;
    	// }
    	// return false;
        return true;
    }

    /**
     * @param $location
     */
    public function deleteSingleUpload($entry,$location=false)
    {
        try{
            if($entry){
                $file=$entry->files()->first();
                if($file){
                    $file->delete();
                }
                return; 
            }
            if(!File::exists(storage_path($location))){
                Storage::delete($location);
                return;
            }
        }catch(\Exception $e){
            return;
        }
        

    	
    }

    /**
     * @param $location
     */
    public function deleteMultipleUpload($entry)
    {
        try{
            if($entry){
                $files=$entry->files()->get();
                if(count($files)){
                    foreach($files as $file){
                        $file->delete();
                    }
                    
                }
                return; 
            }
            if(!File::exists(storage_path($location))){
                Storage::delete($location);
                return;
            }
        }catch(\Exception $e){
            return;
        }
        

    	
    }

    /**
     * @param $request,$model
     */
    public function uploadMultipleFile($request,$model)
    {
        if($request->file){
            foreach ($request->file as $value){
                $path=$this->performUpload($value);
                if($path){
                    $model->files()->create([
                                        'location'=>$path,
                                        'type'=>'file',
                                        'name'=>pathinfo($value->getClientOriginalName(), PATHINFO_FILENAME).'.'.$value->getClientOriginalExtension(),
                                        'extension'=> $value->getClientOriginalExtension(),
                                        'size'=>$value->getSize()
                                    ]);
                    $this->uploaded_files_path[]=$path;
                }
            }
            return $this->uploaded_files_path;
        }
    }

    /**
     * @param $request,$model
     */
    public function uploadContentFiles($request,$model)
    {
        if($request->file){
            foreach ($request->file as $value){
                $offline_location=$this->createContentLocation($model);
                $path=$this->performUpload($value);
                $original_file_name=pathinfo($value->getClientOriginalName(), PATHINFO_FILENAME).'.'.$value->getClientOriginalExtension();
                $download=$this->performUpload($value,$offline_location,$original_file_name);
                if($path){
                    $model->files()->create([
                                        'location'=>$path,
                                        'type'=>'file',
                                        'name'=>$original_file_name,
                                        'extension'=> $value->getClientOriginalExtension(),
                                        'size'=>$value->getSize(),
                                        'download'=>$download
                                    ]);
                    $this->uploaded_files_path[]=$path;
                }
            }
            return $this->uploaded_files_path;
        }
    }

    public function createContentLocation($request)
    {
        if($request->chapter->parent){
            $location='public/re_technology/'.$request->chapter->parent->chapter_name.'/'.$request->chapter->chapter_name;

        }else{
            $location='public/re_technology/'.$request->chapter->chapter_name;
        }
        return $location;
    }
    /**
     * @param $file
     */
    public function uploadSingleFile($request,$model)
    {
        if($request->hasFile('file')){
            $path=$this->performUpload($request->file);
            $model->files()->create([
                                    'location'=>$path,
                                    'type'=>'file',
                                    'name'=>$this->getFilename()
                                ]);
        }
        return $this->uploaded_files_path;
    }

    public  function normalizeString ($str = '')
    {
        $str = strip_tags($str); 
        $str = preg_replace('/[\r\n\t ]+/', ' ', $str);
        $str = preg_replace('/[\"\*\/\:\<\>\?\'\|]+/', ' ', $str);
        $str = strtolower($str);
        $str = html_entity_decode( $str, ENT_QUOTES, "utf-8" );
        $str = htmlentities($str, ENT_QUOTES, "utf-8");
        $str = preg_replace("/(&)([a-z])([a-z]+;)/i", '$2', $str);
        $str = str_replace(' ', '-', $str);
        $str = rawurlencode($str);
        $str = str_replace('%', '-', $str);
        return $str;
    }



}

