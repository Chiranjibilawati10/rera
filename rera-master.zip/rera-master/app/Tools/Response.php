<?php
namespace App\Tools;

class Response{

    public static function prepare($error, $message, Array $data, Array $meta)
    {
        return [
            'error' => $error,
            'message' => $message,
            'data' => $data,
            'meta' => $meta
        ];
    }
}
