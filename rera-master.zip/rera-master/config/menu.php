<?php

return[
    'menu' => [
        [
            'id' => 1,
            'label' => 'User',
            'code' => 'user',
            'description' => 'User settings defines the user\'s rights to configure their own settings as well as make changes to other user\'s.'
        ],
        [
            'id' => 2,
            'label' => 'Permission',
            'code' => 'permission',
            'description' => 'Permission settings defines the user\'s rights to configure their own settings as well as make changes to other user\'s.'
        ],
        [
            'id' => 3,
            'label' => 'Setting',
            'code' => 'setting',
            'description' => 'Setting defines the user\'s rights to configure their own settings as well as make changes to other user\'s.'
        ]
    ]
];
